<?php
// Defense-in-depth HTTP security headers
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

require_once __DIR__ . '/../config.php';

$current_user = require_login(['super_admin', 'staff']);
if ($current_user['role'] === 'staff') {
    require_menu_permission('admin_expense_report');
}

// Session-based request rate limiting (Max 120 page requests per minute)
$now = time();
if (!isset($_SESSION['expense_report_req_attempts']) || !is_array($_SESSION['expense_report_req_attempts'])) {
    $_SESSION['expense_report_req_attempts'] = [];
}
$_SESSION['expense_report_req_attempts'] = array_filter($_SESSION['expense_report_req_attempts'], function($timestamp) use ($now) {
    return ($now - (int)$timestamp) < 60;
});
if (count($_SESSION['expense_report_req_attempts']) >= 120) {
    http_response_code(429);
    exit('Rate limit exceeded. Please wait a moment before trying again.');
}
$_SESSION['expense_report_req_attempts'][] = $now;

$page_title = 'Financial & Expense Audit Report | KSV Academy HRMS';
$page_heading = 'Expense Report';
$page_subheading = 'Category Breakdown, Revenue vs Expenditure Balance, and Monthly Audit Summary';
$active_menu = 'expense-report';

$db = get_db_connection();
$active_session = get_active_session();
$session_id = $active_session ? intval($active_session['id']) : 1;
$current_session_name = $active_session['session_name'] ?? (defined('CURRENT_SESSION') ? CURRENT_SESSION : date('Y'));
$school_settings = get_school_settings();

// Summary calculations for the active session (Prepared Statements)
$stmt_tf = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM fee_payments WHERE session_id = ?");
$stmt_tf->execute([$session_id]);
$total_fees = floatval($stmt_tf->fetchColumn());

$stmt_te = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE session_id = ?");
$stmt_te->execute([$session_id]);
$total_expenses = floatval($stmt_te->fetchColumn());

$stmt_tp = $db->prepare("SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE session_id = ? AND payment_status = 'Paid'");
$stmt_tp->execute([$session_id]);
$total_payroll = floatval($stmt_tp->fetchColumn());

$net_operating_balance = $total_fees - ($total_expenses + $total_payroll);
$total_disbursed = $total_expenses + $total_payroll;

// Category-wise Breakdown (Comprehensive accounting including uncategorized or reallocated heads)
$stmt_cat = $db->prepare("
    SELECT COALESCE(c.id, 0) as id,
           COALESCE(c.category_name, 'Uncategorized') as category_name,
           SUM(e.amount) as total_amount,
           COUNT(e.id) as vouchers_count
    FROM expenses e
    LEFT JOIN expense_categories c ON e.category_id = c.id
    WHERE e.session_id = ?
    GROUP BY c.id, c.category_name
    HAVING total_amount > 0
    ORDER BY total_amount DESC
");
$stmt_cat->execute([$session_id]);
$cat_breakdown = $stmt_cat->fetchAll();

// Monthly Breakdown
$stmt_month = $db->prepare("
    SELECT DATE_FORMAT(expense_date, '%M %Y') as month_label,
           DATE_FORMAT(expense_date, '%Y-%m') as month_key,
           COUNT(id) as voucher_count,
           SUM(amount) as monthly_total
    FROM expenses
    WHERE session_id = ?
    GROUP BY month_key, month_label
    ORDER BY month_key DESC
");
$stmt_month->execute([$session_id]);
$monthly_expenses = $stmt_month->fetchAll();

// Payment Method Distribution (Prepared Statement)
$stmt_method = $db->prepare("
    SELECT payment_method,
           COUNT(id) as voucher_count,
           COALESCE(SUM(amount), 0) as total_amount
    FROM expenses
    WHERE session_id = ?
    GROUP BY payment_method
    ORDER BY total_amount DESC
");
$stmt_method->execute([$session_id]);
$method_breakdown = $stmt_method->fetchAll();

// Helper to pick category icon and color
function get_report_cat_icon($name) {
    $n = strtolower($name);
    if (strpos($n, 'elect') !== false || strpos($n, 'power') !== false || strpos($n, 'util') !== false) {
        return ['icon' => 'fa-bolt', 'bg' => '#fef3c7', 'color' => '#b45309', 'border' => '#fde68a'];
    }
    if (strpos($n, 'station') !== false || strpos($n, 'print') !== false || strpos($n, 'paper') !== false) {
        return ['icon' => 'fa-book-open', 'bg' => '#e0f2fe', 'color' => '#0369a1', 'border' => '#bae6fd'];
    }
    if (strpos($n, 'lab') !== false || strpos($n, 'scien') !== false || strpos($n, 'chem') !== false) {
        return ['icon' => 'fa-flask-vial', 'bg' => '#f3e8ff', 'color' => '#7e22ce', 'border' => '#e9d5ff'];
    }
    if (strpos($n, 'it') !== false || strpos($n, 'soft') !== false || strpos($n, 'comput') !== false) {
        return ['icon' => 'fa-laptop-code', 'bg' => '#ecfdf5', 'color' => '#047857', 'border' => '#a7f3d0'];
    }
    if (strpos($n, 'maint') !== false || strpos($n, 'build') !== false || strpos($n, 'repair') !== false) {
        return ['icon' => 'fa-screwdriver-wrench', 'bg' => '#fff7ed', 'color' => '#c2410c', 'border' => '#fed7aa'];
    }
    return ['icon' => 'fa-tags', 'bg' => '#f1f5f9', 'color' => '#475569', 'border' => '#e2e8f0'];
}

function get_method_icon($method) {
    switch (strtolower(trim($method))) {
        case 'cash':
            return ['icon' => 'fa-wallet', 'bg' => '#ecfdf5', 'color' => '#059669', 'border' => '#a7f3d0'];
        case 'upi':
            return ['icon' => 'fa-qrcode', 'bg' => '#eff6ff', 'color' => '#2563eb', 'border' => '#bfdbfe'];
        case 'bank transfer':
            return ['icon' => 'fa-building-columns', 'bg' => '#f5f3ff', 'color' => '#7c3aed', 'border' => '#ddd6fe'];
        case 'cheque':
            return ['icon' => 'fa-money-check', 'bg' => '#fffbeb', 'color' => '#d97706', 'border' => '#fde68a'];
        default:
            return ['icon' => 'fa-credit-card', 'bg' => '#f8fafc', 'color' => '#64748b', 'border' => '#e2e8f0'];
    }
}

require_once __DIR__ . '/../includes/layout-header.php';
?>

<style>
/* ── Staff ID Style Table (Simple & Sober - Matching staff-id) ── */
.staff-id-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}
.staff-id-table thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 0.73rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
.staff-id-table tbody td {
  padding: 11px 12px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
  font-size: 0.84rem;
}
.staff-id-table tbody tr {
  transition: background-color 0.15s ease;
}
.staff-id-table tbody tr:hover {
  background-color: #f8fafc;
}

/* ── Report Module Specific Styles ── */
.report-progress-bar {
  width: 100%;
  height: 6px;
  background: #f1f5f9;
  border-radius: 999px;
  overflow: hidden;
  margin-top: 6px;
}
.report-progress-fill {
  height: 100%;
  border-radius: 999px;
  background: linear-gradient(90deg, #0092df, #0284c7);
  transition: width 0.4s ease;
}
.report-cat-item {
  padding: 11px 13px;
  border-radius: 8px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  transition: all 0.2s ease;
}
.report-cat-item:hover {
  background: #ffffff;
  border-color: #cbd5e1;
  box-shadow: 0 2px 6px rgba(0,0,0,0.03);
}
.method-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.method-card:hover {
  transform: translateY(-1px);
  box-shadow: 0 3px 8px rgba(0,0,0,0.04);
}
.method-icon-box {
  width: 38px;
  height: 38px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  flex-shrink: 0;
}

/* ── Print Styles ── */
@media print {
  @page {
    size: A4 portrait;
    margin: 15mm;
  }
  body {
    background: #ffffff !important;
    color: #000000 !important;
  }
  .no-print, header, aside, .sidebar, .hrms-sidebar, .hrms-header, .stat-grid, .roaster-toolbar-card {
    display: none !important;
  }
  .report-printable-area {
    display: block !important;
    width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
  }
  .print-header-banner {
    display: block !important;
    margin-bottom: 24px;
    border-bottom: 2px solid #0f172a;
    padding-bottom: 16px;
  }
  .print-signatures {
    display: flex !important;
    justify-content: space-between;
    margin-top: 50px;
    padding-top: 20px;
  }
  .hrms-card {
    box-shadow: none !important;
    border: 1px solid #cbd5e1 !important;
    margin-bottom: 20px !important;
    break-inside: avoid;
  }
  .hrms-table th {
    background: #f1f5f9 !important;
    color: #0f172a !important;
  }
}
.print-header-banner, .print-signatures {
  display: none;
}

/* ══════════════════════════════════════════════════════════════════════
   RESPONSIVE MOBILE VIEW ENHANCEMENTS FOR EXPENSE REPORT
   ══════════════════════════════════════════════════════════════════════ */

/* Tablet & Mobile Screens (<= 768px) */
@media (max-width: 768px) {
  /* Top Stat KPI Grid */
  .stat-grid.exp-rep-stat-grid,
  .stat-grid {
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 10px !important;
    margin-bottom: 16px !important;
  }
  .stat-card {
    padding: 12px 14px !important;
    border-radius: 12px !important;
  }
  .stat-card-top {
    gap: 8px !important;
  }
  .stat-label {
    font-size: 0.70rem !important;
  }
  .stat-number {
    font-size: 1.25rem !important;
  }
  .stat-icon-wrapper {
    width: 38px !important;
    height: 38px !important;
    font-size: 1.05rem !important;
    border-radius: 10px !important;
  }
  .stat-card-footer {
    font-size: 0.68rem !important;
    flex-wrap: wrap !important;
    gap: 4px !important;
    margin-top: 10px !important;
    padding-top: 8px !important;
  }

  /* Roaster Toolbar Card */
  .exp-rep-toolbar-card {
    padding: 12px 14px !important;
    margin-bottom: 14px !important;
    border-radius: 12px !important;
  }
  .exp-rep-toolbar-inner {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
  }
  .exp-rep-nav-links {
    display: grid !important;
    grid-template-columns: repeat(3, 1fr) !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .exp-rep-nav-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.76rem !important;
    padding: 0 8px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
  }
  .exp-rep-toolbar-actions {
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
    width: 100% !important;
    margin: 2px 0 0 0 !important;
  }
  .exp-rep-session-badge {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.78rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
  }
  .exp-rep-print-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.80rem !important;
    padding: 0 12px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
    margin: 0 !important;
  }

  /* Primary 2-Column Analytics Section */
  .exp-rep-main-grid {
    grid-template-columns: 1fr !important;
    gap: 16px !important;
    margin-bottom: 16px !important;
  }
  .exp-rep-card {
    border-radius: 12px !important;
  }
  .exp-rep-card-header {
    padding: 12px 14px !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
  }
  .exp-rep-card-title {
    font-size: 0.92rem !important;
  }
  .exp-rep-card-body {
    padding: 14px !important;
  }
  .exp-rep-cat-item {
    padding: 9px 11px !important;
    border-radius: 8px !important;
  }
  .exp-rep-cat-name {
    font-size: 0.82rem !important;
  }
  .exp-rep-cat-sub {
    font-size: 0.68rem !important;
  }
  .exp-rep-cat-amount {
    font-size: 0.84rem !important;
  }
  .exp-rep-cat-pct {
    font-size: 0.68rem !important;
  }

  /* Monthly Trend Table Wrap */
  .exp-rep-table-wrap {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
    width: 100% !important;
    margin: 0 !important;
  }
  .exp-rep-table {
    min-width: 540px !important;
  }
  .exp-rep-table thead th {
    padding: 9px 8px !important;
    font-size: 0.68rem !important;
  }
  .exp-rep-table tbody td {
    padding: 9px 8px !important;
    font-size: 0.78rem !important;
  }

  /* Bottom Row: Methods & Ledger */
  .exp-rep-bottom-grid {
    grid-template-columns: 1fr !important;
    gap: 16px !important;
    margin-bottom: 20px !important;
  }
  .exp-rep-methods-grid {
    padding: 14px !important;
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 10px !important;
  }
  .exp-rep-method-card {
    padding: 10px 12px !important;
  }
  .exp-rep-method-icon {
    width: 32px !important;
    height: 32px !important;
    font-size: 0.85rem !important;
  }
  .exp-rep-method-name {
    font-size: 0.80rem !important;
  }
  .exp-rep-method-amount {
    font-size: 0.85rem !important;
  }
  .exp-rep-ledger-wrap {
    padding: 12px 14px !important;
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
  }
  .exp-rep-ledger-table td {
    padding: 8px 6px !important;
  }
  .exp-rep-ledger-cell-title {
    font-size: 0.78rem !important;
  }
  .exp-rep-ledger-cell-val {
    font-size: 0.82rem !important;
  }
}

/* Mobile Screens (<= 480px) */
@media (max-width: 480px) {
  .exp-rep-nav-links {
    grid-template-columns: 1fr !important;
  }
  .exp-rep-methods-grid {
    grid-template-columns: 1fr !important;
  }
}

/* Micro Devices (<= 360px) */
@media (max-width: 360px) {
  .stat-grid.exp-rep-stat-grid,
  .stat-grid {
    grid-template-columns: 1fr !important;
  }
  .exp-rep-toolbar-actions {
    grid-template-columns: 1fr !important;
  }
}

/* ══════════════════════════════════════════════════════════════════════
   DARK THEME COMPREHENSIVE ADAPTATIONS FOR EXPENSE REPORT
   ══════════════════════════════════════════════════════════════════════ */

/* 1. Top KPI Stat Metrics Strip */
[data-theme="dark"] .stat-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
}
[data-theme="dark"] .stat-label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .stat-number {
  color: #f8fafc !important;
}
[data-theme="dark"] .stat-card.green .stat-number,
[data-theme="dark"] .stat-card .stat-number[style*="color: #059669"],
[data-theme="dark"] .stat-card .stat-number[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .stat-card.purple .stat-number,
[data-theme="dark"] .stat-card .stat-number[style*="color: #dc2626"],
[data-theme="dark"] .stat-card .stat-number[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .stat-card.blue .stat-number,
[data-theme="dark"] .stat-card .stat-number[style*="color: #7c3aed"],
[data-theme="dark"] .stat-card .stat-number[style*="color:#7c3aed"] {
  color: #a78bfa !important;
}
[data-theme="dark"] .stat-card.amber .stat-number,
[data-theme="dark"] .stat-card .stat-number[style*="color: #007cbd"],
[data-theme="dark"] .stat-card .stat-number[style*="color:#007cbd"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .stat-card-progress {
  background: #334155 !important;
}
[data-theme="dark"] .stat-card.green .stat-card-progress-bar {
  background: #34d399 !important;
}
[data-theme="dark"] .stat-card.purple .stat-card-progress-bar {
  background: #f87171 !important;
}
[data-theme="dark"] .stat-card.blue .stat-card-progress-bar {
  background: #a78bfa !important;
}
[data-theme="dark"] .stat-card.amber .stat-card-progress-bar {
  background: #38bdf8 !important;
}
[data-theme="dark"] .stat-card.green .stat-icon-wrapper {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border: 1px solid rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .stat-card.purple .stat-icon-wrapper {
  background: rgba(239, 68, 68, 0.15) !important;
  color: #f87171 !important;
  border: 1px solid rgba(239, 68, 68, 0.3) !important;
}
[data-theme="dark"] .stat-card.blue .stat-icon-wrapper {
  background: rgba(124, 58, 237, 0.15) !important;
  color: #a78bfa !important;
  border: 1px solid rgba(124, 58, 237, 0.3) !important;
}
[data-theme="dark"] .stat-card.amber .stat-icon-wrapper {
  background: rgba(0, 146, 223, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(0, 146, 223, 0.3) !important;
}
[data-theme="dark"] .stat-card-footer {
  border-top: 1px solid #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .stat-card-footer .text-muted {
  color: #94a3b8 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #059669"],
[data-theme="dark"] .stat-card-footer span[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #dc2626"],
[data-theme="dark"] .stat-card-footer span[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #7c3aed"],
[data-theme="dark"] .stat-card-footer span[style*="color:#7c3aed"] {
  color: #a78bfa !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #007cbd"],
[data-theme="dark"] .stat-card-footer span[style*="color:#007cbd"] {
  color: #38bdf8 !important;
}

/* 2. Subnavigation & Toolbar */
[data-theme="dark"] .exp-rep-toolbar-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
}
[data-theme="dark"] .exp-rep-nav-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .exp-rep-nav-btn:hover {
  background: #334155 !important;
  color: #f8fafc !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .exp-rep-nav-btn i.fa-file-invoice-dollar {
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-nav-btn i.fa-sitemap {
  color: #34d399 !important;
}
[data-theme="dark"] .exp-rep-nav-btn i.fa-hand-holding-dollar {
  color: #a78bfa !important;
}
[data-theme="dark"] .exp-rep-session-badge {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .exp-rep-session-badge strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-print-btn {
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}

/* 3. Cards & Headers */
[data-theme="dark"] .exp-rep-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25) !important;
}
[data-theme="dark"] .exp-rep-card-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .exp-rep-card-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-card-title i {
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-header-badge {
  background: #0f172a !important;
  color: #cbd5e1 !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
}

/* 4. Category-Wise Allocation */
[data-theme="dark"] .exp-rep-cat-item {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .exp-rep-cat-item:hover {
  background: #1e293b !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .exp-rep-cat-name {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-cat-sub {
  color: #94a3b8 !important;
}
[data-theme="dark"] .exp-rep-cat-amount {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-cat-pct {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  border-radius: 4px !important;
  -webkit-border-radius: 4px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-progress-track {
  background: #334155 !important;
}
[data-theme="dark"] .exp-rep-card-body .fa-folder-open {
  color: #64748b !important;
}

/* Category Icon Translucent Tint Adaptations */
[data-theme="dark"] .exp-rep-cat-icon {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 7px !important;
  -webkit-border-radius: 7px !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#b45309"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#fef3c7"] {
  background: rgba(245, 158, 11, 0.15) !important;
  color: #fbbf24 !important;
  border-color: rgba(245, 158, 11, 0.35) !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#0369a1"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#e0f2fe"] {
  background: rgba(2, 132, 199, 0.15) !important;
  color: #38bdf8 !important;
  border-color: rgba(2, 132, 199, 0.35) !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#7e22ce"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#f3e8ff"] {
  background: rgba(124, 58, 237, 0.15) !important;
  color: #c084fc !important;
  border-color: rgba(124, 58, 237, 0.35) !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#047857"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#ecfdf5"] {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border-color: rgba(16, 185, 129, 0.35) !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#c2410c"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#fff7ed"] {
  background: rgba(249, 115, 22, 0.15) !important;
  color: #fb923c !important;
  border-color: rgba(249, 115, 22, 0.35) !important;
}
[data-theme="dark"] .exp-rep-cat-icon[style*="#475569"],
[data-theme="dark"] .exp-rep-cat-icon[style*="#f1f5f9"] {
  background: rgba(148, 163, 184, 0.15) !important;
  color: #cbd5e1 !important;
  border-color: rgba(148, 163, 184, 0.35) !important;
}

/* 5. Monthly Expenditure Trend Table */
[data-theme="dark"] .staff-id-table thead th,
[data-theme="dark"] .exp-rep-table thead th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .staff-id-table tbody td,
[data-theme="dark"] .exp-rep-table tbody td {
  background: transparent !important;
  border-bottom: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .staff-id-table tbody tr:hover,
[data-theme="dark"] .exp-rep-table tbody tr:hover {
  background-color: rgba(51, 65, 85, 0.3) !important;
}
[data-theme="dark"] .exp-rep-month-cell {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-month-cell i {
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-vouchers-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .exp-rep-month-amount {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-avg-amount {
  color: #94a3b8 !important;
}
[data-theme="dark"] .exp-rep-share-badge {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  border-radius: 4px !important;
  -webkit-border-radius: 4px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-table td .fa-calendar-xmark {
  color: #64748b !important;
}

/* 6. Disbursement Channels & Modes */
[data-theme="dark"] .exp-rep-method-card {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .exp-rep-method-card:hover {
  background: #1e293b !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .exp-rep-method-name {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-method-sub {
  color: #94a3b8 !important;
}
[data-theme="dark"] .exp-rep-method-amount {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-method-pct {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  border-radius: 4px !important;
  -webkit-border-radius: 4px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .exp-rep-methods-grid p {
  color: #94a3b8 !important;
}

/* Payment Method Icon Translucent Tint Adaptations */
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#059669"],
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#ecfdf5"] {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border-color: rgba(16, 185, 129, 0.35) !important;
}
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#2563eb"],
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#eff6ff"] {
  background: rgba(37, 99, 235, 0.15) !important;
  color: #60a5fa !important;
  border-color: rgba(37, 99, 235, 0.35) !important;
}
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#7c3aed"],
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#f5f3ff"] {
  background: rgba(124, 58, 237, 0.15) !important;
  color: #a78bfa !important;
  border-color: rgba(124, 58, 237, 0.35) !important;
}
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#d97706"],
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#fffbeb"] {
  background: rgba(245, 158, 11, 0.15) !important;
  color: #fbbf24 !important;
  border-color: rgba(245, 158, 11, 0.35) !important;
}
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#64748b"],
[data-theme="dark"] .exp-rep-method-card .exp-rep-method-icon[style*="#f8fafc"] {
  background: rgba(148, 163, 184, 0.15) !important;
  color: #cbd5e1 !important;
  border-color: rgba(148, 163, 184, 0.35) !important;
}

/* 7. Executive Ledger Reconcilement Matrix */
[data-theme="dark"] .exp-rep-ledger-table td {
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .exp-rep-ledger-cell-title {
  color: #cbd5e1 !important;
}
[data-theme="dark"] .exp-rep-row-inflow i {
  color: #34d399 !important;
}
[data-theme="dark"] .exp-rep-row-inflow .exp-rep-ledger-cell-val {
  color: #34d399 !important;
}
[data-theme="dark"] .exp-rep-row-expense i {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-row-expense .exp-rep-ledger-cell-val {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-row-payroll i {
  color: #a78bfa !important;
}
[data-theme="dark"] .exp-rep-row-payroll .exp-rep-ledger-cell-val {
  color: #a78bfa !important;
}
[data-theme="dark"] .exp-rep-row-outflow {
  background: #0f172a !important;
}
[data-theme="dark"] .exp-rep-row-outflow .exp-rep-ledger-cell-title,
[data-theme="dark"] .exp-rep-row-outflow .exp-rep-ledger-cell-val {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-surplus {
  background: rgba(22, 101, 52, 0.25) !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-surplus .exp-rep-ledger-cell-val {
  color: #34d399 !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-deficit {
  background: rgba(220, 38, 38, 0.22) !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-deficit .exp-rep-ledger-cell-val {
  color: #f87171 !important;
}
[data-theme="dark"] .exp-rep-row-balance .exp-rep-ledger-cell-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .exp-rep-ledger-table tbody tr:hover {
  background-color: rgba(51, 65, 85, 0.3) !important;
}
[data-theme="dark"] .exp-rep-row-outflow:hover {
  background-color: #1e293b !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-surplus:hover {
  background-color: rgba(22, 101, 52, 0.35) !important;
}
[data-theme="dark"] .exp-rep-row-balance.is-deficit:hover {
  background-color: rgba(220, 38, 38, 0.32) !important;
}
</style>

<!-- ══════════════════════════════════════════════════════
     TOP KPI STAT METRICS GRID
     ══════════════════════════════════════════════════════ -->
<div class="stat-grid exp-rep-stat-grid no-print" style="margin-bottom: 24px;">
  
  <!-- Total Revenue (Fee Collections) -->
  <div class="stat-card green">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Fee Revenue (Collections)</span>
          <span class="stat-number" style="color: #059669;"><?php echo format_inr($total_fees); ?></span>
        </div>
        <div class="stat-icon-wrapper" style="background: rgba(16, 185, 129, 0.12); color: #10b981;">
          <i class="fa-solid fa-hand-holding-dollar"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%; background: #10b981;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span style="color: #059669; font-weight: 700;"><i class="fa-solid fa-arrow-trend-up"></i> Inflow Verified</span>
      <span class="text-muted">Session <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></span>
    </div>
  </div>

  <!-- Operational Expenses -->
  <div class="stat-card purple">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Operational Expenses</span>
          <span class="stat-number" style="color: #dc2626;"><?php echo format_inr($total_expenses); ?></span>
        </div>
        <div class="stat-icon-wrapper" style="background: rgba(239, 68, 68, 0.12); color: #dc2626;">
          <i class="fa-solid fa-receipt"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%; background: #dc2626;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span style="color: #dc2626; font-weight: 700;"><i class="fa-solid fa-file-invoice-dollar"></i> Disbursed Vouchers</span>
      <span class="text-muted">Bills, Labs &amp; Upkeep</span>
    </div>
  </div>

  <!-- Faculty & Staff Payroll -->
  <div class="stat-card blue">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Faculty &amp; Staff Payroll</span>
          <span class="stat-number" style="color: #7c3aed;"><?php echo format_inr($total_payroll); ?></span>
        </div>
        <div class="stat-icon-wrapper" style="background: rgba(124, 58, 237, 0.12); color: #7c3aed;">
          <i class="fa-solid fa-users-line"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%; background: #7c3aed;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span style="color: #7c3aed; font-weight: 700;"><i class="fa-solid fa-money-bill-wave"></i> Paid Staff Salaries</span>
      <span class="text-muted">Academic &amp; Admin</span>
    </div>
  </div>

  <!-- Net Operating Balance -->
  <div class="stat-card <?php echo $net_operating_balance >= 0 ? 'amber' : 'purple'; ?>">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Net Operating Balance</span>
          <span class="stat-number" style="color: <?php echo $net_operating_balance >= 0 ? '#007cbd' : '#dc2626'; ?>;">
            <?php echo format_inr($net_operating_balance); ?>
          </span>
        </div>
        <div class="stat-icon-wrapper" style="background: <?php echo $net_operating_balance >= 0 ? 'rgba(0, 146, 223, 0.12)' : 'rgba(239, 68, 68, 0.12)'; ?>; color: <?php echo $net_operating_balance >= 0 ? '#0092df' : '#dc2626'; ?>;">
          <i class="fa-solid fa-scale-balanced"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%; background: <?php echo $net_operating_balance >= 0 ? '#0092df' : '#dc2626'; ?>;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span style="color: <?php echo $net_operating_balance >= 0 ? '#007cbd' : '#dc2626'; ?>; font-weight: 700;">
        <i class="fa-solid <?php echo $net_operating_balance >= 0 ? 'fa-shield-halved' : 'fa-circle-exclamation'; ?>"></i> 
        <?php echo $net_operating_balance >= 0 ? 'Surplus Reserve' : 'Deficit Alert'; ?>
      </span>
      <span class="text-muted">Revenue &minus; Outflow</span>
    </div>
  </div>

</div>

<!-- ══════════════════════════════════════════════════════
     ROASTER TOOLBAR CARD & NAVIGATION
     ══════════════════════════════════════════════════════ -->
<div class="roaster-toolbar-card exp-rep-toolbar-card no-print" style="margin-bottom: 22px;">
  <div class="roaster-toolbar-inner exp-rep-toolbar-inner" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
    
    <!-- Left: Subnavigation Links -->
    <div class="exp-rep-nav-links" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
      <a href="<?php echo htmlspecialchars(ADMIN_URL . '/expenses', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary exp-rep-nav-btn" style="text-decoration: none; font-size: 0.82rem; gap: 6px;">
        <i class="fa-solid fa-file-invoice-dollar" style="color: #0092df;"></i>
        <span>Expenses &amp; Vouchers</span>
      </a>

      <a href="<?php echo htmlspecialchars(ADMIN_URL . '/expense-categories', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary exp-rep-nav-btn" style="text-decoration: none; font-size: 0.82rem; gap: 6px;">
        <i class="fa-solid fa-sitemap" style="color: #059669;"></i>
        <span>Expense Heads</span>
      </a>

      <a href="<?php echo htmlspecialchars(ADMIN_URL . '/fee-collection', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary exp-rep-nav-btn" style="text-decoration: none; font-size: 0.82rem; gap: 6px;">
        <i class="fa-solid fa-hand-holding-dollar" style="color: #7c3aed;"></i>
        <span>Fee Collections</span>
      </a>
    </div>

    <!-- Right: Session Badge -->
    <div class="roaster-toolbar-actions exp-rep-toolbar-actions">
      <div class="scholars-count-badge exp-rep-session-badge">
        <span class="count-dot" style="background: #10b981;"></span>
        <span>Session <strong><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong></span>
      </div>
    </div>

  </div>
</div>

<!-- ══════════════════════════════════════════════════════
     REPORT PRINTABLE / AUDIT CONTAINER
     ══════════════════════════════════════════════════════ -->
<div class="report-printable-area">
  
  <!-- Printable Official Header Banner -->
  <div class="print-header-banner">
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h1 style="margin: 0; font-size: 22px; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
          <?php echo htmlspecialchars($school_settings['school_name'] ?? 'KSV Academy', ENT_QUOTES, 'UTF-8'); ?>
        </h1>
        <p style="margin: 3px 0 0; font-size: 13px; color: #475569;">
          <?php echo htmlspecialchars($school_settings['address'] ?? 'Official Financial Audit & Expenditure Ledger Report', ENT_QUOTES, 'UTF-8'); ?>
        </p>
      </div>
      <div style="text-align: right;">
        <div style="font-size: 12px; font-weight: 700; color: #0284c7;">ACADEMIC AUDIT SESSION</div>
        <div style="font-size: 18px; font-weight: 800; color: #0f172a;"><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></div>
        <div style="font-size: 11px; color: #64748b;">Generated: <?php echo date('d M Y, h:i A'); ?></div>
      </div>
    </div>
  </div>

  <!-- Primary 2-Column Analytics Section -->
  <div class="exp-rep-main-grid" style="display: grid; grid-template-columns: 1.25fr 1.75fr; gap: 24px; margin-bottom: 24px;">
    
    <!-- Left Column: Category-Wise Allocation -->
    <div class="hrms-card exp-rep-card" style="border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
      <div class="hrms-card-header exp-rep-card-header" style="border-bottom: 1px solid #e2e8f0; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center;">
        <h4 class="exp-rep-card-title" style="margin: 0; font-size: 0.95rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 8px;">
          <i class="fa-solid fa-chart-pie" style="color: #0284c7;"></i>
          <span>Category-Wise Allocation</span>
        </h4>
        <span class="exp-rep-header-badge" style="font-size: 0.74rem; font-weight: 600; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
          <?php echo count($cat_breakdown); ?> Heads Active
        </span>
      </div>

      <div class="exp-rep-card-body" style="padding: 18px;">
        <?php if (empty($cat_breakdown)): ?>
          <div style="text-align: center; padding: 36px 12px; color: #94a3b8;">
            <i class="fa-solid fa-folder-open" style="font-size: 2rem; color: #cbd5e1; display: block; margin-bottom: 8px;"></i>
            <span style="font-size: 0.85rem;">No categorized expenses recorded in this session.</span>
          </div>
        <?php else: ?>
          <div class="exp-rep-cat-list" style="display: flex; flex-direction: column; gap: 12px;">
            <?php foreach ($cat_breakdown as $cb): ?>
              <?php 
                $pct = $total_expenses > 0 ? round(($cb['total_amount'] / $total_expenses) * 100, 1) : 0;
                $cat_style = get_report_cat_icon($cb['category_name']);
              ?>
              <div class="report-cat-item exp-rep-cat-item">
                <div class="exp-rep-cat-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                  <div class="exp-rep-cat-left" style="display: flex; align-items: center; gap: 9px; min-width: 0;">
                    <div class="exp-rep-cat-icon" style="width: 28px; height: 28px; border-radius: 7px; background: <?php echo htmlspecialchars($cat_style['bg'], ENT_QUOTES, 'UTF-8'); ?>; color: <?php echo htmlspecialchars($cat_style['color'], ENT_QUOTES, 'UTF-8'); ?>; border: 1px solid <?php echo htmlspecialchars($cat_style['border'], ENT_QUOTES, 'UTF-8'); ?>; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; flex-shrink: 0;">
                      <i class="fa-solid <?php echo htmlspecialchars($cat_style['icon'], ENT_QUOTES, 'UTF-8'); ?>"></i>
                    </div>
                    <div style="min-width: 0;">
                      <span class="exp-rep-cat-name" style="font-weight: 700; font-size: 0.88rem; color: #0f172a; font-family: 'Outfit', sans-serif;">
                        <?php echo htmlspecialchars($cb['category_name'], ENT_QUOTES, 'UTF-8'); ?>
                      </span>
                      <span class="exp-rep-cat-sub" style="font-size: 0.72rem; color: #64748b; margin-left: 6px;">
                        &bull; <?php echo intval($cb['vouchers_count']); ?> vouchers
                      </span>
                    </div>
                  </div>
                  <div class="exp-rep-cat-right" style="text-align: right; flex-shrink: 0;">
                    <strong class="exp-rep-cat-amount" style="color: #dc2626; font-size: 0.88rem; font-family: 'Outfit', sans-serif;">
                      <?php echo format_inr($cb['total_amount']); ?>
                    </strong>
                    <span class="exp-rep-cat-pct" style="display: inline-block; font-size: 0.72rem; font-weight: 700; color: #0284c7; background: #f0f9ff; border: 1px solid #bae6fd; padding: 1px 6px; border-radius: 4px; margin-left: 4px;">
                      <?php echo $pct; ?>%
                    </span>
                  </div>
                </div>

                <!-- Progress Bar -->
                <div class="report-progress-bar exp-rep-progress-track">
                  <div class="report-progress-fill" style="width: <?php echo min(100, max(2, $pct)); ?>%;"></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Right Column: Monthly Expenditure Trend -->
    <div class="hrms-card exp-rep-card" style="border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
      <div class="hrms-card-header exp-rep-card-header" style="border-bottom: 1px solid #e2e8f0; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center;">
        <h4 class="exp-rep-card-title" style="margin: 0; font-size: 0.95rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 8px;">
          <i class="fa-solid fa-calendar-days" style="color: #0284c7;"></i>
          <span>Monthly Expenditure Trend</span>
        </h4>
        <span class="exp-rep-header-badge" style="font-size: 0.74rem; font-weight: 600; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
          <?php echo count($monthly_expenses); ?> Months Recorded
        </span>
      </div>

      <div class="table-responsive exp-rep-table-wrap">
        <table class="hrms-table staff-id-table exp-rep-table">
          <thead>
            <tr>
              <th style="min-width: 130px;">Month &amp; Year</th>
              <th style="min-width: 90px; text-align: center;">Vouchers</th>
              <th style="min-width: 120px;">Total Disbursed (₹)</th>
              <th style="min-width: 100px;">Avg / Voucher</th>
              <th style="min-width: 70px; text-align: right;">Share</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($monthly_expenses)): ?>
              <tr>
                <td colspan="5" style="text-align: center; color: #94a3b8; padding: 40px 20px;">
                  <i class="fa-regular fa-calendar-xmark" style="font-size: 2rem; color: #cbd5e1; display: block; margin-bottom: 8px;"></i>
                  <span>No monthly expenditure vouchers recorded yet.</span>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($monthly_expenses as $me): ?>
                <?php 
                  $m_pct = $total_expenses > 0 ? round(($me['monthly_total'] / $total_expenses) * 100, 1) : 0;
                ?>
                <tr>
                  <td>
                    <div class="exp-rep-month-cell" style="font-weight: 700; font-size: 0.86rem; color: #0f172a; display: flex; align-items: center; gap: 7px;">
                      <i class="fa-regular fa-calendar" style="color: #0284c7; font-size: 0.72rem;"></i>
                      <span class="exp-rep-month-label"><?php echo htmlspecialchars($me['month_label'], ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                  </td>
                  <td style="text-align: center;">
                    <span class="exp-rep-vouchers-pill" style="display: inline-flex; align-items: center; gap: 4px; font-weight: 600; font-size: 0.74rem; background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; padding: 2px 8px; border-radius: 5px;">
                      <?php echo intval($me['voucher_count']); ?> vouchers
                    </span>
                  </td>
                  <td>
                    <strong class="exp-rep-month-amount" style="color: #dc2626; font-size: 0.88rem; font-family: 'Outfit', sans-serif;">
                      <?php echo format_inr($me['monthly_total']); ?>
                    </strong>
                  </td>
                  <td class="exp-rep-avg-amount" style="font-size: 0.82rem; color: #475569; font-weight: 500;">
                    <?php echo format_inr($me['monthly_total'] / max(1, $me['voucher_count'])); ?>
                  </td>
                  <td style="text-align: right;">
                    <span class="exp-rep-share-badge" style="font-size: 0.74rem; font-weight: 700; color: #0284c7; background: #f0f9ff; border: 1px solid #bae6fd; padding: 2px 7px; border-radius: 4px;">
                      <?php echo $m_pct; ?>%
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- Bottom Analytics Row: Payment Channel Distribution & Executive Audit Matrix -->
  <div class="exp-rep-bottom-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px; margin-bottom: 30px;">
    
    <!-- Payment Methods Breakdown -->
    <div class="hrms-card exp-rep-card" style="border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
      <div class="hrms-card-header exp-rep-card-header" style="border-bottom: 1px solid #e2e8f0; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center;">
        <h4 class="exp-rep-card-title" style="margin: 0; font-size: 0.95rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 8px;">
          <i class="fa-solid fa-credit-card" style="color: #0284c7;"></i>
          <span>Disbursement Channels &amp; Modes</span>
        </h4>
        <span class="exp-rep-header-badge" style="font-size: 0.74rem; font-weight: 600; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
          Voucher Settlement
        </span>
      </div>

      <div class="exp-rep-methods-grid" style="padding: 18px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
        <?php if (empty($method_breakdown)): ?>
          <p style="color: #94a3b8; font-size: 0.82rem; grid-column: 1 / -1; text-align: center; padding: 20px 0;">No disbursement mode data.</p>
        <?php else: ?>
          <?php foreach ($method_breakdown as $mb): ?>
            <?php 
              $m_info = get_method_icon($mb['payment_method']);
              $mb_pct = $total_expenses > 0 ? round(($mb['total_amount'] / $total_expenses) * 100, 1) : 0;
            ?>
            <div class="method-card exp-rep-method-card">
              <div class="method-icon-box exp-rep-method-icon" style="background: <?php echo htmlspecialchars($m_info['bg'], ENT_QUOTES, 'UTF-8'); ?>; color: <?php echo htmlspecialchars($m_info['color'], ENT_QUOTES, 'UTF-8'); ?>; border: 1px solid <?php echo htmlspecialchars($m_info['border'], ENT_QUOTES, 'UTF-8'); ?>;">
                <i class="fa-solid <?php echo htmlspecialchars($m_info['icon'], ENT_QUOTES, 'UTF-8'); ?>"></i>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                  <span class="exp-rep-method-name" style="font-size: 0.84rem; font-weight: 700; color: #0f172a;"><?php echo htmlspecialchars($mb['payment_method'], ENT_QUOTES, 'UTF-8'); ?></span>
                  <span class="exp-rep-method-pct" style="font-size: 0.72rem; font-weight: 700; color: #0284c7; background: #f0f9ff; border: 1px solid #bae6fd; padding: 1px 5px; border-radius: 4px;"><?php echo $mb_pct; ?>%</span>
                </div>
                <div class="exp-rep-method-amount" style="font-size: 0.90rem; font-weight: 700; color: #dc2626; font-family: 'Outfit', sans-serif; margin-top: 2px;">
                  <?php echo format_inr($mb['total_amount']); ?>
                </div>
                <div class="exp-rep-method-sub" style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">
                  <?php echo intval($mb['voucher_count']); ?> vouchers settled
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Executive Audit Summary Matrix -->
    <div class="hrms-card exp-rep-card" style="border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
      <div class="hrms-card-header exp-rep-card-header" style="border-bottom: 1px solid #e2e8f0; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center;">
        <h4 class="exp-rep-card-title" style="margin: 0; font-size: 0.95rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 8px;">
          <i class="fa-solid fa-file-contract" style="color: #0284c7;"></i>
          <span>Institutional Ledger Reconcilement</span>
        </h4>
        <span class="exp-rep-header-badge" style="font-size: 0.74rem; font-weight: 600; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
          Session <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>

      <div class="exp-rep-ledger-wrap" style="padding: 16px;">
        <table class="hrms-table staff-id-table exp-rep-ledger-table" style="width: 100%;">
          <tbody>
            <tr class="exp-rep-row-inflow">
              <td class="exp-rep-ledger-cell-title" style="color: #475569; font-size: 0.84rem;">
                <span style="display: inline-flex; align-items: center; gap: 8px;">
                  <i class="fa-solid fa-circle-check" style="color: #10b981; font-size: 0.75rem;"></i>
                  <span>Total Fee Realization (Inflow)</span>
                </span>
              </td>
              <td class="exp-rep-ledger-cell-val" style="text-align: right; font-weight: 700; color: #059669; font-family: 'Outfit', sans-serif; font-size: 0.88rem;">
                + <?php echo format_inr($total_fees); ?>
              </td>
            </tr>

            <tr class="exp-rep-row-expense">
              <td class="exp-rep-ledger-cell-title" style="color: #475569; font-size: 0.84rem;">
                <span style="display: inline-flex; align-items: center; gap: 8px;">
                  <i class="fa-solid fa-circle-minus" style="color: #ef4444; font-size: 0.75rem;"></i>
                  <span>Operational &amp; Maintenance Expenses</span>
                </span>
              </td>
              <td class="exp-rep-ledger-cell-val" style="text-align: right; font-weight: 700; color: #dc2626; font-family: 'Outfit', sans-serif; font-size: 0.88rem;">
                &minus; <?php echo format_inr($total_expenses); ?>
              </td>
            </tr>

            <tr class="exp-rep-row-payroll">
              <td class="exp-rep-ledger-cell-title" style="color: #475569; font-size: 0.84rem;">
                <span style="display: inline-flex; align-items: center; gap: 8px;">
                  <i class="fa-solid fa-circle-minus" style="color: #7c3aed; font-size: 0.75rem;"></i>
                  <span>Staff &amp; Faculty Net Salaries Disbursed</span>
                </span>
              </td>
              <td class="exp-rep-ledger-cell-val" style="text-align: right; font-weight: 700; color: #7c3aed; font-family: 'Outfit', sans-serif; font-size: 0.88rem;">
                &minus; <?php echo format_inr($total_payroll); ?>
              </td>
            </tr>

            <tr class="exp-rep-row-outflow" style="background: #f8fafc;">
              <td class="exp-rep-ledger-cell-title" style="font-weight: 600; color: #1e293b; font-size: 0.84rem;">
                Total Institutional Outflow
              </td>
              <td class="exp-rep-ledger-cell-val" style="text-align: right; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif; font-size: 0.88rem;">
                <?php echo format_inr($total_disbursed); ?>
              </td>
            </tr>

            <tr class="exp-rep-row-balance <?php echo $net_operating_balance >= 0 ? 'is-surplus' : 'is-deficit'; ?>" style="background: <?php echo $net_operating_balance >= 0 ? '#f0fdf4' : '#fef2f2'; ?>;">
              <td class="exp-rep-ledger-cell-title" style="font-weight: 700; font-size: 0.88rem; color: #0f172a; font-family: 'Outfit', sans-serif;">
                Net Operating Balance (Reserves)
              </td>
              <td class="exp-rep-ledger-cell-val" style="text-align: right; font-weight: 800; font-size: 0.98rem; color: <?php echo $net_operating_balance >= 0 ? '#166534' : '#dc2626'; ?>; font-family: 'Outfit', sans-serif;">
                <?php echo format_inr($net_operating_balance); ?>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- Printable Signatures / Audit Certification Section -->
  <div class="print-signatures">
    <div style="text-align: center; width: 180px;">
      <div style="border-bottom: 1px dashed #000000; height: 40px; margin-bottom: 8px;"></div>
      <div style="font-weight: 700; font-size: 12px;">Prepared By</div>
      <div style="font-size: 11px; color: #475569;">Senior Accountant</div>
    </div>

    <div style="text-align: center; width: 180px;">
      <div style="border-bottom: 1px dashed #000000; height: 40px; margin-bottom: 8px;"></div>
      <div style="font-weight: 700; font-size: 12px;">Verified &amp; Audited</div>
      <div style="font-size: 11px; color: #475569;">Bursar / Accounts Officer</div>
    </div>

    <div style="text-align: center; width: 180px;">
      <div style="border-bottom: 1px dashed #000000; height: 40px; margin-bottom: 8px;"></div>
      <div style="font-weight: 700; font-size: 12px;">Authorized Approval</div>
      <div style="font-size: 11px; color: #475569;">Director / Principal</div>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/layout-footer.php'; ?>
