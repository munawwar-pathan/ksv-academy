<?php
// Defense-in-depth HTTP security headers
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

require_once __DIR__ . '/../config.php';

$current_user = require_login(['super_admin', 'staff', 'parent', 'student']);
if ($current_user['role'] === 'staff') {
    require_menu_permission('admin_student_id');
}

// Method restriction / HTTP verb tampering defense
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

// Session-based rate limiting (Max 120 requests per minute)
$now = time();
if (!isset($_SESSION['student_id_req_attempts']) || !is_array($_SESSION['student_id_req_attempts'])) {
    $_SESSION['student_id_req_attempts'] = [];
}
$_SESSION['student_id_req_attempts'] = array_filter($_SESSION['student_id_req_attempts'], function($timestamp) use ($now) {
    return ($now - (int)$timestamp) < 60;
});
if (count($_SESSION['student_id_req_attempts']) >= 120) {
    http_response_code(429);
    exit('Rate limit exceeded. Please wait a moment before trying again.');
}
$_SESSION['student_id_req_attempts'][] = $now;

$page_title = 'Student ID Card | KSV Academy HRMS';
$page_heading = 'Student ID Card';
$page_subheading = 'Official Academic Identification Badge with Biometric QR Code';
$active_menu = 'student-id';

$db = get_db_connection();
$active_session = get_active_session();
$session_id = $active_session ? intval($active_session['id']) : 1;
$current_session_name = $active_session['session_name'] ?? (defined('CURRENT_SESSION') ? CURRENT_SESSION : date('Y'));
$school_settings = get_school_settings();

// Academic Standards & Specialized Course Categories (Matching Student Roaster & Attendance)
$academic_categories = get_default_academic_categories();
$flat_predefined_standards = [];
foreach ($academic_categories as $cat => $std_list) {
    foreach ($std_list as $s_item) {
        $flat_predefined_standards[] = $s_item;
    }
}
$db_standards = $db->query("SELECT DISTINCT standard FROM students WHERE session_id = " . intval($session_id) . " AND standard IS NOT NULL AND standard != ''")->fetchAll(PDO::FETCH_COLUMN) ?: [];
$standards = array_values(array_unique(array_filter(array_merge($flat_predefined_standards, $db_standards))));
$custom_db_standards = array_values(array_diff($db_standards, $flat_predefined_standards));

$search = mb_substr(trim($_GET['search'] ?? ''), 0, 100);
$raw_standard = trim($_GET['standard'] ?? '');
$filter_standard = ($raw_standard !== '' && $raw_standard !== 'all' && in_array($raw_standard, $standards, true)) ? $raw_standard : '';

// Get selected student ID
$selected_id = max(0, intval($_GET['id'] ?? 0));

// Resolve authorization for parent/student roles (Prevent IDOR & unauthorized directory browsing)
$is_parent_or_student = in_array($current_user['role'], ['student', 'parent'], true);
$allowed_student_ids = [];
if ($is_parent_or_student) {
    if ($current_user['role'] === 'student') {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    } else {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE parent_user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    }
    $allowed_student_ids = array_map('intval', $stmt_auth->fetchAll(PDO::FETCH_COLUMN));

    if ($selected_id > 0 && in_array($selected_id, $allowed_student_ids, true)) {
        // Allowed selected_id
    } elseif (!empty($allowed_student_ids)) {
        $selected_id = $allowed_student_ids[0];
    } else {
        $selected_id = 0;
    }
}

// Fetch students for dropdown list (Strictly scoped by session and user role, memory optimized)
if ($is_parent_or_student) {
    if (!empty($allowed_student_ids)) {
        $in_auth_ph = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $all_students_stmt = $db->prepare("
            SELECT id FROM students 
            WHERE session_id = ? AND id IN ($in_auth_ph)
            ORDER BY standard ASC, roll_no ASC, student_name ASC
        ");
        $all_students_stmt->execute(array_merge([$session_id], $allowed_student_ids));
        $all_students_list = $all_students_stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $all_students_list = [];
    }
} else {
    $all_students_stmt = $db->prepare("
        SELECT id FROM students 
        WHERE session_id = ? 
        ORDER BY standard ASC, roll_no ASC, student_name ASC
    ");
    $all_students_stmt->execute([$session_id]);
    $all_students_list = $all_students_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Pagination & Limits Setup (10, 20, 30, 40, 50)
$allowed_limits = [10, 20, 30, 40, 50];
$limit = intval($_GET['limit'] ?? 10);
if (!in_array($limit, $allowed_limits, true)) {
    $limit = 10;
}
$page = max(1, intval($_GET['page'] ?? 1));

// Build WHERE filter conditions
$where_clauses = ["session_id = ?"];
$where_params = [$session_id];

if ($is_parent_or_student) {
    if (!empty($allowed_student_ids)) {
        $in_auth_where = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $where_clauses[] = "id IN ($in_auth_where)";
        foreach ($allowed_student_ids as $aid) {
            $where_params[] = $aid;
        }
    } else {
        $where_clauses[] = "1=0";
    }
}

if ($search !== '') {
    $where_clauses[] = "(student_name LIKE ? OR roll_no LIKE ? OR admission_no LIKE ? OR parent_phone LIKE ?)";
    $search_like = addcslashes($search, '%_\\');
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
}

if ($filter_standard !== '') {
    $where_clauses[] = "standard = ?";
    $where_params[] = $filter_standard;
}

$where_sql = implode(' AND ', $where_clauses);

// Count total matching scholars
$count_stmt = $db->prepare("SELECT COUNT(*) FROM students WHERE {$where_sql}");
$count_stmt->execute($where_params);
$total_records = intval($count_stmt->fetchColumn());

// Calculate total pages & offset
$total_pages = max(1, (int)ceil($total_records / $limit));
if ($page > $total_pages) {
    $page = $total_pages;
}
$offset = ($page - 1) * $limit;

// Query students for the paginated table directory
$query = "SELECT * FROM students WHERE {$where_sql} ORDER BY standard ASC, roll_no ASC, student_name ASC LIMIT ? OFFSET ?";
$stmt_table = $db->prepare($query);
$bind_idx = 1;
foreach ($where_params as $val) {
    $stmt_table->bindValue($bind_idx++, $val);
}
$stmt_table->bindValue($bind_idx++, $limit, PDO::PARAM_INT);
$stmt_table->bindValue($bind_idx++, $offset, PDO::PARAM_INT);
$stmt_table->execute();
$table_students = $stmt_table->fetchAll();

// Pagination indicators
$start_record = $total_records > 0 ? $offset + 1 : 0;
$end_record = min($offset + $limit, $total_records);

// Helper for generating student ID directory pagination links
function get_student_id_pagination_url($target_page, $search, $filter_standard, $selected_id, $limit) {
    $params = [];
    $selected_id = intval($selected_id);
    $target_page = intval($target_page);
    $limit = intval($limit);
    if ($selected_id > 0) $params['id'] = $selected_id;
    if (!empty($search)) $params['search'] = $search;
    if (!empty($filter_standard)) $params['standard'] = $filter_standard;
    if ($limit !== 10) $params['limit'] = $limit;
    if ($target_page > 1) $params['page'] = $target_page;
    return ADMIN_URL . '/student-id' . (!empty($params) ? '?' . http_build_query($params) : '') . '#studentIdDirectoryCard';
}

// Default selected student:
if ($selected_id === 0) {
    if (!empty($table_students)) {
        $selected_id = intval($table_students[0]['id']);
    } elseif (!empty($all_students_list)) {
        $selected_id = intval($all_students_list[0]['id']);
    }
}

// Active navigation list for Prev / Next card switcher
if ($search !== '' || $filter_standard !== '') {
    $nav_stmt = $db->prepare("SELECT id FROM students WHERE {$where_sql} ORDER BY standard ASC, roll_no ASC, student_name ASC");
    $nav_stmt->execute($where_params);
    $nav_list = $nav_stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $nav_list = $all_students_list;
}

// Find current student index for Previous / Next navigation
$current_index = 0;
foreach ($nav_list as $idx => $s_item) {
    if (intval($s_item['id']) === $selected_id) {
        $current_index = $idx;
        break;
    }
}
$prev_student_id = ($current_index > 0 && isset($nav_list[$current_index - 1])) ? intval($nav_list[$current_index - 1]['id']) : null;
$next_student_id = ($current_index < count($nav_list) - 1 && isset($nav_list[$current_index + 1])) ? intval($nav_list[$current_index + 1]['id']) : null;

// Fetch selected student details (Enforcing session and authorization)
$student = null;
if ($selected_id > 0) {
    if ($is_parent_or_student) {
        if (in_array($selected_id, $allowed_student_ids, true)) {
            $stmt = $db->prepare("SELECT * FROM students WHERE id = ? AND session_id = ? LIMIT 1");
            $stmt->execute([$selected_id, $session_id]);
            $student = $stmt->fetch();
        }
    } else {
        $stmt = $db->prepare("SELECT * FROM students WHERE id = ? AND session_id = ? LIMIT 1");
        $stmt->execute([$selected_id, $session_id]);
        $student = $stmt->fetch();
        if (!$student) {
            $stmt = $db->prepare("SELECT * FROM students WHERE id = ? LIMIT 1");
            $stmt->execute([$selected_id]);
            $student = $stmt->fetch();
        }
    }
    if (!$student) {
        $selected_id = 0;
    }
}

/**
 * Safely resolves and validates a student profile photo path.
 * Supports /web-app/uploads/students/, /uploads/students/, /assets/imgs/students/ etc.
 * Excludes default placeholder logos (/assets/imgs/ksv-logo.jpg).
 * Protects against path traversal attacks.
 *
 * @param string|null $photo_path
 * @return string|false Web-accessible URL or false if invalid/not found
 */
if (!function_exists('resolve_student_photo_url')) {
    function resolve_student_photo_url($photo_path) {
        if (empty($photo_path) || !is_string($photo_path)) {
            return false;
        }
        $trimmed = trim($photo_path);
        // Exclude generic placeholder logo
        if ($trimmed === '/assets/imgs/ksv-logo.jpg' || $trimmed === 'assets/imgs/ksv-logo.jpg') {
            return false;
        }

        $clean_rel = ltrim($trimmed, '/\\');
        
        // Allowed safe directory bases on disk
        $allowed_bases = array_filter([
            realpath(__DIR__ . '/../uploads'),
            realpath(__DIR__ . '/../../uploads'),
            realpath(__DIR__ . '/../../assets'),
            realpath(__DIR__ . '/../assets')
        ]);

        // Candidate paths to check on disk
        $candidates = [
            realpath(__DIR__ . '/../../' . $clean_rel),
            realpath(__DIR__ . '/../' . $clean_rel),
            realpath(__DIR__ . '/../../web-app/' . $clean_rel)
        ];

        foreach ($candidates as $cand) {
            if ($cand && file_exists($cand) && is_file($cand)) {
                foreach ($allowed_bases as $base) {
                    $base_prefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
                    if (strpos($cand, $base_prefix) === 0) {
                        $root_path = realpath(__DIR__ . '/../..');
                        if ($root_path && strpos($cand, $root_path) === 0) {
                            $web_rel = substr($cand, strlen($root_path));
                            return '/' . ltrim(str_replace('\\', '/', $web_rel), '/');
                        }
                        return '/' . $clean_rel;
                    }
                }
            }
        }
        return false;
    }
}

// Check student photo with directory traversal protection
$student_photo_url = resolve_student_photo_url($student['photo'] ?? null);
$has_student_photo = !empty($student_photo_url);

// Generate sanitized QR Code data string (STU-{id}-{roll_no})
$raw_qr = $student ? ($student['qr_code'] ?: ('STU-' . $student['roll_no'])) : 'KSV-STUDENT';
$qr_data = preg_replace('/[^a-zA-Z0-9_\-\.\:\/]/', '', (string)$raw_qr);
if (empty($qr_data)) {
    $qr_data = 'KSV-' . intval($selected_id);
}
$qr_image_url = get_qr_code_url($qr_data, '220x220');

// Validity date
$valid_date_str = (!empty($active_session) && !empty($active_session['end_date'])) ? date('d M Y', strtotime($active_session['end_date'])) : ('31 MAR ' . (((int)date('Y')) + 1));

// Avatar gradient fallback
$first_letter = $student ? strtoupper(substr($student['student_name'], 0, 1)) : 'S';
$grad_palette = [
    'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)',
    'linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)',
    'linear-gradient(135deg, #059669 0%, #047857 100%)',
    'linear-gradient(135deg, #d97706 0%, #b45309 100%)',
    'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
];
$avatar_bg = $grad_palette[ord($first_letter) % count($grad_palette)];

require_once __DIR__ . '/../includes/layout-header.php';
?>

<!-- html2canvas for High-Resolution Card Export -->
<script src="<?php echo HRMS_URL; ?>/assets/js/html2canvas.min.js"></script>

<style>
/* ── Premium PVC Student ID Card Styles ── */
.id-card-stage {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  gap: 40px;
  flex-wrap: wrap;
  padding: 10px 0 30px;
}

.id-badge-holder {
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* Simulated Lanyard Clip at top */
.lanyard-clip {
  width: 48px;
  height: 24px;
  background: linear-gradient(180deg, #94a3b8 0%, #64748b 100%);
  border-radius: 6px 6px 0 0;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
  position: relative;
  z-index: 5;
  margin-bottom: -10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.lanyard-clip::after {
  content: '';
  width: 20px;
  height: 6px;
  background: #334155;
  border-radius: 3px;
}

/* Card Physical Dimension (Standard CR80 Ratio 85.6mm x 54mm) */
.pvc-card {
  width: 326px;
  min-height: 512px;
  background: #ffffff;
  border-radius: 18px;
  box-shadow: 0 20px 45px -10px rgba(15, 23, 42, 0.2), 0 0 0 1px rgba(15, 23, 42, 0.08);
  overflow: hidden;
  position: relative;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.3s ease;
  user-select: none;
}
.pvc-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 28px 55px -12px rgba(0, 146, 223, 0.25), 0 0 0 1px rgba(0, 146, 223, 0.2);
}

/* Top Lanyard Punch Slot */
.card-lanyard-slot {
  width: 44px;
  height: 10px;
  background: #f1f5f9;
  border: 1.5px solid #cbd5e1;
  border-radius: 8px;
  margin: 10px auto 0;
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.12);
  position: relative;
  z-index: 4;
}

/* Card Front Header Banner */
.card-front-header {
  background: linear-gradient(135deg, #0f172a 0%, #0092df 65%, #0284c7 100%);
  color: #ffffff;
  padding: 10px 16px 38px;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.card-front-header::before {
  content: '';
  position: absolute;
  top: -40px;
  right: -40px;
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  pointer-events: none;
}
.card-front-header::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 24px;
  background: #ffffff;
  clip-path: ellipse(56% 100% at 50% 100%);
}

.cf-logo-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}
.cf-logo-wrap {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  background: #ffffff;
  padding: 2.5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
}
.cf-logo-wrap img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  border-radius: 7px;
}
.cf-brand-name {
  font-family: 'Outfit', sans-serif;
  font-size: 16px;
  font-weight: 900;
  letter-spacing: 0.02em;
  color: #ffffff;
  line-height: 1.15;
}
.cf-sub-tag {
  font-size: 8.5px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: rgba(255, 255, 255, 0.85);
  font-weight: 700;
  margin-top: 2px;
}

.cf-session-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: rgba(15, 23, 42, 0.35);
  backdrop-filter: blur(4px);
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 8.5px;
  font-weight: 800;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin-top: 6px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

/* Photo and Smart Chip Row */
.cf-photo-container {
  position: relative;
  margin-top: -38px;
  z-index: 5;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.cf-smart-chip {
  position: absolute;
  top: 14px;
  left: 20px;
  width: 32px;
  height: 24px;
  background: linear-gradient(135deg, #fcd34d 0%, #f59e0b 50%, #d97706 100%);
  border-radius: 5px;
  border: 1px solid #b45309;
  box-shadow: inset 0 1px 2px rgba(255, 255, 255, 0.6), 0 2px 4px rgba(0,0,0,0.15);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  color: #78350f;
}

.cf-photo-frame {
  width: 98px;
  height: 98px;
  border-radius: 50%;
  border: 4px solid #ffffff;
  box-shadow: 0 6px 16px rgba(0, 146, 223, 0.28);
  background: #f8fafc;
  overflow: hidden;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}
.cf-photo-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.cf-photo-fallback {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 38px;
  font-weight: 900;
  font-family: 'Outfit', sans-serif;
}

/* Card Front Body Details */
.card-front-body {
  padding: 8px 20px 14px;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.cf-student-name {
  margin: 6px 0 2px;
  font-size: 17px;
  font-weight: 900;
  color: #0f172a;
  font-family: 'Outfit', sans-serif;
  letter-spacing: -0.01em;
  text-align: center;
}
.cf-standard-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #e0f2fe;
  color: #0284c7;
  padding: 3px 12px;
  border-radius: 12px;
  font-size: 10.5px;
  font-weight: 800;
  letter-spacing: 0.02em;
  margin-bottom: 12px;
  border: 1px solid #bae6fd;
}

/* Key Value Table */
.cf-info-list {
  width: 100%;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  overflow: hidden;
  background: #f8fafc;
  margin-bottom: 10px;
}
.cf-info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 10px;
  font-size: 11px;
  border-bottom: 1px solid #eef2f6;
}
.cf-info-row:last-child {
  border-bottom: none;
}
.cf-label {
  color: #64748b;
  font-weight: 700;
  font-size: 9.5px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.cf-val {
  color: #0f172a;
  font-weight: 700;
  text-align: right;
}
.cf-val.mono {
  font-family: monospace;
  font-size: 11.5px;
  color: #0284c7;
  font-weight: 800;
}
.cf-blood-badge {
  background: #fee2e2;
  color: #dc2626;
  padding: 1px 6px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 800;
}

/* Card Front Sign & Validity Footer */
.cf-footer {
  width: 100%;
  margin-top: auto;
  padding-top: 8px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  border-top: 1.5px dashed #e2e8f0;
}
.cf-valid-box {
  text-align: left;
}
.cf-valid-lbl {
  font-size: 8px;
  color: #94a3b8;
  font-weight: 800;
  text-transform: uppercase;
}
.cf-valid-val {
  font-size: 10px;
  font-weight: 800;
  color: #334155;
  font-family: monospace;
}
.cf-sign-box {
  text-align: right;
}
.cf-sign-img {
  font-family: 'Outfit', cursive;
  font-size: 13px;
  font-weight: 800;
  color: #0284c7;
  letter-spacing: 0.5px;
}
.cf-sign-lbl {
  font-size: 8px;
  color: #94a3b8;
  font-weight: 800;
  text-transform: uppercase;
  border-top: 1px solid #cbd5e1;
  padding-top: 2px;
}

/* ── Card Back Styles ── */
.card-back-header {
  background: #0f172a;
  color: #ffffff;
  padding: 12px 14px 10px;
  text-align: center;
  position: relative;
}
.cb-title {
  font-size: 10px;
  font-weight: 900;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: #38bdf8;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.card-back-body {
  padding: 14px 18px 12px;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

/* QR Code Container */
.cb-qr-frame {
  padding: 8px;
  background: #ffffff;
  border: 2px solid #0092df;
  border-radius: 12px;
  box-shadow: 0 4px 14px rgba(0, 146, 223, 0.2);
  margin-top: 4px;
}
.cb-qr-frame img {
  width: 140px;
  height: 140px;
  display: block;
  border-radius: 4px;
}
.cb-qr-code-text {
  font-family: monospace;
  font-size: 12px;
  font-weight: 800;
  color: #0284c7;
  margin-top: 6px;
  letter-spacing: 0.05em;
}
.cb-qr-hint {
  font-size: 9.5px;
  color: #64748b;
  margin: 3px 0 10px;
  font-weight: 600;
}

/* Instructions Box */
.cb-instructions {
  width: 100%;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 9.5px;
  color: #475569;
  text-align: left;
  line-height: 1.45;
  margin-bottom: 8px;
}
.cb-instructions strong {
  color: #0f172a;
  font-size: 9px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  display: block;
  margin-bottom: 3px;
}
.cb-instructions ol {
  margin: 0;
  padding-left: 14px;
}

/* Card Back Contact Footer */
.cb-footer {
  width: 100%;
  margin-top: auto;
  padding-top: 8px;
  border-top: 1px solid #e2e8f0;
  font-size: 9.5px;
  color: #64748b;
  line-height: 1.35;
}
.cb-footer strong {
  color: #0f172a;
  font-size: 10px;
}

/* ── Student ID Directory Table & Badge Styles (Simple & Sober - Like staff-id) ── */
.student-id-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}
.student-id-table thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 0.73rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
.student-id-table tbody td {
  padding: 11px 12px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
  font-size: 0.84rem;
}
.student-id-table tbody tr {
  transition: background-color 0.15s ease;
}
.student-id-table tbody tr:hover {
  background-color: #f8fafc;
}
.student-id-table tbody tr.active-student-row {
  background-color: #f0f9ff !important;
}
.student-id-table tbody tr.active-student-row td:first-child {
  border-left: 3px solid #0284c7;
}

/* Badge & Tag Elements */
.sid-roll-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  color: #0284c7;
  padding: 2px 7px;
  border-radius: 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.74rem;
  font-weight: 700;
  white-space: nowrap;
}
.sid-std-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.75rem;
  font-weight: 600;
}
.sid-blood-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
  font-size: 0.70rem;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  white-space: nowrap;
}
.sid-qr-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 3px 8px;
  border-radius: 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.73rem;
  font-weight: 600;
  white-space: nowrap;
}
.sid-status-active {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f0f9ff;
  color: #0284c7;
  border: 1px solid #bae6fd;
  font-size: 0.74rem;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 20px;
  white-space: nowrap;
}
.sid-status-active .pulse-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #0284c7;
  box-shadow: 0 0 0 0 rgba(2, 132, 199, 0.7);
  animation: pulse-ring 1.8s infinite;
}
@keyframes pulse-ring {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(2, 132, 199, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(2, 132, 199, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(2, 132, 199, 0); }
}
.sid-status-verified {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f0fdf4;
  color: #166534;
  border: 1px solid #bbf7d0;
  font-size: 0.74rem;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 20px;
  white-space: nowrap;
}
.sid-btn-action {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 12px;
  font-size: 0.76rem;
  font-weight: 600;
  border-radius: 6px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.sid-btn-secondary {
  color: #334155;
  background: #ffffff;
  border: 1px solid #cbd5e1;
}
.sid-btn-secondary:hover {
  background: #f8fafc;
  border-color: #94a3b8;
  color: #0f172a;
}

/* ── Print Setup for CR80 Standard ID Card ── */
@media print {
  body * {
    visibility: hidden;
  }
  .id-card-printable-area, .id-card-printable-area * {
    visibility: visible;
  }
  .id-card-printable-area {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    display: flex !important;
    justify-content: center;
    gap: 30px;
    padding: 20px;
    background: #ffffff !important;
  }
  .lanyard-clip, .card-label-badge {
    display: none !important;
  }
  .pvc-card {
    box-shadow: none !important;
    border: 1px solid #94a3b8 !important;
    break-inside: avoid;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }
  .no-print {
    display: none !important;
  }
}

/* ══════════════════════════════════════════════════════════════════════
   RESPONSIVE MOBILE VIEW ENHANCEMENTS FOR STUDENT ID
   ══════════════════════════════════════════════════════════════════════ */

/* Tablet & Mobile Screens (<= 768px) */
@media (max-width: 768px) {
  /* Top Toolbar */
  .roaster-toolbar-card {
    padding: 12px 14px !important;
    margin-bottom: 14px !important;
    border-radius: 12px !important;
  }
  .roaster-toolbar-inner {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 12px !important;
  }
  .roaster-toolbar-inner > div:first-child {
    width: 100% !important;
  }
  .roaster-toolbar-inner h3 {
    font-size: 0.98rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .id-card-actions-wrap {
    width: 100% !important;
    display: flex !important;
    flex-direction: column !important;
    gap: 8px !important;
  }
  .id-card-download-group {
    width: 100% !important;
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
  }
  .id-card-download-group .roaster-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.78rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
  }
  .id-card-print-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.82rem !important;
    padding: 0 14px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    margin: 0 !important;
  }
  .id-card-print-btn .btn-icon-circle {
    width: 22px !important;
    height: 22px !important;
    font-size: 0.72rem !important;
  }

  /* PVC Card Stage */
  .id-card-stage {
    gap: 24px !important;
    padding: 6px 0 24px !important;
  }

  /* Filter Toolbar Above Directory */
  .roaster-filter-form {
    flex-direction: column !important;
    align-items: stretch !important;
    width: 100% !important;
    gap: 8px !important;
  }
  .roaster-search-box {
    width: 100% !important;
    max-width: 100% !important;
    min-width: 0 !important;
    box-sizing: border-box !important;
    height: 40px !important;
    padding: 8px 12px !important;
    border-radius: 9px !important;
  }
  .student-id-filter-row {
    display: grid !important;
    grid-template-columns: 1fr auto !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .student-id-filter-row .roaster-select-box {
    width: 100% !important;
    min-width: 0 !important;
  }
  .student-id-filter-row .roaster-select-box select {
    width: 100% !important;
    min-width: 0 !important;
    height: 40px !important;
    font-size: 0.80rem !important;
    border-radius: 9px !important;
    padding: 8px 24px 8px 28px !important;
  }
  .student-id-filter-row .roaster-btn.secondary {
    height: 40px !important;
    font-size: 0.80rem !important;
    padding: 0 16px !important;
    justify-content: center !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
  }
  .student-id-filter-row .roaster-btn.ghost {
    grid-column: 1 / -1 !important;
    width: 100% !important;
    height: 34px !important;
    font-size: 0.78rem !important;
    justify-content: center !important;
    border-radius: 8px !important;
  }
  .roaster-toolbar-actions {
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
    width: 100% !important;
    margin: 2px 0 0 0 !important;
  }
  .scholars-count-badge {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.78rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
  }
  .roaster-link-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.80rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
    margin: 0 !important;
    display: inline-flex !important;
    align-items: center !important;
  }

  /* Directory Card Header */
  .student-id-directory-card {
    border-radius: 12px !important;
    margin-bottom: 20px !important;
  }
  .directory-card-header {
    padding: 12px 14px !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
  }
  .directory-title-block {
    width: 100% !important;
  }
  .directory-title-block .card-title {
    font-size: 0.95rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .directory-title-block p {
    font-size: 0.74rem !important;
    line-height: 1.4 !important;
  }
  .directory-records-count {
    width: 100% !important;
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    padding-top: 8px !important;
    border-top: 1px dashed #e2e8f0 !important;
    font-size: 0.75rem !important;
  }

  /* Table & Scrolling */
  .table-responsive {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
    width: 100% !important;
    margin: 0 !important;
  }
  .student-id-table {
    min-width: 900px !important;
  }
  .student-id-table thead th {
    padding: 9px 8px !important;
    font-size: 0.68rem !important;
  }
  .student-id-table tbody td {
    padding: 9px 8px !important;
    font-size: 0.78rem !important;
  }
  .student-id-table tbody td .user-cell {
    gap: 8px !important;
  }
  .student-id-table tbody td .user-cell img,
  .student-id-table tbody td .user-cell .staff-avatar-init {
    width: 34px !important;
    height: 34px !important;
    font-size: 13px !important;
  }
  .sid-btn-action {
    padding: 4px 8px !important;
    font-size: 0.70rem !important;
  }

  /* Pagination Controls */
  .pagination-controls-wrap {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 12px !important;
    padding: 12px 14px !important;
  }
  .pagination-meta-group {
    flex-direction: column !important;
    align-items: flex-start !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .pagination-limit-box {
    width: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
  }
  .pagination-limit-select {
    padding: 4px 8px !important;
    font-size: 0.75rem !important;
    height: 30px !important;
  }
  .pagination-nav {
    display: flex !important;
    justify-content: center !important;
    width: 100% !important;
    margin: 2px 0 !important;
  }
  .pagination-btn {
    min-width: 32px !important;
    height: 32px !important;
    font-size: 0.74rem !important;
    padding: 0 4px !important;
  }
  .pagination-controls-wrap > div:last-child {
    margin-left: 0 !important;
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    font-size: 0.74rem !important;
    text-align: center !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
  }
}

/* Mobile Phones (<= 576px) */
@media (max-width: 576px) {
  .id-card-stage {
    gap: 20px !important;
  }
  .id-badge-holder {
    width: 100% !important;
    max-width: min(326px, 100%) !important;
  }
  .pvc-card {
    width: min(326px, 100%) !important;
    max-width: 100% !important;
    border-radius: 16px !important;
  }
  .cf-val {
    word-break: break-word;
  }
}

/* Micro Phones (<= 360px) */
@media (max-width: 360px) {
  .id-card-download-group {
    grid-template-columns: 1fr !important;
  }
  .student-id-filter-row {
    grid-template-columns: 1fr !important;
  }
  .roaster-toolbar-actions {
    grid-template-columns: 1fr !important;
  }
  .pvc-card {
    border-radius: 14px !important;
  }
  .card-front-header {
    padding: 8px 12px 34px !important;
  }
  .card-front-body {
    padding: 6px 14px 12px !important;
  }
  .card-back-body {
    padding: 10px 14px 10px !important;
  }
}

/* ══════════════════════════════════════════════════════════════════════
   DARK THEME COMPREHENSIVE ADAPTATIONS FOR STUDENT ID
   ══════════════════════════════════════════════════════════════════════ */
[data-theme="dark"] .roaster-toolbar-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3) !important;
}
[data-theme="dark"] .roaster-toolbar-card h3,
[data-theme="dark"] .roaster-toolbar-card h3 span {
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-toolbar-card h3 span[style*="background: #f0f9ff"],
[data-theme="dark"] .roaster-toolbar-card h3 span[style*="background:#f0f9ff"] {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.35) !important;
  border-radius: 6px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .roaster-toolbar-card h3 span[style*="background: #f8fafc"],
[data-theme="dark"] .roaster-toolbar-card h3 span[style*="background:#f8fafc"] {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  color: #cbd5e1 !important;
}

/* Search Box with Radius Fix */
[data-theme="dark"] .roaster-search-box {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-search-box:focus-within {
  background: #0f172a !important;
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-search-box i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-search-box input {
  background: transparent !important;
  border: none !important;
  outline: none !important;
  box-shadow: none !important;
  border-radius: 0 !important;
  -webkit-border-radius: 0 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-search-box input::placeholder {
  color: #64748b !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn {
  background: #334155 !important;
  color: #94a3b8 !important;
  border-radius: 50% !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn:hover {
  background: #475569 !important;
  color: #f8fafc !important;
}

/* Select Box with Radius Fix */
[data-theme="dark"] .roaster-select-box {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-select-box > i:first-child,
[data-theme="dark"] .roaster-select-box .select-chevron {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-select-box select {
  background: #0f172a !important;
  border: none !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] .roaster-select-box select:focus {
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-select-box select option,
[data-theme="dark"] .roaster-select-box select optgroup {
  background: #0f172a !important;
  color: #f8fafc !important;
}

/* Toolbar Buttons */
[data-theme="dark"] .roaster-btn,
[data-theme="dark"] .roaster-btn.secondary {
  background: #334155 !important;
  color: #f1f5f9 !important;
  border: 1px solid #475569 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-btn.secondary:hover {
  background: #475569 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}
[data-theme="dark"] .roaster-add-btn {
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-link-btn {
  background: #334155 !important;
  border: 1px solid #475569 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #f1f5f9 !important;
}
[data-theme="dark"] .roaster-link-btn:hover {
  background: #475569 !important;
  border-color: #64748b !important;
  color: #ffffff !important;
}
[data-theme="dark"] .roaster-btn.ghost {
  color: #94a3b8 !important;
  background: transparent !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-btn.ghost:hover {
  color: #f87171 !important;
  background: rgba(239, 68, 68, 0.15) !important;
}

/* Live Counts Badge */
[data-theme="dark"] .scholars-count-badge {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .scholars-count-badge strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .scholars-count-badge .count-dot {
  background: #10b981 !important;
  box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7) !important;
}

/* Lanyard Clip & PVC Card Stage */
[data-theme="dark"] .lanyard-clip {
  background: linear-gradient(180deg, #475569 0%, #334155 100%) !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5) !important;
}
[data-theme="dark"] .lanyard-clip::after {
  background: #0f172a !important;
}
[data-theme="dark"] .pvc-card {
  box-shadow: 0 20px 45px -10px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.08) !important;
}
[data-theme="dark"] .pvc-card:hover {
  box-shadow: 0 28px 55px -12px rgba(2, 132, 199, 0.35), 0 0 0 1px rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] .card-label-badge {
  background: #1e293b !important;
  color: #94a3b8 !important;
  border: 1px solid #334155 !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
}

/* Directory Card & Header */
[data-theme="dark"] .student-id-directory-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3) !important;
}
[data-theme="dark"] .directory-card-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .directory-title-block .card-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .directory-session-badge {
  background: #0f172a !important;
  color: #cbd5e1 !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
}
[data-theme="dark"] .directory-title-block p {
  color: #94a3b8 !important;
}
[data-theme="dark"] .directory-title-block p strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .directory-records-count {
  border-top-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .directory-records-count strong,
[data-theme="dark"] .directory-records-count strong[style*="color: #0f172a"],
[data-theme="dark"] .directory-records-count strong[style*="color:#0f172a"] {
  color: #f8fafc !important;
}

/* Directory Table */
[data-theme="dark"] .student-id-table thead th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .student-id-table tbody td {
  background: transparent !important;
  border-bottom: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .student-id-table tbody tr:hover {
  background-color: rgba(51, 65, 85, 0.3) !important;
}
[data-theme="dark"] .student-id-table tbody tr.active-student-row {
  background-color: rgba(2, 132, 199, 0.15) !important;
}
[data-theme="dark"] .student-id-table tbody tr.active-student-row td:first-child {
  border-left: 3px solid #38bdf8 !important;
}
[data-theme="dark"] .student-id-table tbody td .user-cell > div > div:first-child,
[data-theme="dark"] .student-id-table tbody td div[style*="color: #0f172a"],
[data-theme="dark"] .student-id-table tbody td div[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .student-id-table tbody td div[style*="color: #64748b"],
[data-theme="dark"] .student-id-table tbody td div[style*="color:#64748b"],
[data-theme="dark"] .student-id-table tbody td div[style*="color: #94a3b8"],
[data-theme="dark"] .student-id-table tbody td div[style*="color:#94a3b8"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .student-id-table tbody td div[style*="color: #64748b"] i,
[data-theme="dark"] .student-id-table tbody td div[style*="color:#64748b"] i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .student-id-table tbody td div[style*="color: #334155"],
[data-theme="dark"] .student-id-table tbody td div[style*="color:#334155"] {
  color: #f1f5f9 !important;
}
[data-theme="dark"] .student-id-table tbody td .staff-avatar-img {
  border-color: #334155 !important;
}
[data-theme="dark"] .student-id-table tbody td .staff-avatar-init,
[data-theme="dark"] .student-id-table tbody td .user-cell .staff-avatar-init {
  background: #334155 !important;
  color: #f8fafc !important;
  border-color: #475569 !important;
}

/* Badges & Chips */
[data-theme="dark"] .sid-std-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-std-pill i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .sid-roll-pill {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-blood-badge {
  background: rgba(225, 29, 72, 0.15) !important;
  border: 1px solid rgba(225, 29, 72, 0.3) !important;
  border-radius: 4px !important;
  -webkit-border-radius: 4px !important;
  color: #fb7185 !important;
}
[data-theme="dark"] .sid-qr-chip {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-qr-chip i {
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-status-verified {
  background: rgba(22, 101, 52, 0.2) !important;
  border: 1px solid rgba(22, 101, 52, 0.4) !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
  color: #4ade80 !important;
}
[data-theme="dark"] .sid-status-active {
  background: rgba(2, 132, 199, 0.2) !important;
  border: 1px solid rgba(2, 132, 199, 0.4) !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-status-active .pulse-dot {
  background: #38bdf8 !important;
}

/* Action Buttons in Directory Table */
[data-theme="dark"] .sid-btn-action,
[data-theme="dark"] .sid-btn-secondary {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-btn-secondary:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .sid-btn-action[style*="background: #f0f9ff"],
[data-theme="dark"] .sid-btn-action[style*="background:#f0f9ff"] {
  background: rgba(2, 132, 199, 0.2) !important;
  border-color: rgba(2, 132, 199, 0.4) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-btn-action[style*="background: #f0f9ff"]:hover,
[data-theme="dark"] .sid-btn-action[style*="background:#f0f9ff"]:hover {
  background: rgba(2, 132, 199, 0.3) !important;
  border-color: #38bdf8 !important;
  color: #ffffff !important;
}

/* Pagination Controls & Footer */
[data-theme="dark"] .pagination-controls-wrap {
  background: #1e293b !important;
  border-top: 1px solid #334155 !important;
}
[data-theme="dark"] .pagination-meta-group span,
[data-theme="dark"] .pagination-meta-group span[style*="color: #475569"],
[data-theme="dark"] .pagination-meta-group span[style*="color:#475569"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-meta-group strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-limit-box label,
[data-theme="dark"] .pagination-limit-box label[style*="color: #64748b"],
[data-theme="dark"] .pagination-limit-box label[style*="color:#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-limit-select {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] .pagination-limit-select option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .pagination-btn:hover:not(.disabled) {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn.active {
  background: var(--hrms-primary, #0092df) !important;
  border-color: var(--hrms-primary, #0092df) !important;
  color: #ffffff !important;
}
[data-theme="dark"] .pagination-btn.disabled {
  background: #0f172a !important;
  border-color: #1e293b !important;
  color: #475569 !important;
  opacity: 0.5 !important;
}
[data-theme="dark"] .pagination-ellipsis {
  color: #64748b !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong,
[data-theme="dark"] .pagination-controls-wrap > div:last-child span strong[style*="color: #334155"],
[data-theme="dark"] .pagination-controls-wrap > div:last-child span strong[style*="color:#334155"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child span[style*="color: #cbd5e1"],
[data-theme="dark"] .pagination-controls-wrap > div:last-child span[style*="color:#cbd5e1"] {
  color: #475569 !important;
}

/* Empty States */
[data-theme="dark"] .student-id-table tbody td div[style*="background: #f1f5f9"],
[data-theme="dark"] .student-id-table tbody td div[style*="background:#f1f5f9"] {
  background: #0f172a !important;
  color: #64748b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .student-id-table tbody td h4[style*="color: #0f172a"],
[data-theme="dark"] .student-id-table tbody td h4[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .student-id-table tbody td p[style*="color: #64748b"] strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-card h3[style*="color: #0f172a"],
[data-theme="dark"] .hrms-card h3[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-card div[style*="color: #cbd5e1"],
[data-theme="dark"] .hrms-card div[style*="color:#cbd5e1"] {
  color: #475569 !important;
}

</style>

<!-- ══════════════════════════════════════════════════════
     STUDENT ID CARD TOP TOOLBAR & ACTION BAR
     ══════════════════════════════════════════════════════ -->
<?php
  // Build query string to preserve search & filter
  $qp_filter = [];
  if (!empty($search)) $qp_filter['search'] = $search;
  if (!empty($filter_standard)) $qp_filter['standard'] = $filter_standard;
  if ($limit !== 10) $qp_filter['limit'] = intval($limit);
  if ($page > 1) $qp_filter['page'] = intval($page);
  $filter_qs = !empty($qp_filter) ? '&' . http_build_query($qp_filter) : '';
  $prev_card_url = $prev_student_id ? (ADMIN_URL . '/student-id?id=' . intval($prev_student_id) . $filter_qs . '#id-card-stage') : '#';
  $next_card_url = $next_student_id ? (ADMIN_URL . '/student-id?id=' . intval($next_student_id) . $filter_qs . '#id-card-stage') : '#';
?>
<div class="roaster-toolbar-card no-print" style="margin-bottom: 22px;">
  <div class="roaster-toolbar-inner" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
    
    <!-- Left: Selected Student Label -->
    <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
      <h3 style="margin: 0; font-size: 1.08rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 8px;">
        <i class="fa-solid fa-id-card" style="color: var(--hrms-primary);"></i>
        <span><?php echo htmlspecialchars($student['student_name'] ?? 'Student', ENT_QUOTES, 'UTF-8'); ?></span>
        <span style="font-size: 0.78rem; font-weight: 800; color: #0284c7; background: #f0f9ff; border: 1px solid #bae6fd; padding: 2px 8px; border-radius: 6px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;" title="Roll Number">
          <?php echo htmlspecialchars($student['roll_no'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <span style="font-size: 0.78rem; font-weight: 700; color: #0369a1; background: #e0f2fe; border: 1px solid #bae6fd; padding: 2px 8px; border-radius: 6px;" title="Database Student ID">
          ID: #<?php echo intval($student['id']); ?>
        </span>
        <span style="font-size: 0.78rem; font-weight: 700; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 9px; border-radius: 6px;">
          <?php echo htmlspecialchars($student['standard'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </h3>

      <!-- Prev / Next Student Card Switcher -->
      <div style="display: inline-flex; align-items: center; gap: 4px; margin-left: 6px;">
        <a href="<?php echo htmlspecialchars($prev_card_url, ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary" style="padding: 0 10px; height: 30px; font-size: 0.75rem; <?php echo !$prev_student_id ? 'opacity: 0.45; pointer-events: none;' : ''; ?>" title="Previous Student Card">
          <i class="fa-solid fa-chevron-left"></i>
        </a>
        <a href="<?php echo htmlspecialchars($next_card_url, ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary" style="padding: 0 10px; height: 30px; font-size: 0.75rem; <?php echo !$next_student_id ? 'opacity: 0.45; pointer-events: none;' : ''; ?>" title="Next Student Card">
          <i class="fa-solid fa-chevron-right"></i>
        </a>
      </div>
    </div>

    <!-- Right: Print and Download Actions -->
    <div class="id-card-actions-wrap" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
      
      <div class="id-card-download-group" style="display: flex; gap: 8px;">
        <!-- Download Front PNG -->
        <button type="button" onclick="downloadCardImage('card_front_element', 'Front');" class="roaster-btn secondary" style="gap: 6px;" title="Save Front Card as High-Resolution Image">
          <i class="fa-solid fa-download"></i>
          <span>Front (PNG)</span>
        </button>

        <!-- Download Back PNG -->
        <button type="button" onclick="downloadCardImage('card_back_element', 'Back');" class="roaster-btn secondary" style="gap: 6px;" title="Save Back Card with QR Code as High-Resolution Image">
          <i class="fa-solid fa-download"></i>
          <span>Back (PNG)</span>
        </button>
      </div>

      <!-- Print Both Sides -->
      <button type="button" onclick="window.print();" class="roaster-add-btn id-card-print-btn" style="gap: 8px;" title="Print official ID card (Front & Back)">
        <div class="btn-icon-circle"><i class="fa-solid fa-print"></i></div>
        <span>Print ID Card</span>
      </button>

    </div>

  </div>
</div>

<?php if ($student): ?>
  <!-- ══════════════════════════════════════════════════════
       ID CARD STAGE: FRONT & BACK SIDES WITH LANYARDS
       ══════════════════════════════════════════════════════ -->
  <div class="id-card-printable-area id-card-stage" id="id-card-stage">
    
    <!-- ── CARD FRONT ── -->
    <div class="id-badge-holder">
      <div class="lanyard-clip no-print"></div>
      
      <div class="pvc-card" id="card_front_element">
        
        <!-- Punch Slot -->
        <div class="card-lanyard-slot"></div>

        <!-- Header Banner -->
        <div class="card-front-header">
          <div class="cf-logo-row">
            <div class="cf-logo-wrap">
              <img src="<?php echo htmlspecialchars($school_settings['logo_url'] ?? '/assets/imgs/ksv-logo.jpg', ENT_QUOTES, 'UTF-8'); ?>" alt="Logo" onerror="this.src='/assets/imgs/ksv-logo.jpg'">
            </div>
            <div>
              <div class="cf-brand-name"><?php echo htmlspecialchars($school_settings['school_name'] ?? 'KSV Academy', ENT_QUOTES, 'UTF-8'); ?></div>
              <div class="cf-sub-tag">Academic Excellence &amp; HRMS</div>
            </div>
          </div>
          <div class="cf-session-pill">
            <i class="fa-solid fa-graduation-cap"></i>
            <span>Identity Card &bull; Session <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>

        <!-- Student Photo & Smart Chip -->
        <div class="cf-photo-container">
          <!-- Gold Metallic Smart Chip -->
          <div class="cf-smart-chip" title="Biometric Smart Badge">
            <i class="fa-solid fa-microchip"></i>
          </div>

          <!-- Photo Frame -->
          <div class="cf-photo-frame">
            <?php if ($has_student_photo): ?>
              <img src="<?php echo htmlspecialchars($student_photo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($student['student_name'], ENT_QUOTES, 'UTF-8'); ?>" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
              <div class="cf-photo-fallback" style="background: <?php echo $avatar_bg; ?>; display: none;">
                <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
              </div>
            <?php else: ?>
              <div class="cf-photo-fallback" style="background: <?php echo $avatar_bg; ?>;">
                <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Student Profile Details -->
        <div class="card-front-body">
          <h3 class="cf-student-name">
            <?php echo htmlspecialchars($student['student_name'], ENT_QUOTES, 'UTF-8'); ?>
          </h3>
          <div class="cf-standard-badge">
            <i class="fa-solid fa-book-open" style="font-size: 9px;"></i>
            <span><?php echo htmlspecialchars($student['standard'], ENT_QUOTES, 'UTF-8'); ?> &bull; Sec <?php echo htmlspecialchars($student['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?></span>
          </div>

          <!-- Info List -->
          <div class="cf-info-list">
            <div class="cf-info-row">
              <span class="cf-label">Roll Number</span>
              <span class="cf-val mono"><?php echo htmlspecialchars($student['roll_no'], ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="cf-info-row">
              <span class="cf-label">Admission No</span>
              <span class="cf-val"><?php echo htmlspecialchars($student['admission_no'] ?? ('ADM-' . $student['id']), ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="cf-info-row">
              <span class="cf-label">Guardian</span>
              <span class="cf-val"><?php echo htmlspecialchars($student['parent_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="cf-info-row">
              <span class="cf-label">Emergency Ph</span>
              <span class="cf-val"><?php echo htmlspecialchars($student['parent_phone'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="cf-info-row">
              <span class="cf-label">Blood Group</span>
              <span class="cf-val">
                <span class="cf-blood-badge"><?php echo htmlspecialchars($student['blood_group'] ?? 'O+', ENT_QUOTES, 'UTF-8'); ?></span>
              </span>
            </div>
            <div class="cf-info-row">
              <span class="cf-label">Date of Birth</span>
              <span class="cf-val"><?php echo format_date($student['dob']); ?></span>
            </div>
          </div>

          <!-- Footer: Validity & Principal Sign -->
          <div class="cf-footer">
            <div class="cf-valid-box">
              <div class="cf-valid-lbl">Valid Till</div>
              <div class="cf-valid-val"><?php echo htmlspecialchars($valid_date_str, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
            <div class="cf-sign-box">
              <div class="cf-sign-img">Salam Khan</div>
              <div class="cf-sign-lbl">Principal Signature</div>
            </div>
          </div>

        </div>

      </div>

      <div class="card-label-badge no-print" style="margin-top: 12px; font-size: 0.76rem; font-weight: 800; color: #64748b; background: #e2e8f0; padding: 4px 14px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.05em;">
        Front Side View
      </div>
    </div>

    <!-- ── CARD BACK (Biometric Scannable QR Code) ── -->
    <div class="id-badge-holder">
      <div class="lanyard-clip no-print"></div>

      <div class="pvc-card" id="card_back_element">
        
        <!-- Punch Slot -->
        <div class="card-lanyard-slot"></div>

        <!-- Back Header Band -->
        <div class="card-back-header">
          <div class="cb-title">
            <i class="fa-solid fa-qrcode"></i>
            <span>Biometric QR Attendance Pass</span>
          </div>
        </div>

        <!-- Back Body -->
        <div class="card-back-body">
          
          <!-- High-Resolution Scannable QR Frame -->
          <div class="cb-qr-frame">
            <img id="back_qr_img" src="<?php echo htmlspecialchars($qr_image_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Biometric QR Code" crossorigin="anonymous">
          </div>

          <div class="cb-qr-code-text">
            <?php echo htmlspecialchars($qr_data, ENT_QUOTES, 'UTF-8'); ?>
          </div>
          <div class="cb-qr-hint">
            Scan via KSV Academy Biometric Camera to punch daily attendance.
          </div>

          <!-- Rules & Terms -->
          <div class="cb-instructions">
            <strong>Campus Rules &amp; Regulations:</strong>
            <ol>
              <li>This identity badge is mandatory on campus at all times.</li>
              <li>Present this card for library, lab, and examination entry.</li>
              <li>Non-transferable. Valid only for <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?>.</li>
              <li>If lost or damaged, report to admin office immediately.</li>
            </ol>
          </div>

          <!-- Campus Contact & Return Address -->
          <div class="cb-footer">
            <strong><?php echo htmlspecialchars($school_settings['school_name'] ?? 'KSV Academy', ENT_QUOTES, 'UTF-8'); ?></strong><br>
            <?php echo htmlspecialchars($school_settings['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?><br>
            Emergency: <strong><?php echo htmlspecialchars($school_settings['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?></strong>
          </div>

        </div>

      </div>

      <div class="card-label-badge no-print" style="margin-top: 12px; font-size: 0.76rem; font-weight: 800; color: #64748b; background: #e2e8f0; padding: 4px 14px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.05em;">
        Back Side View (QR Pass)
      </div>
    </div>

  </div>



  <!-- ══════════════════════════════════════════════════════
       FILTER TOOLBAR (Exact match to students.php)
       ══════════════════════════════════════════════════════ -->
  <div class="roaster-toolbar-card no-print" style="margin-top: 24px; margin-bottom: 20px;">
    <div class="roaster-toolbar-inner">
      
      <!-- Filter form -->
      <form method="GET" action="<?php echo htmlspecialchars(ADMIN_URL . '/student-id', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-filter-form">
        <input type="hidden" name="limit" value="<?php echo intval($limit); ?>">
        <?php if ($selected_id > 0): ?>
          <input type="hidden" name="id" value="<?php echo intval($selected_id); ?>">
        <?php endif; ?>

        <div class="roaster-search-box">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" name="search" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search name, roll no, phone..." autocomplete="off">
          <?php if (!empty($search)): ?>
            <a href="<?php echo htmlspecialchars(get_student_id_pagination_url(1, '', $filter_standard, $selected_id, $limit), ENT_QUOTES, 'UTF-8'); ?>" class="clear-search-btn" title="Clear search">&times;</a>
          <?php endif; ?>
        </div>

        <div class="student-id-filter-row" style="display: flex; gap: 8px; align-items: center;">
          <div class="roaster-select-box">
            <i class="fa-solid fa-filter"></i>
            <select name="standard" onchange="this.form.submit()" style="min-width: 175px; max-width: 250px; font-weight: 600; text-overflow: ellipsis;">
              <option value="">All Academic Standards</option>
              <?php echo render_standards_dropdown_options($filter_standard, false, $academic_categories, $custom_db_standards); ?>
            </select>
            <i class="fa-solid fa-chevron-down select-chevron"></i>
          </div>

          <button type="submit" class="roaster-btn secondary">
            <i class="fa-solid fa-sliders"></i> Filter
          </button>

          <?php if (!empty($search) || !empty($filter_standard)): ?>
            <?php 
              $rp = [];
              if ($selected_id > 0) $rp['id'] = intval($selected_id);
              if ($limit !== 10) $rp['limit'] = intval($limit);
              $reset_filter_url = ADMIN_URL . '/student-id' . (!empty($rp) ? '?' . http_build_query($rp) : '');
            ?>
            <a href="<?php echo htmlspecialchars($reset_filter_url, ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn ghost" title="Reset all filters">
              <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
          <?php endif; ?>
        </div>
      </form>

      <!-- Right: Scholars Live Count & Link to Roster -->
      <div class="roaster-toolbar-actions">
        <div class="scholars-count-badge">
          <span class="count-dot"></span>
          <span><strong><?php echo $total_records; ?></strong> Scholars</span>
        </div>

        <?php if (!$is_parent_or_student): ?>
          <a href="<?php echo htmlspecialchars(ADMIN_URL . '/students', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary roaster-link-btn" style="text-decoration: none; font-size: 0.82rem; gap: 6px;">
            <i class="fa-solid fa-users"></i>
            <span>Student Roaster</span>
          </a>
        <?php endif; ?>
      </div>

    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       STUDENT DATA TABLE (Simple & Sober - Like staff-id.php)
       ══════════════════════════════════════════════════════ -->
  <div class="hrms-card no-print student-id-directory-card" id="studentIdDirectoryCard" style="margin-bottom: 30px; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
    <div class="hrms-card-header directory-card-header" style="border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 16px 20px;">
      <div class="directory-title-block">
        <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 1rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif;">
          <i class="fa-solid fa-id-card-clip" style="color: #0284c7;"></i>
          Student ID Card Directory
          <span class="directory-session-badge" style="font-size: 0.74rem; font-weight: 600; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
            Session <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?>
          </span>
        </h3>
        <p style="margin: 3px 0 0; font-size: 0.78rem; color: #64748b;">
          Click <strong>View ID Card</strong> on any student row below to load their official PVC badge with biometric QR pass.
        </p>
      </div>
      <div class="directory-records-count" style="font-size: 0.78rem; color: #64748b; font-weight: 600;">
        <span>Total Records: <strong style="color: #0f172a;"><?php echo $total_records; ?></strong></span>
      </div>
    </div>

    <div class="table-responsive">
      <table class="hrms-table student-id-table">
        <thead>
          <tr>
            <th style="min-width: 160px;">Student Profile</th>
            <th style="min-width: 110px;">Roll &amp; Admission</th>
            <th style="min-width: 120px;">Standard &amp; Section</th>
            <th style="min-width: 115px;">Guardian Info</th>
            <th style="min-width: 120px;">Biometric QR Pass</th>
            <th style="min-width: 90px;">Card Status</th>
            <th style="min-width: 115px; text-align: right;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($table_students)): ?>
            <tr>
              <td colspan="7" style="text-align: center; padding: 50px 20px; color: #64748b;">
                <div style="width: 52px; height: 52px; border-radius: 50%; background: #f1f5f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; font-size: 1.4rem; color: #94a3b8;">
                  <i class="fa-solid fa-user-slash"></i>
                </div>
                <h4 style="font-size: 1rem; font-weight: 800; color: #0f172a; margin-bottom: 4px; font-family: 'Outfit', sans-serif;">No Scholars Matching Filters</h4>
                <p style="font-size: 0.82rem; color: #64748b; margin: 0 0 14px;">
                  No student records matched your query in Session <strong><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong>.
                </p>
                <a href="<?php echo htmlspecialchars(ADMIN_URL . '/student-id' . ($selected_id > 0 ? '?id=' . intval($selected_id) : ''), ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary" style="display: inline-flex; text-decoration: none;">
                  <i class="fa-solid fa-rotate-left"></i> Reset All Filters
                </a>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($table_students as $stu): ?>
              <?php 
                $is_cur_viewing = (intval($stu['id']) === $selected_id);
                $stu_photo_url = resolve_student_photo_url($stu['photo'] ?? null);
                $stu_has_photo = !empty($stu_photo_url);
                $first_letter = strtoupper(substr($stu['student_name'] ?? 'S', 0, 1));

                $stu_raw_qr = $stu['qr_code'] ?: ('STU-' . ($stu['roll_no'] ?? $stu['id']));
                $stu_qr_code = preg_replace('/[^a-zA-Z0-9_\-\.\:\/]/', '', (string)$stu_raw_qr);

                $switch_params = ['id' => intval($stu['id'])];
                if ($search !== '') $switch_params['search'] = $search;
                if ($filter_standard !== '') $switch_params['standard'] = $filter_standard;
                if ($limit !== 10) $switch_params['limit'] = intval($limit);
                if ($page > 1) $switch_params['page'] = intval($page);
                $switch_url = ADMIN_URL . '/student-id?' . http_build_query($switch_params) . '#id-card-stage';
              ?>
              <tr class="<?php echo $is_cur_viewing ? 'active-student-row' : ''; ?>">
                
                <!-- 1. Student Profile -->
                <td>
                  <div class="user-cell" style="display: flex; align-items: center; gap: 12px;">
                    <?php if ($stu_has_photo): ?>
                      <img src="<?php echo htmlspecialchars($stu_photo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($stu['student_name'], ENT_QUOTES, 'UTF-8'); ?>" class="staff-avatar-img" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1.5px solid #e2e8f0; flex-shrink: 0;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                      <div class="staff-avatar-init" style="width: 40px; height: 40px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 15px; border: 1px solid #e2e8f0; display: none; align-items: center; justify-content: center; flex-shrink: 0;">
                        <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
                      </div>
                    <?php else: ?>
                      <div class="staff-avatar-init" style="width: 40px; height: 40px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 15px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
                      </div>
                    <?php endif; ?>

                    <div>
                      <div style="font-weight: 700; color: #0f172a; font-size: 0.90rem; font-family: 'Outfit', sans-serif; line-height: 1.25; display: flex; align-items: center; gap: 6px;">
                        <span><?php echo htmlspecialchars($stu['student_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                        <span style="font-size: 0.70rem; font-weight: 700; color: #0284c7; background: #f0f9ff; border: 1px solid #bae6fd; padding: 1px 6px; border-radius: 4px;" title="Student ID">#<?php echo intval($stu['id']); ?></span>
                      </div>
                      <div style="font-size: 0.74rem; color: #64748b; margin-top: 2px; display: flex; align-items: center; gap: 6px;">
                        <span><?php echo htmlspecialchars($stu['gender'] ?? 'Scholar', ENT_QUOTES, 'UTF-8'); ?></span>
                        <span>&bull;</span>
                        <span class="sid-blood-badge">Blood: <?php echo htmlspecialchars($stu['blood_group'] ?? 'O+', ENT_QUOTES, 'UTF-8'); ?></span>
                      </div>
                    </div>
                  </div>
                </td>

                <!-- 2. Roll & Admission -->
                <td>
                  <span class="sid-roll-pill">
                    <i class="fa-solid fa-hashtag" style="font-size: 0.62rem;"></i>
                    <span><?php echo htmlspecialchars($stu['roll_no'], ENT_QUOTES, 'UTF-8'); ?></span>
                  </span>
                  <div style="font-size: 0.74rem; color: #64748b; margin-top: 4px;">
                    Adm: <?php echo htmlspecialchars($stu['admission_no'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                  <div style="font-size: 0.72rem; color: #0284c7; font-weight: 600; margin-top: 3px;">
                    ID: #<?php echo intval($stu['id']); ?>
                  </div>
                </td>

                <!-- 3. Standard & Section -->
                <td>
                  <span class="sid-std-pill">
                    <i class="fa-solid fa-graduation-cap" style="font-size: 0.65rem; color: #64748b;"></i>
                    <span><?php echo htmlspecialchars($stu['standard'], ENT_QUOTES, 'UTF-8'); ?></span>
                  </span>
                  <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 4px;">
                    Section <?php echo htmlspecialchars($stu['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                </td>

                <!-- 4. Guardian Info -->
                <td>
                  <div style="font-size: 0.78rem; font-weight: 600; color: #334155;">
                    <?php echo htmlspecialchars($stu['parent_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                  <div style="font-size: 0.74rem; color: #64748b; margin-top: 3px; display: inline-flex; align-items: center; gap: 5px;">
                    <i class="fa-solid fa-phone" style="font-size: 0.65rem; color: #64748b;"></i>
                    <span><?php echo htmlspecialchars($stu['parent_phone'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></span>
                  </div>
                </td>

                <!-- 5. Biometric QR Pass -->
                <td>
                  <span class="sid-qr-chip" title="Biometric QR Pass ID">
                    <i class="fa-solid fa-qrcode" style="color: #0284c7; font-size: 0.72rem;"></i>
                    <span><?php echo htmlspecialchars($stu_qr_code, ENT_QUOTES, 'UTF-8'); ?></span>
                  </span>
                </td>

                <!-- 6. Card Status -->
                <td>
                  <?php if ($is_cur_viewing): ?>
                    <span class="sid-status-active">
                      <span class="pulse-dot"></span> In Preview
                    </span>
                  <?php else: ?>
                    <span class="sid-status-verified">
                      <i class="fa-solid fa-check" style="font-size: 0.68rem;"></i> Enrolled
                    </span>
                  <?php endif; ?>
                </td>

                <!-- 7. Actions -->
                <td style="text-align: right;">
                  <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center;">
                    <?php if ($is_cur_viewing): ?>
                      <button type="button" onclick="document.getElementById('id-card-stage').scrollIntoView({behavior: 'smooth'});" class="sid-btn-action sid-btn-secondary" style="background: #f0f9ff; border-color: #bae6fd; color: #0284c7;" title="Currently loaded into preview">
                        <i class="fa-solid fa-eye" style="font-size: 0.72rem;"></i>
                        <span>Viewing</span>
                      </button>
                      <button type="button" onclick="window.print();" class="sid-btn-action sid-btn-secondary" title="Print this Card">
                        <i class="fa-solid fa-print" style="color: #0284c7; font-size: 0.72rem;"></i>
                        <span>Print</span>
                      </button>
                    <?php else: ?>
                      <a href="<?php echo htmlspecialchars($switch_url, ENT_QUOTES, 'UTF-8'); ?>" class="sid-btn-action sid-btn-secondary" title="Load student card into preview">
                        <i class="fa-solid fa-id-card" style="color: #0284c7; font-size: 0.72rem;"></i>
                        <span>View ID Card</span>
                      </a>
                    <?php endif; ?>
                  </div>
                </td>

              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Table Pagination & Per-Page Controls -->
    <div class="pagination-controls-wrap">
      
      <!-- Left: Showing summary & Limit Selector -->
      <div class="pagination-meta-group">
        <span style="font-size: 0.82rem; color: #475569;">
          <?php if ($total_records > 0): ?>
            Showing <strong><?php echo $start_record; ?></strong>–<strong><?php echo $end_record; ?></strong> of <strong><?php echo $total_records; ?></strong> scholars
          <?php else: ?>
            Showing <strong>0</strong> scholars
          <?php endif; ?>
        </span>

        <div class="pagination-limit-box">
          <label for="perPageLimitSelect" style="color: #64748b; font-size: 0.8rem; margin: 0; font-weight: 500;">Show Per Page</label>
          <select id="perPageLimitSelect" class="pagination-limit-select" onchange="window.location.href = this.value;">
            <?php foreach ($allowed_limits as $l): ?>
              <option value="<?php echo htmlspecialchars(get_student_id_pagination_url(1, $search, $filter_standard, $selected_id, $l), ENT_QUOTES, 'UTF-8'); ?>" <?php echo $limit === $l ? 'selected' : ''; ?>>
                <?php echo $l; ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <!-- Center/Right: Navigation page buttons -->
      <?php if ($total_pages > 1): ?>
        <nav class="pagination-nav" aria-label="Student ID Directory Pagination">
          <!-- Prev Page -->
          <a href="<?php echo $page > 1 ? htmlspecialchars(get_student_id_pagination_url($page - 1, $search, $filter_standard, $selected_id, $limit), ENT_QUOTES, 'UTF-8') : '#'; ?>" 
             class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" 
             aria-label="Previous Page"
             title="Previous Page">
            <i class="fa-solid fa-chevron-left" style="font-size: 0.72rem;"></i>
          </a>

          <!-- Page Numbers -->
          <?php
            $range = 2;
            for ($p = 1; $p <= $total_pages; $p++):
              if ($p == 1 || $p == $total_pages || ($p >= $page - $range && $p <= $page + $range)):
          ?>
            <a href="<?php echo htmlspecialchars(get_student_id_pagination_url($p, $search, $filter_standard, $selected_id, $limit), ENT_QUOTES, 'UTF-8'); ?>" 
               class="pagination-btn <?php echo $p === $page ? 'active' : ''; ?>">
              <?php echo $p; ?>
            </a>
          <?php 
              elseif (($p == 2 && $page - $range > 2) || ($p == $total_pages - 1 && $page + $range < $total_pages - 1)):
          ?>
            <span class="pagination-ellipsis">&hellip;</span>
          <?php 
              endif;
            endfor;
          ?>

          <!-- Next Page -->
          <a href="<?php echo $page < $total_pages ? htmlspecialchars(get_student_id_pagination_url($page + 1, $search, $filter_standard, $selected_id, $limit), ENT_QUOTES, 'UTF-8') : '#'; ?>" 
             class="pagination-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>" 
             aria-label="Next Page"
             title="Next Page">
            <i class="fa-solid fa-chevron-right" style="font-size: 0.72rem;"></i>
          </a>
        </nav>
      <?php endif; ?>

      <!-- Legend / Session Status -->
      <div style="font-size: 0.78rem; color: #64748b; display: flex; align-items: center; gap: 12px; margin-left: auto;">
        <span style="display: inline-flex; align-items: center; gap: 6px;">
          <span style="width: 8px; height: 8px; border-radius: 50%; background: #10b981;"></span>
          Official PVC Pass
        </span>
        <span style="color: #cbd5e1;">|</span>
        <span>Session: <strong style="color: #334155;"><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong></span>
      </div>

    </div>
  </div>
  
<?php else: ?>
  <div class="hrms-card" style="text-align: center; padding: 60px 20px;">
    <div style="font-size: 2.5rem; color: #cbd5e1; margin-bottom: 12px;"><i class="fa-solid fa-id-badge"></i></div>
    <h3 style="margin: 0 0 8px; font-weight: 800; color: #0f172a;">No Student Enrolled in Active Session</h3>
    <p style="margin: 0; color: #64748b; font-size: 0.88rem;">Please enroll students in Student Roaster to generate identity cards.</p>
  </div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════
     HIGH-RES PNG DOWNLOAD LOGIC (html2canvas)
     ══════════════════════════════════════════════════════ -->
<script>
function downloadCardImage(elementId, sideLabel) {
  const card = document.getElementById(elementId);
  if (!card) return;

  const rawStuName = <?php echo json_encode($student['student_name'] ?? 'Student', JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
  const rawRollNo = <?php echo json_encode($student['roll_no'] ?? 'KSV', JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
  const safeStuName = String(rawStuName).replace(/[^a-zA-Z0-9_\-]/g, '_');
  const safeRollNo = String(rawRollNo).replace(/[^a-zA-Z0-9_\-]/g, '_');
  const safeSide = String(sideLabel).replace(/[^a-zA-Z0-9_\-]/g, '_');
  const filename = `Student_ID_${safeSide}_${safeStuName}_${safeRollNo}.png`;

  html2canvas(card, {
    scale: 2.5,
    useCORS: true,
    backgroundColor: null,
    logging: false
  }).then(canvas => {
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }).catch(err => {
    console.error('Download error:', err);
    alert('Unable to generate high-resolution image. Please try again.');
  });
}
</script>

<?php require_once __DIR__ . '/../includes/layout-footer.php'; ?>
