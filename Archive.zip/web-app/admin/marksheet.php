<?php
// Defense-in-depth HTTP security headers
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

require_once __DIR__ . '/../config.php';

$current_user = require_login(['super_admin', 'staff', 'parent', 'student']);
if ($current_user['role'] === 'staff') {
    require_menu_permission('admin_marksheet');
}

// Session-based rate limiting (Max 120 page requests per minute)
$now = time();
if (!isset($_SESSION['marksheet_req_attempts']) || !is_array($_SESSION['marksheet_req_attempts'])) {
    $_SESSION['marksheet_req_attempts'] = [];
}
$_SESSION['marksheet_req_attempts'] = array_filter($_SESSION['marksheet_req_attempts'], function($timestamp) use ($now) {
    return ($now - (int)$timestamp) < 60;
});
if (count($_SESSION['marksheet_req_attempts']) >= 120) {
    http_response_code(429);
    exit('Rate limit exceeded. Please wait a moment before trying again.');
}
$_SESSION['marksheet_req_attempts'][] = $now;

$page_title = 'Report Card | KSV Academy HRMS';
$page_heading = 'Report Card';
$page_subheading = 'Official Academic Statement of Marks, Examination Registers & Printable Report Cards';
$active_menu = 'marksheet';

$db = get_db_connection();
$active_session = get_active_session();
$session_id = $active_session ? intval($active_session['id']) : 1;
$current_session_name = $active_session['session_name'] ?? (defined('CURRENT_SESSION') ? CURRENT_SESSION : date('Y'));
$school_settings = get_school_settings();

// Academic Standards & Specialized Course Categories (Matching Student Roaster & Attendance)
$academic_categories = get_default_academic_categories();
$flat_predefined_standards = [];
foreach ($academic_categories as $cat => $std_list) {
    foreach ($std_list as $s_item) {
        $flat_predefined_standards[] = $s_item;
    }
}
$db_standards = $db->query("SELECT DISTINCT standard FROM students WHERE session_id = " . intval($session_id) . " AND standard IS NOT NULL AND standard != ''")->fetchAll(PDO::FETCH_COLUMN) ?: [];
$standards = array_values(array_unique(array_filter(array_merge($flat_predefined_standards, $db_standards))));
$custom_db_standards = array_values(array_diff($db_standards, $flat_predefined_standards));

$search = mb_substr(trim($_GET['search'] ?? ''), 0, 100);
$raw_standard = trim($_GET['standard'] ?? '');
$filter_standard = ($raw_standard !== '' && $raw_standard !== 'all' && in_array($raw_standard, $standards, true)) ? $raw_standard : '';

// Selected student & exam
$selected_student_id = max(0, intval($_GET['student_id'] ?? ($_GET['id'] ?? 0)));
$selected_marksheet_id = max(0, intval($_GET['marksheet_id'] ?? 0));

// Resolve authorization for parent/student roles (Prevent IDOR & unauthorized directory browsing)
$is_parent_or_student = in_array($current_user['role'], ['student', 'parent'], true);
$allowed_student_ids = [];
if ($is_parent_or_student) {
    if ($current_user['role'] === 'student') {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    } else {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE parent_user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    }
    $allowed_student_ids = array_map('intval', $stmt_auth->fetchAll(PDO::FETCH_COLUMN));

    if ($selected_student_id > 0 && in_array($selected_student_id, $allowed_student_ids, true)) {
        // Authorized selected_student_id
    } elseif (!empty($allowed_student_ids)) {
        $selected_student_id = $allowed_student_ids[0];
    } else {
        $selected_student_id = 0;
    }
}

// Fetch students for dropdown list (Strictly scoped by session and user role, memory optimized)
if ($is_parent_or_student) {
    if (!empty($allowed_student_ids)) {
        $in_auth_ph = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $all_students_stmt = $db->prepare("
            SELECT id, student_name, roll_no, standard 
            FROM students 
            WHERE session_id = ? AND id IN ($in_auth_ph)
            ORDER BY standard ASC, roll_no ASC, student_name ASC
        ");
        $all_students_stmt->execute(array_merge([$session_id], $allowed_student_ids));
        $all_students_list = $all_students_stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $all_students_list = [];
    }
} else {
    $all_students_stmt = $db->prepare("
        SELECT id, student_name, roll_no, standard 
        FROM students 
        WHERE session_id = ? 
        ORDER BY standard ASC, roll_no ASC, student_name ASC
    ");
    $all_students_stmt->execute([$session_id]);
    $all_students_list = $all_students_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Pagination & Limits Setup (10, 20, 30, 40, 50)
$allowed_limits = [10, 20, 30, 40, 50];
$limit = intval($_GET['limit'] ?? 10);
if (!in_array($limit, $allowed_limits, true)) {
    $limit = 10;
}
$page = max(1, intval($_GET['page'] ?? 1));

// Build WHERE filter conditions
$where_clauses = ["session_id = ?"];
$where_params = [$session_id];

if ($is_parent_or_student) {
    if (!empty($allowed_student_ids)) {
        $in_auth_where = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $where_clauses[] = "id IN ($in_auth_where)";
        foreach ($allowed_student_ids as $aid) {
            $where_params[] = $aid;
        }
    } else {
        $where_clauses[] = "1=0";
    }
}

if ($search !== '') {
    $where_clauses[] = "(student_name LIKE ? OR roll_no LIKE ? OR admission_no LIKE ? OR parent_phone LIKE ?)";
    $search_like = addcslashes($search, '%_\\');
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
    $where_params[] = "%$search_like%";
}

if ($filter_standard !== '') {
    $where_clauses[] = "standard = ?";
    $where_params[] = $filter_standard;
}

$where_sql = implode(' AND ', $where_clauses);

// Count total matching scholars
$count_stmt = $db->prepare("SELECT COUNT(*) FROM students WHERE {$where_sql}");
$count_stmt->execute($where_params);
$total_records = intval($count_stmt->fetchColumn());

// Calculate total pages & offset
$total_pages = max(1, (int)ceil($total_records / $limit));
if ($page > $total_pages) {
    $page = $total_pages;
}
$offset = ($page - 1) * $limit;

// Query students for the paginated table directory
$query = "SELECT * FROM students WHERE {$where_sql} ORDER BY standard ASC, roll_no ASC, student_name ASC LIMIT ? OFFSET ?";
$stmt_table = $db->prepare($query);
$bind_idx = 1;
foreach ($where_params as $val) {
    $stmt_table->bindValue($bind_idx++, $val);
}
$stmt_table->bindValue($bind_idx++, $limit, PDO::PARAM_INT);
$stmt_table->bindValue($bind_idx++, $offset, PDO::PARAM_INT);
$stmt_table->execute();
$table_students = $stmt_table->fetchAll();

// Pagination indicators
$start_record = $total_records > 0 ? $offset + 1 : 0;
$end_record = min($offset + $limit, $total_records);

// Helper for generating marksheet pagination links
if (!function_exists('get_marksheet_pagination_url')) {
    function get_marksheet_pagination_url($target_page, $search, $filter_standard, $selected_student_id, $selected_marksheet_id, $limit) {
        $params = [];
        $selected_student_id = intval($selected_student_id);
        $selected_marksheet_id = intval($selected_marksheet_id);
        $limit = intval($limit);
        $target_page = intval($target_page);
        if ($selected_student_id > 0) $params['student_id'] = $selected_student_id;
        if ($selected_marksheet_id > 0) $params['marksheet_id'] = $selected_marksheet_id;
        if (!empty($search)) $params['search'] = $search;
        if (!empty($filter_standard)) $params['standard'] = $filter_standard;
        if ($limit !== 10) $params['limit'] = $limit;
        if ($target_page > 1) $params['page'] = $target_page;
        return ADMIN_URL . '/marksheet' . (!empty($params) ? '?' . http_build_query($params) : '') . '#marksheetDirectoryCard';
    }
}

// Default selected student:
if ($selected_student_id === 0) {
    if (!empty($table_students)) {
        $selected_student_id = intval($table_students[0]['id']);
    } elseif (!empty($all_students_list)) {
        $selected_student_id = intval($all_students_list[0]['id']);
    }
}

// Active session academic statistics for stat cards:
$total_enrolled_count = count($all_students_list);
if ($is_parent_or_student) {
    if (!empty($allowed_student_ids)) {
        $in_ms_ph = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $eval_stats_stmt = $db->prepare("
            SELECT COUNT(*) as cnt, AVG(percentage) as avg_pct, 
                   SUM(CASE WHEN result_status = 'PASS' THEN 1 ELSE 0 END) as pass_cnt 
            FROM marksheets 
            WHERE session_id = ? AND student_id IN ($in_ms_ph)
        ");
        $eval_stats_stmt->execute(array_merge([$session_id], $allowed_student_ids));
        $eval_stats = $eval_stats_stmt->fetch();
    } else {
        $eval_stats = null;
    }
} else {
    $eval_stats_stmt = $db->prepare("
        SELECT COUNT(*) as cnt, AVG(percentage) as avg_pct, 
               SUM(CASE WHEN result_status = 'PASS' THEN 1 ELSE 0 END) as pass_cnt 
        FROM marksheets 
        WHERE session_id = ?
    ");
    $eval_stats_stmt->execute([$session_id]);
    $eval_stats = $eval_stats_stmt->fetch();
}
$total_marksheets_count = intval($eval_stats['cnt'] ?? 0);
$avg_academic_pct = ($eval_stats && $eval_stats['avg_pct'] !== null) ? round($eval_stats['avg_pct'], 1) : 0;
$passed_count = intval($eval_stats['pass_cnt'] ?? 0);
$pass_rate = $total_marksheets_count > 0 ? round(($passed_count / $total_marksheets_count) * 100) : 0;

// Query summary of marksheets per student for displayed table records in active session (Performance & Memory optimized)
$page_student_ids = array_values(array_unique(array_filter(array_map('intval', array_column($table_students, 'id')))));
$stu_ms_summary = [];

if (!empty($page_student_ids)) {
    $in_stu_ph = implode(',', array_fill(0, count($page_student_ids), '?'));
    $ms_summary_stmt = $db->prepare("
        SELECT m.student_id, COUNT(m.id) as total_marksheets, 
               SUBSTRING_INDEX(GROUP_CONCAT(m.exam_name ORDER BY m.id DESC SEPARATOR '||'), '||', 1) as latest_exam_name,
               SUBSTRING_INDEX(GROUP_CONCAT(m.percentage ORDER BY m.id DESC SEPARATOR '||'), '||', 1) as latest_percentage,
               SUBSTRING_INDEX(GROUP_CONCAT(m.overall_grade ORDER BY m.id DESC SEPARATOR '||'), '||', 1) as latest_grade,
               SUBSTRING_INDEX(GROUP_CONCAT(m.result_status ORDER BY m.id DESC SEPARATOR '||'), '||', 1) as latest_status,
               SUBSTRING_INDEX(GROUP_CONCAT(m.id ORDER BY m.id DESC SEPARATOR '||'), '||', 1) as latest_marksheet_id
        FROM marksheets m
        WHERE m.session_id = ? AND m.student_id IN ($in_stu_ph)
        GROUP BY m.student_id
    ");
    $ms_summary_stmt->execute(array_merge([$session_id], $page_student_ids));
    while ($row = $ms_summary_stmt->fetch(PDO::FETCH_ASSOC)) {
        $stu_ms_summary[$row['student_id']] = $row;
    }

    // Query detailed subject marks for page students to support pre-loading saved evaluations & PDF export
    $stu_evaluations_map = [];
    $all_ms_stmt = $db->prepare("
        SELECT id, student_id, exam_name, exam_date, subjects_json, total_obtained, total_max, percentage, overall_grade, result_status
        FROM marksheets
        WHERE session_id = ? AND student_id IN ($in_stu_ph)
        ORDER BY id DESC
    ");
    $all_ms_stmt->execute(array_merge([$session_id], $page_student_ids));
    while ($ms_row = $all_ms_stmt->fetch(PDO::FETCH_ASSOC)) {
        $sid = intval($ms_row['student_id']);
        $ename = trim($ms_row['exam_name']);
        $subs = json_decode($ms_row['subjects_json'], true);
        if (is_array($subs)) {
            foreach ($subs as $sb) {
                $sname = trim($sb['name'] ?? '');
                if ($sname !== '') {
                    $stu_evaluations_map[$sid][$ename][$sname] = [
                        'marksheet_id' => intval($ms_row['id']),
                        'exam_name' => $ename,
                        'exam_date' => $ms_row['exam_date'],
                        'max' => floatval($sb['max'] ?? 100),
                        'pass' => floatval($sb['pass'] ?? 35),
                        'obtained' => floatval($sb['obtained'] ?? 0),
                        'grade' => $sb['grade'] ?? 'F'
                    ];
                }
            }
        }
    }
}

// Handle Add/Generate Marksheet Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($current_user['role'] !== 'super_admin' && $current_user['role'] !== 'staff') {
        http_response_code(403);
        set_flash('error', 'Unauthorized action: Marksheet generation is restricted to staff and administrators.');
        header("Location: " . ADMIN_URL . "/marksheet");
        exit;
    }

    // 1. Anti-bot honeypot check
    if (!empty($_POST['marksheet_hp'])) {
        usleep(300000);
        set_flash('error', 'Invalid submission detected.');
        header("Location: " . ADMIN_URL . "/marksheet");
        exit;
    }

    // 2. CSRF Token verification
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Security validation failed (Invalid CSRF token). Please try again.');
        header("Location: " . ADMIN_URL . "/marksheet");
        exit;
    }

    // 3. Post submission rate limiting (Max 30 marksheets per 5 minutes per session)
    if (!isset($_SESSION['marksheet_post_attempts']) || !is_array($_SESSION['marksheet_post_attempts'])) {
        $_SESSION['marksheet_post_attempts'] = [];
    }
    $_SESSION['marksheet_post_attempts'] = array_filter($_SESSION['marksheet_post_attempts'], function($timestamp) use ($now) {
        return ($now - (int)$timestamp) < 300;
    });
    if (count($_SESSION['marksheet_post_attempts']) >= 30) {
        set_flash('error', 'Rate limit exceeded. Please wait before generating more marksheets.');
        header("Location: " . ADMIN_URL . "/marksheet");
        exit;
    }
    $_SESSION['marksheet_post_attempts'][] = $now;

    $action = $_POST['action'] ?? '';

    if ($action === 'create_marksheet') {
        $student_id = intval($_POST['student_id'] ?? 0);
        
        // Verify student belongs to active session
        $chk_stu = $db->prepare("SELECT id FROM students WHERE id = ? AND session_id = ? LIMIT 1");
        $chk_stu->execute([$student_id, $session_id]);
        if (!$chk_stu->fetch()) {
            set_flash('error', 'Selected student does not exist in the active academic session.');
            header("Location: " . ADMIN_URL . "/marksheet");
            exit;
        }

        $raw_exam_name = trim($_POST['exam_name'] ?? 'Annual Examination');
        if ($raw_exam_name === 'Other' && !empty($_POST['custom_exam_name'])) {
            $raw_exam_name = trim($_POST['custom_exam_name']);
        }
        $exam_name = mb_substr($raw_exam_name !== '' ? $raw_exam_name : 'Annual Examination', 0, 100);
        
        // Strict calendar date verification
        $raw_date = trim($_POST['exam_date'] ?? '');
        $exam_date = date('Y-m-d');
        if (!empty($raw_date) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $raw_date, $m)) {
            if (checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
                $exam_date = $raw_date;
            }
        }
        $remarks = mb_substr(trim($_POST['remarks'] ?? 'Good academic discipline and consistent effort.'), 0, 500);

        $subjects = is_array($_POST['subjects'] ?? null) ? $_POST['subjects'] : [];
        $obtained_list = is_array($_POST['obtained'] ?? null) ? $_POST['obtained'] : [];
        $max_list = is_array($_POST['max_marks'] ?? null) ? $_POST['max_marks'] : [];

        $subjects_data = [];
        $total_obtained = 0;
        $total_max = 0;

        $max_allowed_subs = min(30, count($subjects));
        for ($i = 0; $i < $max_allowed_subs; $i++) {
            $sub_name = mb_substr(trim((string)($subjects[$i] ?? '')), 0, 100);
            if ($sub_name === '') continue;
            
            $max_m = max(1.0, min(1000.0, floatval($max_list[$i] ?? 100)));
            $obt = max(0.0, min($max_m, floatval($obtained_list[$i] ?? 0)));
            $pass_m = round($max_m * 0.35, 1);

            $pct_sub = ($obt / $max_m) * 100;
            if ($pct_sub >= 90) $sub_grade = 'A+';
            elseif ($pct_sub >= 80) $sub_grade = 'A';
            elseif ($pct_sub >= 70) $sub_grade = 'B+';
            elseif ($pct_sub >= 60) $sub_grade = 'B';
            elseif ($pct_sub >= 50) $sub_grade = 'C';
            elseif ($pct_sub >= 35) $sub_grade = 'D';
            else $sub_grade = 'F';

            $subjects_data[] = [
                'name' => $sub_name,
                'max' => $max_m,
                'pass' => $pass_m,
                'obtained' => $obt,
                'grade' => $sub_grade
            ];

            $total_obtained += $obt;
            $total_max += $max_m;
        }

        if (empty($subjects_data)) {
            set_flash('error', 'Please enter at least one valid subject.');
            header("Location: " . ADMIN_URL . "/marksheet?student_id=" . $student_id);
            exit;
        }

        $overall_percentage = $total_max > 0 ? round(($total_obtained / $total_max) * 100, 2) : 0;
        
        if ($overall_percentage >= 90) $overall_grade = 'A+';
        elseif ($overall_percentage >= 80) $overall_grade = 'A';
        elseif ($overall_percentage >= 70) $overall_grade = 'B+';
        elseif ($overall_percentage >= 60) $overall_grade = 'B';
        elseif ($overall_percentage >= 50) $overall_grade = 'C';
        elseif ($overall_percentage >= 35) $overall_grade = 'D';
        else $overall_grade = 'F';

        $result_status = $overall_percentage >= 35 ? 'PASS' : 'FAIL';

        $stmt = $db->prepare("
            INSERT INTO marksheets (session_id, student_id, exam_name, exam_date, subjects_json, total_obtained, total_max, percentage, overall_grade, result_status, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $session_id, $student_id, $exam_name, $exam_date, json_encode($subjects_data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
            $total_obtained, $total_max, $overall_percentage, $overall_grade, $result_status, $remarks
        ]);
        $new_ms_id = intval($db->lastInsertId());

        set_flash('success', "Marksheet generated successfully for scholar #" . $student_id . "!");
        
        // Preserve filters on redirect
        $qp_redir = ['student_id' => $student_id, 'marksheet_id' => $new_ms_id];
        if (!empty($search)) $qp_redir['search'] = $search;
        if (!empty($filter_standard)) $qp_redir['standard'] = $filter_standard;

        header("Location: " . ADMIN_URL . "/marksheet?" . http_build_query($qp_redir) . "#report-card-view");
        exit;
    }

    // Handle Bulk Add Subject Evaluation for Multiple Selected Scholars
    if ($action === 'bulk_add_subject') {
        $raw_exam_name = trim($_POST['bulk_exam_name'] ?? '');
        if ($raw_exam_name === 'custom' && !empty($_POST['bulk_custom_exam_name'])) {
            $raw_exam_name = trim($_POST['bulk_custom_exam_name']);
        }
        $exam_name = mb_substr($raw_exam_name !== '' ? $raw_exam_name : 'Unit Test 1', 0, 100);

        // Strict calendar date verification
        $raw_date = trim($_POST['bulk_exam_date'] ?? '');
        $exam_date = date('Y-m-d');
        if (!empty($raw_date) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $raw_date, $m)) {
            if (checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
                $exam_date = $raw_date;
            }
        }

        $student_ids = is_array($_POST['bulk_student_ids'] ?? null) ? $_POST['bulk_student_ids'] : [];
        $bulk_subjects = is_array($_POST['bulk_subjects'] ?? null) ? $_POST['bulk_subjects'] : [];
        $bulk_max = is_array($_POST['bulk_max_marks'] ?? null) ? $_POST['bulk_max_marks'] : [];
        $bulk_pass = is_array($_POST['bulk_pass_marks'] ?? null) ? $_POST['bulk_pass_marks'] : [];
        $bulk_obtained = is_array($_POST['bulk_obtained'] ?? null) ? $_POST['bulk_obtained'] : [];

        $processed_count = 0;
        $updated_count = 0;
        $inserted_count = 0;

        foreach ($student_ids as $sid_raw) {
            $sid = intval($sid_raw);
            if ($sid <= 0) continue;

            // Verify scholar belongs to active academic session
            $st_chk = $db->prepare("SELECT id, student_name FROM students WHERE id = ? AND session_id = ? LIMIT 1");
            $st_chk->execute([$sid, $session_id]);
            $stu_row = $st_chk->fetch(PDO::FETCH_ASSOC);
            if (!$stu_row) continue;

            $sub_name = mb_substr(trim((string)($bulk_subjects[$sid] ?? 'Mathematics')), 0, 100);
            if ($sub_name === '') $sub_name = 'Mathematics';

            $max_m = max(1.0, min(1000.0, floatval($bulk_max[$sid] ?? 100)));
            $pass_m = max(0.0, min($max_m, floatval($bulk_pass[$sid] ?? round($max_m * 0.35, 1))));
            $obt = max(0.0, min($max_m, floatval($bulk_obtained[$sid] ?? 0)));

            $pct_sub = ($obt / $max_m) * 100;
            if ($pct_sub >= 90) $sub_grade = 'A+';
            elseif ($pct_sub >= 80) $sub_grade = 'A';
            elseif ($pct_sub >= 70) $sub_grade = 'B+';
            elseif ($pct_sub >= 60) $sub_grade = 'B';
            elseif ($pct_sub >= 50) $sub_grade = 'C';
            elseif ($pct_sub >= 35) $sub_grade = 'D';
            else $sub_grade = 'F';

            $new_subject_entry = [
                'name' => $sub_name,
                'max' => $max_m,
                'pass' => $pass_m,
                'obtained' => $obt,
                'grade' => $sub_grade
            ];

            // Check if marksheet already exists for this scholar and exam_name in current session
            $ms_chk = $db->prepare("SELECT id, subjects_json FROM marksheets WHERE student_id = ? AND session_id = ? AND exam_name = ? LIMIT 1");
            $ms_chk->execute([$sid, $session_id, $exam_name]);
            $existing_ms = $ms_chk->fetch(PDO::FETCH_ASSOC);

            if ($existing_ms) {
                // Parse existing subjects
                $existing_subs = json_decode($existing_ms['subjects_json'], true);
                if (!is_array($existing_subs)) $existing_subs = [];

                $found_sub = false;
                foreach ($existing_subs as &$ex_s) {
                    if (strcasecmp(trim($ex_s['name'] ?? ''), $sub_name) === 0) {
                        $ex_s['max'] = $max_m;
                        $ex_s['pass'] = $pass_m;
                        $ex_s['obtained'] = $obt;
                        $ex_s['grade'] = $sub_grade;
                        $found_sub = true;
                        break;
                    }
                }
                unset($ex_s);

                if (!$found_sub) {
                    $existing_subs[] = $new_subject_entry;
                }

                // Recalculate whole marksheet totals
                $tot_obt = 0;
                $tot_max = 0;
                foreach ($existing_subs as $s_item) {
                    $tot_obt += floatval($s_item['obtained'] ?? 0);
                    $tot_max += floatval($s_item['max'] ?? 0);
                }
                $overall_pct = $tot_max > 0 ? round(($tot_obt / $tot_max) * 100, 2) : 0;
                if ($overall_pct >= 90) $overall_grade = 'A+';
                elseif ($overall_pct >= 80) $overall_grade = 'A';
                elseif ($overall_pct >= 70) $overall_grade = 'B+';
                elseif ($overall_pct >= 60) $overall_grade = 'B';
                elseif ($overall_pct >= 50) $overall_grade = 'C';
                elseif ($overall_pct >= 35) $overall_grade = 'D';
                else $overall_grade = 'F';

                $result_status = $overall_pct >= 35 ? 'PASS' : 'FAIL';

                $up_stmt = $db->prepare("
                    UPDATE marksheets 
                    SET subjects_json = ?, total_obtained = ?, total_max = ?, percentage = ?, overall_grade = ?, result_status = ?, exam_date = ?
                    WHERE id = ?
                ");
                $up_stmt->execute([
                    json_encode($existing_subs, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
                    $tot_obt, $tot_max, $overall_pct, $overall_grade, $result_status, $exam_date,
                    $existing_ms['id']
                ]);
                $updated_count++;
            } else {
                // Insert new marksheet for this scholar
                $overall_pct = round(($obt / $max_m) * 100, 2);
                $overall_grade = $sub_grade;
                $result_status = $overall_pct >= 35 ? 'PASS' : 'FAIL';
                $remarks = 'Subject evaluation recorded.';

                $ins_stmt = $db->prepare("
                    INSERT INTO marksheets (session_id, student_id, exam_name, exam_date, subjects_json, total_obtained, total_max, percentage, overall_grade, result_status, remarks)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ins_stmt->execute([
                    $session_id, $sid, $exam_name, $exam_date,
                    json_encode([$new_subject_entry], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
                    $obt, $max_m, $overall_pct, $overall_grade, $result_status, $remarks
                ]);
                $inserted_count++;
            }
            $processed_count++;
        }

        if ($processed_count > 0) {
            set_flash('success', "Subject '{$sub_name}' evaluation for {$processed_count} scholar(s) saved in '{$exam_name}' successfully! ({$inserted_count} new marksheets, {$updated_count} updated).");
        } else {
            set_flash('error', 'No valid scholar records were submitted.');
        }

        header("Location: " . ADMIN_URL . "/marksheet");
        exit;
    }
}

// Fetch marksheets for this student (Strictly scoped by session)
$marksheets_stmt = $db->prepare("SELECT * FROM marksheets WHERE student_id = ? AND session_id = ? ORDER BY id DESC");
$marksheets_stmt->execute([$selected_student_id, $session_id]);
$student_marksheets = $marksheets_stmt->fetchAll();

// Select active marksheet to display
$active_marksheet = null;
if ($selected_marksheet_id > 0) {
    foreach ($student_marksheets as $ms) {
        if (intval($ms['id']) === $selected_marksheet_id) {
            $active_marksheet = $ms;
            break;
        }
    }
}
if (!$active_marksheet && !empty($student_marksheets)) {
    $active_marksheet = $student_marksheets[0];
}

// Fetch student profile (Strictly enforcing session and authorization)
$student_profile = null;
if ($selected_student_id > 0) {
    if ($is_parent_or_student) {
        if (in_array($selected_student_id, $allowed_student_ids, true)) {
            $st_stmt = $db->prepare("SELECT * FROM students WHERE id = ? AND session_id = ? LIMIT 1");
            $st_stmt->execute([$selected_student_id, $session_id]);
            $student_profile = $st_stmt->fetch();
        }
    } else {
        $st_stmt = $db->prepare("SELECT * FROM students WHERE id = ? AND session_id = ? LIMIT 1");
        $st_stmt->execute([$selected_student_id, $session_id]);
        $student_profile = $st_stmt->fetch();
    }
    if (!$student_profile) {
        $selected_student_id = 0;
    }
}

// Verification QR code for marksheet
$verification_qr_url = '';
if ($student_profile && $active_marksheet) {
    $safe_roll = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$student_profile['roll_no']);
    $safe_grade = preg_replace('/[^a-zA-Z0-9_\+\-]/', '', (string)$active_marksheet['overall_grade']);
    $qr_payload = 'KSV-EVAL-ID:' . intval($active_marksheet['id']) . '|ROLL:' . $safe_roll . '|SCORE:' . floatval($active_marksheet['percentage']) . '%|' . $safe_grade;
    $verification_qr_url = get_qr_code_url($qr_payload, '120x120');
}

// Base directories for safe photo verification
$allowed_base_uploads = ($p = realpath(__DIR__ . '/../../uploads')) ? rtrim($p, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : false;
$allowed_base_assets = ($p = realpath(__DIR__ . '/../../assets')) ? rtrim($p, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : false;

// Build query string to preserve search & filter
$qp_filter = [];
if (!empty($search)) $qp_filter['search'] = $search;
if (!empty($filter_standard)) $qp_filter['standard'] = $filter_standard;
$filter_qs = !empty($qp_filter) ? '&' . http_build_query($qp_filter) : '';

// Avatar gradient fallback
$grad_palette = [
    'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)',
    'linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)',
    'linear-gradient(135deg, #059669 0%, #047857 100%)',
    'linear-gradient(135deg, #d97706 0%, #b45309 100%)',
    'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
];

require_once __DIR__ . '/../includes/layout-header.php';
?>

<style>
/* ── Strict A4 Single-Page Print Setup ── */
@media print {
  @page {
    size: A4 portrait;
    margin: 8mm 10mm;
  }
  
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    background: #ffffff !important;
    width: 100% !important;
    height: 100% !important;
    overflow: hidden !important;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  body * {
    visibility: hidden;
  }

  .hrms-sidebar,
  .hrms-topbar,
  .no-print,
  .academic-stat-grid,
  .scholar-control-card,
  .roaster-toolbar-card,
  .hrms-card.no-print,
  .table-card,
  #student-directory,
  .modal-backdrop,
  header,
  footer,
  nav {
    display: none !important;
  }

  .marksheet-print-canvas,
  .marksheet-print-canvas * {
    visibility: visible;
  }

  .marksheet-print-canvas {
    position: absolute !important;
    left: 0 !important;
    top: 0 !important;
    right: 0 !important;
    margin: 0 auto !important;
    width: 100% !important;
    max-width: 100% !important;
    box-sizing: border-box !important;
    background: #ffffff !important;
    box-shadow: none !important;
    border: 2px solid #0092df !important;
    border-radius: 12px !important;
    page-break-inside: avoid !important;
    break-inside: avoid !important;
    page-break-after: avoid !important;
    break-after: avoid !important;
    page-break-before: avoid !important;
    break-before: avoid !important;
  }

  .report-header-banner,
  .report-details-grid,
  .report-table,
  .report-summary-kpi-row,
  .report-remarks-card,
  .report-signatures-row {
    page-break-inside: avoid !important;
    break-inside: avoid !important;
  }

  /* Strict White Paper Output on both Dark and Light mode */
  [data-theme="dark"],
  [data-theme="dark"] body,
  [data-theme="dark"] html {
    background: #ffffff !important;
    color: #000000 !important;
  }

  [data-theme="dark"] .marksheet-print-canvas,
  [data-theme="dark"] .report-card-container {
    background: #ffffff !important;
    color: #0f172a !important;
    border: 2px solid #0092df !important;
    box-shadow: none !important;
  }

  [data-theme="dark"] .report-school-title {
    color: #007cbd !important;
  }

  [data-theme="dark"] .report-school-tagline {
    color: #334155 !important;
  }

  [data-theme="dark"] .report-school-subinfo {
    color: #64748b !important;
  }

  [data-theme="dark"] .report-details-grid {
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
  }

  [data-theme="dark"] .detail-item strong {
    color: #475569 !important;
  }

  [data-theme="dark"] .detail-item span {
    color: #0f172a !important;
  }

  [data-theme="dark"] .report-table {
    border: 1px solid #cbd5e1 !important;
  }

  [data-theme="dark"] .report-table th,
  [data-theme="dark"] .report-table td {
    border: 1px solid #cbd5e1 !important;
    color: #0f172a !important;
  }

  [data-theme="dark"] .report-table thead th {
    background: #0f172a !important;
    color: #ffffff !important;
  }

  [data-theme="dark"] .report-table tbody tr:nth-child(even) {
    background: #fcfdfe !important;
  }

  [data-theme="dark"] .report-table tbody tr:last-child {
    background: #f8fafc !important;
    border-top: 2px solid #0092df !important;
  }

  [data-theme="dark"] .report-remarks-card {
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-left: 4px solid #0092df !important;
    color: #334155 !important;
  }

  [data-theme="dark"] .report-signatures-row {
    border-top: 1px solid #cbd5e1 !important;
    color: #475569 !important;
  }
}

/* ── Academic KPI Statistics Grid ── */
.academic-stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
  gap: 16px;
  margin-bottom: 22px;
}
.academic-stat-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
  transition: all 0.25s ease;
}
.academic-stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(15, 23, 42, 0.06);
}
.stat-icon-wrap {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  flex-shrink: 0;
}
.stat-icon-wrap.blue { background: #e0f2fe; color: #0284c7; }
.stat-icon-wrap.emerald { background: #dcfce7; color: #15803d; }
.stat-icon-wrap.purple { background: #f3e8ff; color: #7e22ce; }
.stat-icon-wrap.amber { background: #fef3c7; color: #b45309; }

.stat-metric-val {
  font-size: 1.45rem;
  font-weight: 800;
  color: #0f172a;
  line-height: 1.1;
  font-family: 'Outfit', sans-serif;
}
.stat-metric-lbl {
  font-size: 0.78rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  margin-top: 3px;
}

/* ── Scholar Control Banner ── */
.scholar-control-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 16px 22px;
  margin-bottom: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}
.current-scholar-pill {
  display: flex;
  align-items: center;
  gap: 14px;
}
.scholar-mini-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #e0f2fe;
}
.scholar-mini-init {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  font-weight: 800;
  font-family: 'Outfit', sans-serif;
  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.1);
}
.current-scholar-meta h4 {
  margin: 0;
  font-size: 1.05rem;
  font-weight: 800;
  color: #0f172a;
  font-family: 'Outfit', sans-serif;
  display: flex;
  align-items: center;
  gap: 8px;
}
.current-scholar-meta .meta-pills {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 3px;
  font-size: 0.75rem;
}

/* ── Modern Premium Report Card Container ── */
.report-card-container {
  max-width: 860px;
  margin: 0 auto 34px;
  background: #ffffff;
  border-radius: 16px;
  border: 2px solid #0092df;
  box-shadow: 0 20px 45px -10px rgba(15, 23, 42, 0.12), 0 0 0 1px rgba(0, 146, 223, 0.15);
  position: relative;
  overflow: hidden;
  transition: all 0.25s ease;
}

/* Gold pinstripe inner accent border */
.report-card-container::before {
  content: '';
  position: absolute;
  inset: 6px;
  border: 1px dashed rgba(0, 146, 223, 0.35);
  border-radius: 10px;
  pointer-events: none;
}

.report-header-banner {
  position: relative;
  z-index: 1;
  text-align: center;
  border-bottom: 2px solid #0092df;
}
.report-brand-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
.report-school-title {
  margin: 0;
  font-weight: 900;
  color: #007cbd;
  letter-spacing: 0.5px;
  font-family: 'Outfit', sans-serif;
  line-height: 1.15;
}
.report-school-tagline {
  font-weight: 800;
  color: #334155;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-top: 2px;
}

.report-session-ribbon {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: linear-gradient(135deg, #0092df 0%, #0074b3 100%);
  color: #ffffff;
  border-radius: 30px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  box-shadow: 0 3px 10px rgba(0, 146, 223, 0.25);
}

/* Student & Exam Details Box */
.report-details-grid {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: 1fr 1fr;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
}
.detail-item {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.detail-item strong {
  color: #475569;
  font-weight: 700;
  min-width: 105px;
}
.detail-item span {
  color: #0f172a;
}

/* Statement of Marks Table */
.report-table {
  width: 100%;
  border-collapse: collapse;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #cbd5e1;
}
.report-table th, .report-table td {
  border: 1px solid #cbd5e1;
}
.report-table thead th {
  background: #0f172a;
  color: #ffffff;
  font-weight: 800;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  text-align: center;
}
.report-table thead th:first-child {
  text-align: left;
}
.report-table tbody tr:nth-child(even) {
  background: #fcfdfe;
}
.report-table tbody tr:hover {
  background: #f0f9ff;
}

/* Performance Summary KPI Row */
.report-summary-kpi-row {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}
.summary-kpi-card {
  border-radius: 10px;
  text-align: center;
  border: 1px solid transparent;
}
.summary-kpi-card.percentage {
  background: #f0fdf4;
  border-color: #bbf7d0;
}
.summary-kpi-card.grade {
  background: #eff6ff;
  border-color: #bfdbfe;
}
.summary-kpi-card.pass {
  background: #f0fdf4;
  border-color: #86efac;
}
.summary-kpi-card.fail {
  background: #fef2f2;
  border-color: #fca5a5;
}
.kpi-title {
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 4px;
}
.kpi-val {
  font-weight: 900;
  font-family: 'Outfit', sans-serif;
  line-height: 1.1;
}

/* Remarks */
.report-remarks-card {
  position: relative;
  z-index: 1;
  color: #334155;
  background: #f8fafc;
  border-radius: 8px;
  border-left: 4px solid #0092df;
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
.report-remarks-card i {
  color: #0092df;
  font-size: 1.1rem;
  margin-top: 2px;
}

/* Digital Signatures and Official Seals */
.report-signatures-row {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  border-top: 1px solid #cbd5e1;
  font-weight: 700;
  color: #475569;
}
.sig-block {
  text-align: center;
  width: 150px;
}
.sig-line {
  border-top: 1px solid #94a3b8;
  padding-top: 4px;
  text-transform: uppercase;
  letter-spacing: 0.03em;
}

/* ══════════════════════════════════════════════════════
   DYNAMIC SUBJECT TIERS (Screen & A4 Sizing)
   tier-few     : 1 - 4 Subjects (Large & spacious)
   tier-medium  : 5 - 7 Subjects (Standard balanced A4 fit)
   tier-compact : 8 - 10 Subjects (Compact content)
   tier-dense   : 11+ Subjects (Ultra-compact content)
   ══════════════════════════════════════════════════════ */

/* --- TIER FEW (<= 4 Subjects): Large & Spacious Content --- */
.report-card-container.tier-few {
  padding: 38px 46px;
}
.report-card-container.tier-few .report-header-banner {
  padding-bottom: 18px;
  margin-bottom: 22px;
}
.report-card-container.tier-few .report-school-title {
  font-size: 28px;
}
.report-card-container.tier-few .report-school-tagline {
  font-size: 13px;
}
.report-card-container.tier-few .report-brand-row img.school-logo-img {
  width: 68px;
  height: 68px;
}
.report-card-container.tier-few .report-session-ribbon {
  padding: 6px 24px;
  font-size: 13px;
  margin-top: 12px;
}
.report-card-container.tier-few .report-details-grid {
  padding: 16px 22px;
  margin-bottom: 22px;
  gap: 16px 28px;
  font-size: 13.5px;
}
.report-card-container.tier-few .report-table {
  margin: 20px 0 24px;
}
.report-card-container.tier-few .report-table th,
.report-card-container.tier-few .report-table td {
  padding: 13px 18px;
  font-size: 13.5px;
}
.report-card-container.tier-few .report-summary-kpi-row {
  margin-bottom: 24px;
  gap: 16px;
}
.report-card-container.tier-few .summary-kpi-card {
  padding: 15px;
}
.report-card-container.tier-few .kpi-val {
  font-size: 26px;
}
.report-card-container.tier-few .kpi-title {
  font-size: 11.5px;
}
.report-card-container.tier-few .report-remarks-card {
  padding: 14px 20px;
  margin-bottom: 34px;
  font-size: 13.5px;
}
.report-card-container.tier-few .report-signatures-row {
  padding-top: 24px;
  font-size: 12px;
}
.report-card-container.tier-few .sig-block .sig-spacer {
  height: 38px;
}
.report-card-container.tier-few .sig-crest-circle {
  width: 56px;
  height: 56px;
}

/* --- TIER MEDIUM (5 - 7 Subjects): Standard Balanced --- */
.report-card-container.tier-medium {
  padding: 26px 36px;
}
.report-card-container.tier-medium .report-header-banner {
  padding-bottom: 14px;
  margin-bottom: 16px;
}
.report-card-container.tier-medium .report-school-title {
  font-size: 24px;
}
.report-card-container.tier-medium .report-school-tagline {
  font-size: 12px;
}
.report-card-container.tier-medium .report-brand-row img.school-logo-img {
  width: 56px;
  height: 56px;
}
.report-card-container.tier-medium .report-session-ribbon {
  padding: 5px 20px;
  font-size: 11.5px;
  margin-top: 10px;
}
.report-card-container.tier-medium .report-details-grid {
  padding: 12px 18px;
  margin-bottom: 16px;
  gap: 10px 22px;
  font-size: 12.5px;
}
.report-card-container.tier-medium .report-table {
  margin: 14px 0 16px;
}
.report-card-container.tier-medium .report-table th,
.report-card-container.tier-medium .report-table td {
  padding: 9px 14px;
  font-size: 12.5px;
}
.report-card-container.tier-medium .report-summary-kpi-row {
  margin-bottom: 16px;
  gap: 12px;
}
.report-card-container.tier-medium .summary-kpi-card {
  padding: 10px 12px;
}
.report-card-container.tier-medium .kpi-val {
  font-size: 21px;
}
.report-card-container.tier-medium .kpi-title {
  font-size: 10.5px;
}
.report-card-container.tier-medium .report-remarks-card {
  padding: 10px 16px;
  margin-bottom: 22px;
  font-size: 12.5px;
}
.report-card-container.tier-medium .report-signatures-row {
  padding-top: 16px;
  font-size: 11.5px;
}
.report-card-container.tier-medium .sig-block .sig-spacer {
  height: 28px;
}
.report-card-container.tier-medium .sig-crest-circle {
  width: 48px;
  height: 48px;
}

/* --- TIER COMPACT (8 - 10 Subjects): Compact content --- */
.report-card-container.tier-compact {
  padding: 20px 30px;
}
.report-card-container.tier-compact .report-header-banner {
  padding-bottom: 10px;
  margin-bottom: 12px;
}
.report-card-container.tier-compact .report-school-title {
  font-size: 21px;
}
.report-card-container.tier-compact .report-school-tagline {
  font-size: 11px;
}
.report-card-container.tier-compact .report-brand-row img.school-logo-img {
  width: 48px;
  height: 48px;
}
.report-card-container.tier-compact .report-session-ribbon {
  padding: 4px 16px;
  font-size: 10.5px;
  margin-top: 8px;
}
.report-card-container.tier-compact .report-details-grid {
  padding: 9px 14px;
  margin-bottom: 12px;
  gap: 8px 18px;
  font-size: 11.5px;
}
.report-card-container.tier-compact .report-table {
  margin: 10px 0 12px;
}
.report-card-container.tier-compact .report-table th,
.report-card-container.tier-compact .report-table td {
  padding: 6.5px 10px;
  font-size: 11.5px;
}
.report-card-container.tier-compact .report-summary-kpi-row {
  margin-bottom: 12px;
  gap: 10px;
}
.report-card-container.tier-compact .summary-kpi-card {
  padding: 8px 10px;
}
.report-card-container.tier-compact .kpi-val {
  font-size: 18px;
}
.report-card-container.tier-compact .kpi-title {
  font-size: 9.5px;
}
.report-card-container.tier-compact .report-remarks-card {
  padding: 8px 12px;
  margin-bottom: 16px;
  font-size: 11.5px;
}
.report-card-container.tier-compact .report-signatures-row {
  padding-top: 12px;
  font-size: 11px;
}
.report-card-container.tier-compact .sig-block .sig-spacer {
  height: 20px;
}
.report-card-container.tier-compact .sig-crest-circle {
  width: 40px;
  height: 40px;
}

/* --- TIER DENSE (11+ Subjects): Ultra-Compact content --- */
.report-card-container.tier-dense {
  padding: 16px 24px;
}
.report-card-container.tier-dense .report-header-banner {
  padding-bottom: 8px;
  margin-bottom: 10px;
}
.report-card-container.tier-dense .report-school-title {
  font-size: 19px;
}
.report-card-container.tier-dense .report-school-tagline {
  font-size: 10px;
}
.report-card-container.tier-dense .report-brand-row img.school-logo-img {
  width: 40px;
  height: 40px;
}
.report-card-container.tier-dense .report-session-ribbon {
  padding: 3px 14px;
  font-size: 9.5px;
  margin-top: 6px;
}
.report-card-container.tier-dense .report-details-grid {
  padding: 7px 12px;
  margin-bottom: 10px;
  gap: 6px 14px;
  font-size: 10.5px;
}
.report-card-container.tier-dense .report-table {
  margin: 8px 0 10px;
}
.report-card-container.tier-dense .report-table th,
.report-card-container.tier-dense .report-table td {
  padding: 5px 8px;
  font-size: 10.5px;
}
.report-card-container.tier-dense .report-summary-kpi-row {
  margin-bottom: 10px;
  gap: 8px;
}
.report-card-container.tier-dense .summary-kpi-card {
  padding: 6px 8px;
}
.report-card-container.tier-dense .kpi-val {
  font-size: 16px;
}
.report-card-container.tier-dense .kpi-title {
  font-size: 9px;
}
.report-card-container.tier-dense .report-remarks-card {
  padding: 6px 10px;
  margin-bottom: 12px;
  font-size: 10.5px;
}
.report-card-container.tier-dense .report-signatures-row {
  padding-top: 10px;
  font-size: 10px;
}
.report-card-container.tier-dense .sig-block .sig-spacer {
  height: 14px;
}
.report-card-container.tier-dense .sig-crest-circle {
  width: 34px;
  height: 34px;
}

/* ══════════════════════════════════════════════════════
   STRICT A4 PRINT OVERRIDES PER TIER (Guaranteed 1 Page)
   ══════════════════════════════════════════════════════ */
@media print {
  /* TIER FEW PRINT */
  .report-card-container.tier-few {
    padding: 24px 30px !important;
  }
  .report-card-container.tier-few .report-header-banner {
    padding-bottom: 12px !important;
    margin-bottom: 16px !important;
  }
  .report-card-container.tier-few .report-school-title {
    font-size: 24px !important;
  }
  .report-card-container.tier-few .report-brand-row img.school-logo-img {
    width: 60px !important;
    height: 60px !important;
  }
  .report-card-container.tier-few .report-session-ribbon {
    padding: 5px 20px !important;
    font-size: 12px !important;
    margin-top: 10px !important;
  }
  .report-card-container.tier-few .report-details-grid {
    padding: 12px 18px !important;
    margin-bottom: 16px !important;
    gap: 10px 22px !important;
    font-size: 12.5px !important;
  }
  .report-card-container.tier-few .report-table {
    margin: 14px 0 16px !important;
  }
  .report-card-container.tier-few .report-table th,
  .report-card-container.tier-few .report-table td {
    padding: 10px 14px !important;
    font-size: 12.5px !important;
  }
  .report-card-container.tier-few .report-summary-kpi-row {
    margin-bottom: 16px !important;
    gap: 12px !important;
  }
  .report-card-container.tier-few .summary-kpi-card {
    padding: 10px 14px !important;
  }
  .report-card-container.tier-few .kpi-val {
    font-size: 22px !important;
  }
  .report-card-container.tier-few .report-remarks-card {
    padding: 10px 16px !important;
    margin-bottom: 20px !important;
    font-size: 12px !important;
  }
  .report-card-container.tier-few .report-signatures-row {
    padding-top: 14px !important;
  }
  .report-card-container.tier-few .sig-block .sig-spacer {
    height: 28px !important;
  }

  /* TIER MEDIUM PRINT (Biswajeet Verma 6 subjects) */
  .report-card-container.tier-medium {
    padding: 14px 22px !important;
  }
  .report-card-container.tier-medium .report-header-banner {
    padding-bottom: 8px !important;
    margin-bottom: 10px !important;
  }
  .report-card-container.tier-medium .report-school-title {
    font-size: 20px !important;
  }
  .report-card-container.tier-medium .report-school-tagline {
    font-size: 10.5px !important;
  }
  .report-card-container.tier-medium .report-brand-row img.school-logo-img {
    width: 48px !important;
    height: 48px !important;
  }
  .report-card-container.tier-medium .report-brand-row .verification-qr-wrap img {
    width: 44px !important;
    height: 44px !important;
  }
  .report-card-container.tier-medium .report-session-ribbon {
    padding: 3px 14px !important;
    font-size: 10px !important;
    margin-top: 6px !important;
  }
  .report-card-container.tier-medium .report-details-grid {
    padding: 8px 14px !important;
    margin-bottom: 10px !important;
    gap: 6px 16px !important;
    font-size: 11px !important;
  }
  .report-card-container.tier-medium .report-table {
    margin: 8px 0 10px !important;
  }
  .report-card-container.tier-medium .report-table th,
  .report-card-container.tier-medium .report-table td {
    padding: 6px 10px !important;
    font-size: 11px !important;
  }
  .report-card-container.tier-medium .report-summary-kpi-row {
    margin-bottom: 10px !important;
    gap: 10px !important;
  }
  .report-card-container.tier-medium .summary-kpi-card {
    padding: 7px 10px !important;
  }
  .report-card-container.tier-medium .kpi-val {
    font-size: 18px !important;
  }
  .report-card-container.tier-medium .kpi-title {
    font-size: 9.5px !important;
  }
  .report-card-container.tier-medium .report-remarks-card {
    padding: 7px 12px !important;
    margin-bottom: 12px !important;
    font-size: 10.5px !important;
  }
  .report-card-container.tier-medium .report-signatures-row {
    padding-top: 10px !important;
  }
  .report-card-container.tier-medium .sig-block .sig-spacer {
    height: 18px !important;
  }
  .report-card-container.tier-medium .sig-block .sig-crest-circle {
    width: 40px !important;
    height: 40px !important;
    font-size: 7px !important;
  }
  .report-card-container.tier-medium .sig-line {
    font-size: 10px !important;
    padding-top: 3px !important;
  }

  /* TIER COMPACT PRINT */
  .report-card-container.tier-compact {
    padding: 10px 18px !important;
  }
  .report-card-container.tier-compact .report-header-banner {
    padding-bottom: 6px !important;
    margin-bottom: 8px !important;
  }
  .report-card-container.tier-compact .report-school-title {
    font-size: 18px !important;
  }
  .report-card-container.tier-compact .report-school-tagline {
    font-size: 9.5px !important;
  }
  .report-card-container.tier-compact .report-brand-row img.school-logo-img {
    width: 42px !important;
    height: 42px !important;
  }
  .report-card-container.tier-compact .report-brand-row .verification-qr-wrap img {
    width: 38px !important;
    height: 38px !important;
  }
  .report-card-container.tier-compact .report-session-ribbon {
    padding: 2px 12px !important;
    font-size: 9px !important;
    margin-top: 4px !important;
  }
  .report-card-container.tier-compact .report-details-grid {
    padding: 6px 12px !important;
    margin-bottom: 8px !important;
    gap: 4px 12px !important;
    font-size: 10px !important;
  }
  .report-card-container.tier-compact .report-table {
    margin: 6px 0 8px !important;
  }
  .report-card-container.tier-compact .report-table th,
  .report-card-container.tier-compact .report-table td {
    padding: 4.5px 8px !important;
    font-size: 10px !important;
  }
  .report-card-container.tier-compact .report-summary-kpi-row {
    margin-bottom: 8px !important;
    gap: 8px !important;
  }
  .report-card-container.tier-compact .summary-kpi-card {
    padding: 5px 8px !important;
  }
  .report-card-container.tier-compact .kpi-val {
    font-size: 16px !important;
  }
  .report-card-container.tier-compact .kpi-title {
    font-size: 8.5px !important;
  }
  .report-card-container.tier-compact .report-remarks-card {
    padding: 5px 10px !important;
    margin-bottom: 8px !important;
    font-size: 9.5px !important;
  }
  .report-card-container.tier-compact .report-signatures-row {
    padding-top: 8px !important;
  }
  .report-card-container.tier-compact .sig-block .sig-spacer {
    height: 12px !important;
  }
  .report-card-container.tier-compact .sig-block .sig-crest-circle {
    width: 34px !important;
    height: 34px !important;
    font-size: 6px !important;
  }
  .report-card-container.tier-compact .sig-line {
    font-size: 9px !important;
    padding-top: 2px !important;
  }

  /* TIER DENSE PRINT */
  .report-card-container.tier-dense {
    padding: 8px 14px !important;
  }
  .report-card-container.tier-dense .report-header-banner {
    padding-bottom: 4px !important;
    margin-bottom: 6px !important;
  }
  .report-card-container.tier-dense .report-school-title {
    font-size: 16px !important;
  }
  .report-card-container.tier-dense .report-school-tagline {
    font-size: 9px !important;
  }
  .report-card-container.tier-dense .report-brand-row img.school-logo-img {
    width: 36px !important;
    height: 36px !important;
  }
  .report-card-container.tier-dense .report-brand-row .verification-qr-wrap img {
    width: 32px !important;
    height: 32px !important;
  }
  .report-card-container.tier-dense .report-session-ribbon {
    padding: 2px 10px !important;
    font-size: 8.5px !important;
    margin-top: 3px !important;
  }
  .report-card-container.tier-dense .report-details-grid {
    padding: 4px 10px !important;
    margin-bottom: 6px !important;
    gap: 3px 10px !important;
    font-size: 9.5px !important;
  }
  .report-card-container.tier-dense .report-table {
    margin: 4px 0 6px !important;
  }
  .report-card-container.tier-dense .report-table th,
  .report-card-container.tier-dense .report-table td {
    padding: 3.5px 6px !important;
    font-size: 9.5px !important;
  }
  .report-card-container.tier-dense .report-summary-kpi-row {
    margin-bottom: 6px !important;
    gap: 6px !important;
  }
  .report-card-container.tier-dense .summary-kpi-card {
    padding: 4px 6px !important;
  }
  .report-card-container.tier-dense .kpi-val {
    font-size: 14px !important;
  }
  .report-card-container.tier-dense .kpi-title {
    font-size: 7.5px !important;
  }
  .report-card-container.tier-dense .report-remarks-card {
    padding: 4px 8px !important;
    margin-bottom: 6px !important;
    font-size: 9px !important;
  }
  .report-card-container.tier-dense .report-signatures-row {
    padding-top: 6px !important;
  }
  .report-card-container.tier-dense .sig-block .sig-spacer {
    height: 8px !important;
  }
  .report-card-container.tier-dense .sig-block .sig-crest-circle {
    width: 28px !important;
    height: 28px !important;
    font-size: 5px !important;
  }
  .report-card-container.tier-dense .sig-line {
    font-size: 8.5px !important;
    padding-top: 1px !important;
  }
}

/* ── Marksheet Directory Table & Badge Styles (Simple & Sober - Like student-id.php) ── */
.marksheet-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}
.marksheet-table thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 0.73rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
.marksheet-table tbody td {
  padding: 11px 12px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
  font-size: 0.84rem;
}
.marksheet-table tbody tr {
  transition: background-color 0.15s ease;
}
.marksheet-table tbody tr:hover {
  background-color: #f8fafc;
}
.marksheet-table tbody tr.active-student-row {
  background-color: #f0f9ff !important;
}
.marksheet-table tbody tr.active-student-row td:first-child {
  border-left: 3px solid #0284c7;
}

/* Badge & Tag Elements */
.ms-roll-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  color: #0284c7;
  padding: 2px 7px;
  border-radius: 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.74rem;
  font-weight: 700;
  white-space: nowrap;
}
.ms-std-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.75rem;
  font-weight: 600;
}
.ms-blood-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
  font-size: 0.70rem;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  white-space: nowrap;
}
.ms-exam-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.74rem;
  font-weight: 600;
  white-space: nowrap;
}
.ms-perf-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.74rem;
  font-weight: 700;
  white-space: nowrap;
}
.ms-perf-badge.pass {
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  color: #166534;
}
.ms-perf-badge.fail {
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #991b1b;
}
.ms-perf-badge.none {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #64748b;
}
.ms-status-active {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f0f9ff;
  color: #0284c7;
  border: 1px solid #bae6fd;
  font-size: 0.74rem;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 20px;
  white-space: nowrap;
}
.ms-status-active .pulse-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #0284c7;
  box-shadow: 0 0 0 0 rgba(2, 132, 199, 0.7);
  animation: pulse-ring 1.8s infinite;
}
@keyframes pulse-ring {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(2, 132, 199, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(2, 132, 199, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(2, 132, 199, 0); }
}
.ms-status-verified {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f0fdf4;
  color: #166534;
  border: 1px solid #bbf7d0;
  font-size: 0.74rem;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 20px;
  white-space: nowrap;
}
.ms-status-pending {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #fefce8;
  color: #854d0e;
  border: 1px solid #fef08a;
  font-size: 0.74rem;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 20px;
  white-space: nowrap;
}
.ms-btn-action {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 11px;
  font-size: 0.76rem;
  font-weight: 600;
  border-radius: 6px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.ms-btn-secondary {
  color: #334155;
  background: #ffffff;
  border: 1px solid #cbd5e1;
}
.ms-btn-secondary:hover {
  background: #f8fafc;
  border-color: #94a3b8;
  color: #0f172a;
}

/* ══════════════════════════════════════════════════════════════════════
   RESPONSIVE MOBILE VIEW ENHANCEMENTS FOR ADMIN MARKSHEET
   ══════════════════════════════════════════════════════════════════════ */

/* Tablet & Mobile Screens (<= 768px) */
@media (max-width: 768px) {
  /* Academic Stat KPI Grid */
  .academic-stat-grid {
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 10px !important;
    margin-bottom: 16px !important;
  }
  .academic-stat-card {
    padding: 10px 12px !important;
    border-radius: 12px !important;
    gap: 10px !important;
  }
  .stat-icon-wrap {
    width: 40px !important;
    height: 40px !important;
    font-size: 1.1rem !important;
    border-radius: 10px !important;
  }
  .stat-metric-val {
    font-size: 1.25rem !important;
  }
  .stat-metric-lbl {
    font-size: 0.68rem !important;
    margin-top: 2px !important;
  }

  /* Scholar Control Bar */
  .scholar-control-card {
    padding: 12px 14px !important;
    margin-bottom: 18px !important;
    border-radius: 12px !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 12px !important;
  }
  .current-scholar-pill {
    width: 100% !important;
    justify-content: flex-start !important;
    gap: 10px !important;
  }
  .scholar-mini-avatar,
  .scholar-mini-init {
    width: 38px !important;
    height: 38px !important;
    font-size: 0.95rem !important;
    flex-shrink: 0 !important;
  }
  .current-scholar-meta h4 {
    font-size: 0.95rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .current-scholar-meta .meta-pills {
    font-size: 0.72rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .marksheet-top-actions {
    width: 100% !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 8px !important;
  }
  .marksheet-exam-form {
    width: 100% !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 6px !important;
  }
  .marksheet-exam-select {
    width: 100% !important;
    height: 40px !important;
    box-sizing: border-box !important;
    font-size: 0.82rem !important;
    border-radius: 8px !important;
  }
  .marksheet-print-btn {
    width: 100% !important;
    height: 40px !important;
    justify-content: center !important;
    font-size: 0.84rem !important;
    border-radius: 8px !important;
    margin: 0 !important;
  }

  /* Report Card Canvas Viewport Scaling */
  .report-card-container {
    padding: 16px 14px !important;
    margin-bottom: 22px !important;
    border-radius: 12px !important;
    border-width: 1.5px !important;
  }
  .report-card-container::before {
    inset: 4px !important;
    border-radius: 8px !important;
  }
  .report-header-banner {
    padding-bottom: 12px !important;
    margin-bottom: 14px !important;
  }
  .report-brand-row {
    gap: 10px !important;
    align-items: center !important;
  }
  .report-brand-row img.school-logo-img {
    width: 48px !important;
    height: 48px !important;
  }
  .report-brand-row .verification-qr-wrap img {
    width: 46px !important;
    height: 46px !important;
  }
  .report-brand-logo-wrap,
  .verification-qr-wrap {
    width: 54px !important;
  }
  .report-school-title {
    font-size: 1.15rem !important;
    line-height: 1.2 !important;
  }
  .report-school-tagline {
    font-size: 0.68rem !important;
  }
  .report-school-subinfo {
    font-size: 0.64rem !important;
    line-height: 1.3 !important;
  }
  .report-session-ribbon {
    padding: 4px 14px !important;
    font-size: 0.68rem !important;
    margin-top: 8px !important;
    letter-spacing: 0.5px !important;
    white-space: normal !important;
    line-height: 1.3 !important;
    text-align: center !important;
  }
  .report-card-container .report-details-grid {
    padding: 10px 12px !important;
    margin-bottom: 12px !important;
    gap: 8px 14px !important;
    font-size: 0.76rem !important;
  }
  .detail-item strong {
    min-width: 85px !important;
    font-size: 0.74rem !important;
  }
  .detail-item span {
    font-size: 0.76rem !important;
  }
  .report-table-responsive {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
    width: 100% !important;
    margin: 10px 0 14px !important;
  }
  .report-card-container .report-table {
    min-width: 480px !important;
    margin: 0 !important;
  }
  .report-card-container .report-table th,
  .report-card-container .report-table td {
    padding: 7px 8px !important;
    font-size: 0.76rem !important;
  }
  .report-card-container .report-summary-kpi-row {
    gap: 8px !important;
    margin-bottom: 14px !important;
  }
  .report-card-container .summary-kpi-card {
    padding: 8px 6px !important;
    border-radius: 8px !important;
  }
  .kpi-title {
    font-size: 0.64rem !important;
  }
  .kpi-val {
    font-size: 1.15rem !important;
  }
  .report-card-container .report-remarks-card {
    padding: 10px 12px !important;
    font-size: 0.76rem !important;
    margin-bottom: 16px !important;
  }
  .report-card-container .report-signatures-row {
    padding-top: 14px !important;
    font-size: 0.70rem !important;
  }
  .sig-block {
    width: auto !important;
    flex: 1 !important;
    max-width: 120px !important;
  }
  .sig-block .sig-spacer {
    height: 20px !important;
  }
  .sig-block .sig-crest-circle {
    width: 40px !important;
    height: 40px !important;
    font-size: 7px !important;
  }
  .sig-crest-lbl {
    font-size: 7px !important;
  }
  .sig-line {
    font-size: 0.68rem !important;
    padding-top: 2px !important;
  }
  .sig-principal-name {
    font-size: 0.82rem !important;
    height: 20px !important;
  }

  /* Empty state card */
  .report-empty-state-card {
    padding: 24px 14px !important;
    margin-bottom: 18px !important;
  }
  .report-empty-state-card button {
    width: 100% !important;
    justify-content: center !important;
  }

  /* Roaster Filter Toolbar */
  .roaster-toolbar-card {
    padding: 12px 14px !important;
    margin-top: 20px !important;
    margin-bottom: 14px !important;
    border-radius: 12px !important;
  }
  .roaster-toolbar-inner {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
  }
  .roaster-filter-form {
    flex-direction: column !important;
    align-items: stretch !important;
    width: 100% !important;
    gap: 8px !important;
  }
  .roaster-search-box {
    width: 100% !important;
    max-width: 100% !important;
    min-width: 0 !important;
    box-sizing: border-box !important;
    height: 40px !important;
    padding: 8px 12px !important;
    border-radius: 9px !important;
  }
  .marksheet-filter-row {
    display: grid !important;
    grid-template-columns: 1fr auto !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .marksheet-filter-row .roaster-select-box {
    width: 100% !important;
    min-width: 0 !important;
  }
  .marksheet-filter-row .roaster-select-box select {
    width: 100% !important;
    min-width: 0 !important;
    height: 40px !important;
    font-size: 0.80rem !important;
    border-radius: 9px !important;
    padding: 8px 24px 8px 28px !important;
  }
  .marksheet-filter-row .roaster-btn.secondary {
    height: 40px !important;
    font-size: 0.80rem !important;
    padding: 0 16px !important;
    justify-content: center !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
  }
  .marksheet-filter-row .roaster-btn.ghost {
    grid-column: 1 / -1 !important;
    width: 100% !important;
    height: 34px !important;
    font-size: 0.78rem !important;
    justify-content: center !important;
    border-radius: 8px !important;
  }
  .roaster-toolbar-actions {
    width: 100% !important;
    display: flex !important;
    margin: 2px 0 0 0 !important;
  }
  .scholars-count-badge {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.78rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
  }

  /* Directory Card & Header */
  .marksheet-directory-card {
    border-radius: 12px !important;
    margin-bottom: 20px !important;
  }
  .marksheet-card-header {
    padding: 12px 14px !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
  }
  .marksheet-title-block {
    width: 100% !important;
  }
  .marksheet-title-block .card-title {
    font-size: 0.95rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .marksheet-title-block p {
    font-size: 0.74rem !important;
    line-height: 1.4 !important;
  }
  .marksheet-actions-wrap {
    width: 100% !important;
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    padding-top: 8px !important;
    border-top: 1px dashed #e2e8f0 !important;
  }
  .marksheet-records-count {
    font-size: 0.75rem !important;
  }
  .ms-generate-btn {
    height: 32px !important;
    font-size: 0.74rem !important;
    padding: 0 10px !important;
    border-radius: 7px !important;
  }

  /* Directory Table & Scrolling */
  .table-responsive {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
    width: 100% !important;
    margin: 0 !important;
  }
  .marksheet-table {
    min-width: 880px !important;
  }
  .marksheet-table thead th {
    padding: 9px 8px !important;
    font-size: 0.68rem !important;
  }
  .marksheet-table tbody td {
    padding: 9px 8px !important;
    font-size: 0.78rem !important;
  }
  .marksheet-table tbody td .user-cell {
    gap: 8px !important;
  }
  .marksheet-table tbody td .user-cell img,
  .marksheet-table tbody td .user-cell .staff-avatar-init {
    width: 34px !important;
    height: 34px !important;
    font-size: 13px !important;
  }
  .ms-btn-action {
    padding: 4px 8px !important;
    font-size: 0.70rem !important;
  }

  /* Pagination Controls */
  .pagination-controls-wrap {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 12px !important;
    padding: 12px 14px !important;
  }
  .pagination-meta-group {
    flex-direction: column !important;
    align-items: flex-start !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .pagination-limit-box {
    width: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
  }
  .pagination-limit-select {
    padding: 4px 8px !important;
    font-size: 0.75rem !important;
    height: 30px !important;
  }
  .pagination-nav {
    display: flex !important;
    justify-content: center !important;
    width: 100% !important;
    flex-wrap: wrap !important;
    gap: 4px !important;
  }
  .pagination-btn {
    width: 30px !important;
    height: 30px !important;
    font-size: 0.75rem !important;
    padding: 0 !important;
  }
  .pagination-summary-group,
  .pagination-controls-wrap > div:last-child {
    margin-left: 0 !important;
    width: 100% !important;
    justify-content: space-between !important;
    font-size: 0.74rem !important;
    border-top: 1px dashed #e2e8f0 !important;
    padding-top: 8px !important;
  }

  /* Modal Responsiveness */
  #createMarksheetModal,
  #bulkAddSubjectModal {
    padding: 12px !important;
  }
  #createMarksheetModal .hrms-modal-content,
  #bulkAddSubjectModal .hrms-modal-content {
    padding: 16px 14px !important;
    border-radius: 12px !important;
    max-height: 94vh !important;
  }
  .modal-form-grid {
    grid-template-columns: 1fr !important;
    gap: 12px !important;
  }
  .modal-calc-ribbon {
    flex-direction: column !important;
    align-items: flex-start !important;
    gap: 6px !important;
    padding: 8px 12px !important;
  }
  .modal-action-footer {
    flex-direction: column-reverse !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .modal-action-footer button {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
  }
}

/* Mobile Screens (<= 576px) */
@media (max-width: 576px) {
  .report-card-container {
    padding: 12px 10px !important;
  }
  .report-brand-row {
    gap: 6px !important;
  }
  .report-brand-logo-wrap,
  .verification-qr-wrap {
    width: 44px !important;
  }
  .report-brand-row img.school-logo-img {
    width: 40px !important;
    height: 40px !important;
  }
  .report-brand-row .verification-qr-wrap img {
    width: 38px !important;
    height: 38px !important;
  }
  .report-school-title {
    font-size: 0.98rem !important;
  }
  .report-school-tagline {
    font-size: 0.60rem !important;
  }
  .report-school-subinfo {
    font-size: 0.58rem !important;
    display: none !important;
  }
  .report-session-ribbon {
    font-size: 0.60rem !important;
    padding: 3px 8px !important;
    margin-top: 6px !important;
  }
  .report-card-container .report-details-grid {
    grid-template-columns: 1fr !important;
    gap: 6px !important;
    padding: 8px 10px !important;
  }
  .detail-item {
    justify-content: space-between !important;
  }
  .report-card-container .report-table {
    min-width: 440px !important;
  }
  .report-card-container .report-table th,
  .report-card-container .report-table td {
    padding: 6px 6px !important;
    font-size: 0.72rem !important;
  }
  .report-card-container .summary-kpi-card {
    padding: 6px 4px !important;
  }
  .kpi-title {
    font-size: 0.58rem !important;
  }
  .kpi-val {
    font-size: 1.05rem !important;
  }
  .report-signatures-row {
    gap: 4px !important;
  }
  .sig-block .sig-crest-circle {
    width: 34px !important;
    height: 34px !important;
    font-size: 6px !important;
  }
  .sig-crest-lbl {
    font-size: 6px !important;
  }
  .sig-line {
    font-size: 0.62rem !important;
  }

  #modalSubjectsTable th,
  #modalSubjectsTable td {
    padding: 6px 4px !important;
    font-size: 11px !important;
  }
  #modalSubjectsTable input {
    padding: 5px 6px !important;
    font-size: 11px !important;
  }
}

/* Micro Devices (<= 360px) */
@media (max-width: 360px) {
  .academic-stat-grid {
    grid-template-columns: 1fr !important;
  }
  .marksheet-filter-row {
    grid-template-columns: 1fr !important;
  }
  .report-card-container .report-summary-kpi-row {
    grid-template-columns: 1fr !important;
  }
  .report-signatures-row {
    flex-direction: column !important;
    align-items: center !important;
    gap: 12px !important;
  }
  .sig-block {
    width: 100% !important;
    max-width: 160px !important;
  }
}

/* ── Grade Pill Badges Base Styles ── */
.grade-pill-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 12px;
  font-weight: 800;
  font-size: 11px;
}
.grade-pill-badge.pass {
  background: #e0f2fe;
  color: #0284c7;
}
.grade-pill-badge.fail {
  background: #fee2e2;
  color: #dc2626;
}

/* ══════════════════════════════════════════════════════════════════════
   DARK THEME COMPREHENSIVE ADAPTATIONS FOR MARKSHEET
   ══════════════════════════════════════════════════════════════════════ */
[data-theme="dark"] .academic-stat-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
}
[data-theme="dark"] .stat-metric-val {
  color: #f8fafc !important;
}
[data-theme="dark"] .stat-metric-lbl {
  color: #94a3b8 !important;
}

/* Top Scholar Control Card */
[data-theme="dark"] .scholar-control-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3) !important;
}
[data-theme="dark"] .current-scholar-meta h4,
[data-theme="dark"] .current-scholar-meta h4 span {
  color: #f8fafc !important;
}
[data-theme="dark"] .current-scholar-meta .meta-pills span,
[data-theme="dark"] .current-scholar-meta .meta-pills span[style*="color: #64748b"],
[data-theme="dark"] .current-scholar-meta .meta-pills span[style*="color:#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .current-scholar-meta .meta-pills span[style*="color: #cbd5e1"],
[data-theme="dark"] .current-scholar-meta .meta-pills span[style*="color:#cbd5e1"] {
  color: #475569 !important;
}
[data-theme="dark"] .roll-badge-pill {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.35) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .marksheet-exam-form label,
[data-theme="dark"] .marksheet-exam-form label[style*="color: #475569"],
[data-theme="dark"] .marksheet-exam-form label[style*="color:#475569"] {
  color: #cbd5e1 !important;
}
[data-theme="dark"] .marksheet-exam-select {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] .marksheet-exam-select option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .marksheet-print-btn {
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35) !important;
}
[data-theme="dark"] .marksheet-print-btn:hover {
  background: linear-gradient(135deg, #0369a1 0%, #075985 100%) !important;
  box-shadow: 0 6px 18px rgba(2, 132, 199, 0.45) !important;
}

/* Official Report Card Container (Always Pure White in Both Light & Dark Mode) */
.report-card-container,
[data-theme="dark"] .report-card-container {
  background: #ffffff !important;
  border: 2px solid #0092df !important;
  color: #0f172a !important;
}
[data-theme="dark"] .report-card-container {
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(0, 146, 223, 0.3) !important;
}
[data-theme="dark"] .report-school-title {
  color: #007cbd !important;
}
[data-theme="dark"] .report-school-tagline {
  color: #334155 !important;
}
[data-theme="dark"] .report-school-subinfo,
[data-theme="dark"] .report-school-subinfo[style*="color: #64748b"],
[data-theme="dark"] .report-school-subinfo[style*="color:#64748b"] {
  color: #64748b !important;
}
[data-theme="dark"] .verification-qr-wrap > div {
  border-color: #cbd5e1 !important;
  background: #ffffff !important;
}
[data-theme="dark"] .report-card-container .report-details-grid {
  background: #f8fafc !important;
  border: 1px solid #e2e8f0 !important;
}
[data-theme="dark"] .report-card-container .detail-item strong {
  color: #475569 !important;
}
[data-theme="dark"] .report-card-container .detail-item span {
  color: #0f172a !important;
}
[data-theme="dark"] .report-card-container .detail-item span[style*="color: #0f172a"],
[data-theme="dark"] .report-card-container .detail-item span[style*="color:#0f172a"] {
  color: #0f172a !important;
}
[data-theme="dark"] .report-card-container .detail-item span[style*="color: #007cbd"],
[data-theme="dark"] .report-card-container .detail-item span[style*="color:#007cbd"] {
  color: #007cbd !important;
}
[data-theme="dark"] .report-card-container .detail-item span[style*="color: #475569"],
[data-theme="dark"] .report-card-container .detail-item span[style*="color:#475569"] {
  color: #475569 !important;
}
[data-theme="dark"] .report-card-container .detail-item span span[style*="color: #64748b"],
[data-theme="dark"] .report-card-container .detail-item span span[style*="color:#64748b"] {
  color: #64748b !important;
}
[data-theme="dark"] .report-card-container .detail-item span[style*="background: #e0f2fe"],
[data-theme="dark"] .report-card-container .detail-item span[style*="background:#e0f2fe"] {
  background: #e0f2fe !important;
  border: 1px solid #bae6fd !important;
  color: #0284c7 !important;
}

/* Statement of Marks Table (Always White & Clean) */
[data-theme="dark"] .report-table {
  border: 1px solid #cbd5e1 !important;
}
[data-theme="dark"] .report-table th,
[data-theme="dark"] .report-table td {
  border: 1px solid #cbd5e1 !important;
  color: #0f172a !important;
}
[data-theme="dark"] .report-table thead th {
  background: #0f172a !important;
  color: #ffffff !important;
}
[data-theme="dark"] .report-table tbody tr:nth-child(even) {
  background: #fcfdfe !important;
}
[data-theme="dark"] .report-table tbody tr:nth-child(odd) {
  background: #ffffff !important;
}
[data-theme="dark"] .report-table tbody tr:hover {
  background: #f0f9ff !important;
}
[data-theme="dark"] .report-table tbody td[style*="color: #1e293b"],
[data-theme="dark"] .report-table tbody td[style*="color:#1e293b"] {
  color: #1e293b !important;
}
[data-theme="dark"] .report-table tbody td[style*="color: #64748b"],
[data-theme="dark"] .report-table tbody td[style*="color:#64748b"] {
  color: #64748b !important;
}
[data-theme="dark"] .report-table tbody td[style*="color: #059669"],
[data-theme="dark"] .report-table tbody td[style*="color:#059669"] {
  color: #059669 !important;
}
[data-theme="dark"] .report-table tbody td[style*="color: #dc2626"],
[data-theme="dark"] .report-table tbody td[style*="color:#dc2626"] {
  color: #dc2626 !important;
}
[data-theme="dark"] .report-table tbody tr:last-child {
  background: #f8fafc !important;
  border-top: 2px solid #0092df !important;
}
[data-theme="dark"] .report-table tbody tr:last-child td {
  color: #0f172a !important;
}
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color: #0f172a"],
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color:#0f172a"] {
  color: #0f172a !important;
}
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color: #334155"],
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color:#334155"] {
  color: #334155 !important;
}
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color: #007cbd"],
[data-theme="dark"] .report-table tbody tr:last-child td[style*="color:#007cbd"] {
  color: #007cbd !important;
}
[data-theme="dark"] .grade-pill-badge.pass {
  background: #dcfce7 !important;
  color: #15803d !important;
}
[data-theme="dark"] .grade-pill-badge.fail {
  background: #fee2e2 !important;
  color: #b91c1c !important;
}

/* Performance KPI Badges */
[data-theme="dark"] .report-card-container .summary-kpi-card.percentage {
  background: #f0fdf4 !important;
  border-color: #bbf7d0 !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.percentage .kpi-title,
[data-theme="dark"] .report-card-container .summary-kpi-card.percentage .kpi-title[style*="color: #15803d"] {
  color: #15803d !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.percentage .kpi-val,
[data-theme="dark"] .report-card-container .summary-kpi-card.percentage .kpi-val[style*="color: #166534"] {
  color: #166534 !important;
}

[data-theme="dark"] .report-card-container .summary-kpi-card.grade {
  background: #eff6ff !important;
  border-color: #bfdbfe !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.grade .kpi-title,
[data-theme="dark"] .report-card-container .summary-kpi-card.grade .kpi-title[style*="color: #1d4ed8"] {
  color: #1d4ed8 !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.grade .kpi-val,
[data-theme="dark"] .report-card-container .summary-kpi-card.grade .kpi-val[style*="color: #1e40af"] {
  color: #1e40af !important;
}

[data-theme="dark"] .report-card-container .summary-kpi-card.pass {
  background: #f0fdf4 !important;
  border-color: #86efac !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.pass .kpi-title,
[data-theme="dark"] .report-card-container .summary-kpi-card.pass .kpi-title[style*="color: #15803d"] {
  color: #15803d !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.pass .kpi-val,
[data-theme="dark"] .report-card-container .summary-kpi-card.pass .kpi-val[style*="color: #166534"] {
  color: #166534 !important;
}

[data-theme="dark"] .report-card-container .summary-kpi-card.fail {
  background: #fef2f2 !important;
  border-color: #fca5a5 !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.fail .kpi-title,
[data-theme="dark"] .report-card-container .summary-kpi-card.fail .kpi-title[style*="color: #991b1b"] {
  color: #991b1b !important;
}
[data-theme="dark"] .report-card-container .summary-kpi-card.fail .kpi-val,
[data-theme="dark"] .report-card-container .summary-kpi-card.fail .kpi-val[style*="color: #b91c1c"] {
  color: #b91c1c !important;
}

/* Remarks & Signatures */
[data-theme="dark"] .report-remarks-card {
  background: #f8fafc !important;
  border: 1px solid #e2e8f0 !important;
  border-left: 4px solid #0092df !important;
  color: #334155 !important;
}
[data-theme="dark"] .report-remarks-card i {
  color: #0092df !important;
}
[data-theme="dark"] .report-remarks-card strong {
  color: #0f172a !important;
}
[data-theme="dark"] .report-remarks-card div div,
[data-theme="dark"] .report-remarks-card div div[style*="color: #475569"] {
  color: #475569 !important;
}
[data-theme="dark"] .report-signatures-row {
  border-top: 1px solid #cbd5e1 !important;
  color: #475569 !important;
}
[data-theme="dark"] .sig-line {
  border-top: 1px solid #94a3b8 !important;
  color: #475569 !important;
}
[data-theme="dark"] .sig-crest-circle {
  border-color: #0092df !important;
  color: #0092df !important;
}
[data-theme="dark"] .sig-crest-circle span[style*="color: #64748b"] {
  color: #64748b !important;
}
[data-theme="dark"] .sig-principal-name {
  color: #007cbd !important;
}

/* Empty State Card */
[data-theme="dark"] .report-empty-state-card {
  background: #1e293b !important;
  border-color: #334155 !important;
  border-radius: 14px !important;
  -webkit-border-radius: 14px !important;
}
[data-theme="dark"] .report-empty-state-card div[style*="background: #e0f2fe"],
[data-theme="dark"] .report-empty-state-card div[style*="background:#e0f2fe"] {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .report-empty-state-card h3 {
  color: #f8fafc !important;
}
[data-theme="dark"] .report-empty-state-card p {
  color: #94a3b8 !important;
}
[data-theme="dark"] .report-empty-state-card p strong {
  color: #f8fafc !important;
}

/* Filter Toolbar */
[data-theme="dark"] .roaster-toolbar-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3) !important;
}

/* Search Box with Radius Fix */
[data-theme="dark"] .roaster-search-box {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-search-box:focus-within {
  background: #0f172a !important;
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-search-box i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-search-box input {
  background: transparent !important;
  border: none !important;
  outline: none !important;
  box-shadow: none !important;
  border-radius: 0 !important;
  -webkit-border-radius: 0 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-search-box input::placeholder {
  color: #64748b !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn {
  background: #334155 !important;
  color: #94a3b8 !important;
  border-radius: 50% !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn:hover {
  background: #475569 !important;
  color: #f8fafc !important;
}

/* Select Box with Radius Fix */
[data-theme="dark"] .roaster-select-box {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-select-box > i:first-child,
[data-theme="dark"] .roaster-select-box .select-chevron {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-select-box select {
  background: #0f172a !important;
  border: none !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] .roaster-select-box select:focus {
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-select-box select option,
[data-theme="dark"] .roaster-select-box select optgroup {
  background: #0f172a !important;
  color: #f8fafc !important;
}

/* Toolbar Buttons */
[data-theme="dark"] .roaster-btn,
[data-theme="dark"] .roaster-btn.secondary {
  background: #334155 !important;
  color: #f1f5f9 !important;
  border: 1px solid #475569 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-btn.secondary:hover {
  background: #475569 !important;
  color: #ffffff !important;
  border-color: #64748b !important;
}
[data-theme="dark"] .roaster-btn.ghost {
  color: #94a3b8 !important;
  background: transparent !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] .roaster-btn.ghost:hover {
  color: #f87171 !important;
  background: rgba(239, 68, 68, 0.15) !important;
}

/* Live Counts Badge */
[data-theme="dark"] .scholars-count-badge {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .scholars-count-badge strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .scholars-count-badge .count-dot {
  background: #10b981 !important;
  box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7) !important;
}

/* Scholar Academic Directory Card */
[data-theme="dark"] .marksheet-directory-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 12px !important;
  -webkit-border-radius: 12px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3) !important;
}
[data-theme="dark"] .marksheet-card-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .marksheet-title-block .card-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .marksheet-session-badge {
  background: #0f172a !important;
  color: #cbd5e1 !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
}
[data-theme="dark"] .marksheet-title-block p {
  color: #94a3b8 !important;
}
[data-theme="dark"] .marksheet-title-block p strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .marksheet-records-count {
  border-top-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .marksheet-records-count strong,
[data-theme="dark"] .marksheet-records-count strong[style*="color: #0f172a"],
[data-theme="dark"] .marksheet-records-count strong[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .ms-generate-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .ms-generate-btn:hover {
  background: #334155 !important;
  border-color: #059669 !important;
  color: #34d399 !important;
}
[data-theme="dark"] .ms-generate-btn i {
  color: #34d399 !important;
}

/* Directory Table */
[data-theme="dark"] .marksheet-table thead th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .marksheet-table tbody td {
  background: transparent !important;
  border-bottom: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .marksheet-table tbody tr:hover {
  background-color: rgba(51, 65, 85, 0.3) !important;
}
[data-theme="dark"] .marksheet-table tbody tr.active-student-row {
  background-color: rgba(2, 132, 199, 0.15) !important;
}
[data-theme="dark"] .marksheet-table tbody tr.active-student-row td:first-child {
  border-left: 3px solid #38bdf8 !important;
}
[data-theme="dark"] .marksheet-table tbody td .user-cell > div > div:first-child,
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #0f172a"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #64748b"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#64748b"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #94a3b8"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#94a3b8"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #64748b"] i,
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#64748b"] i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #334155"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#334155"] {
  color: #f1f5f9 !important;
}
[data-theme="dark"] .marksheet-table tbody td .staff-avatar-img {
  border-color: #334155 !important;
}
[data-theme="dark"] .marksheet-table tbody td .staff-avatar-init,
[data-theme="dark"] .marksheet-table tbody td .user-cell .staff-avatar-init {
  background: #334155 !important;
  color: #f8fafc !important;
  border: 1px solid #475569 !important;
}

/* Badges & Chips */
[data-theme="dark"] .ms-std-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .ms-std-pill i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .ms-roll-pill {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .ms-blood-badge {
  background: rgba(225, 29, 72, 0.15) !important;
  border: 1px solid rgba(225, 29, 72, 0.3) !important;
  border-radius: 4px !important;
  -webkit-border-radius: 4px !important;
  color: #fb7185 !important;
}
[data-theme="dark"] .ms-exam-chip {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .ms-exam-chip i {
  color: #38bdf8 !important;
}

/* Performance Badges */
[data-theme="dark"] .ms-perf-badge.pass {
  background: rgba(22, 101, 52, 0.2) !important;
  border: 1px solid rgba(22, 101, 52, 0.4) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #4ade80 !important;
}
[data-theme="dark"] .ms-perf-badge.fail {
  background: rgba(220, 38, 38, 0.2) !important;
  border: 1px solid rgba(220, 38, 38, 0.4) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #f87171 !important;
}
[data-theme="dark"] .ms-perf-badge.none {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #166534"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#166534"] {
  color: #4ade80 !important;
}
[data-theme="dark"] .marksheet-table tbody td div[style*="color: #991b1b"],
[data-theme="dark"] .marksheet-table tbody td div[style*="color:#991b1b"] {
  color: #f87171 !important;
}

/* Status Badges */
[data-theme="dark"] .ms-status-active {
  background: rgba(2, 132, 199, 0.2) !important;
  border: 1px solid rgba(2, 132, 199, 0.4) !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .ms-status-active .pulse-dot {
  background: #38bdf8 !important;
}
[data-theme="dark"] .ms-status-verified {
  background: rgba(22, 101, 52, 0.2) !important;
  border: 1px solid rgba(22, 101, 52, 0.4) !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
  color: #4ade80 !important;
}
[data-theme="dark"] .ms-status-pending {
  background: rgba(202, 138, 4, 0.18) !important;
  border: 1px solid rgba(202, 138, 4, 0.4) !important;
  border-radius: 20px !important;
  -webkit-border-radius: 20px !important;
  color: #facc15 !important;
}

/* Action Buttons in Directory Table */
[data-theme="dark"] .ms-btn-action,
[data-theme="dark"] .ms-btn-secondary {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .ms-btn-secondary:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .ms-btn-secondary i[style*="color: #0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .ms-btn-secondary i[style*="color: #059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .ms-btn-action[style*="background: #f0f9ff"],
[data-theme="dark"] .ms-btn-action[style*="background:#f0f9ff"] {
  background: rgba(2, 132, 199, 0.2) !important;
  border-color: rgba(2, 132, 199, 0.4) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .ms-btn-action[style*="background: #f0f9ff"]:hover,
[data-theme="dark"] .ms-btn-action[style*="background:#f0f9ff"]:hover {
  background: rgba(2, 132, 199, 0.3) !important;
  border-color: #38bdf8 !important;
  color: #ffffff !important;
}

/* Pagination Controls & Footer */
[data-theme="dark"] .pagination-controls-wrap {
  background: #1e293b !important;
  border-top: 1px solid #334155 !important;
}
[data-theme="dark"] .pagination-meta-group span,
[data-theme="dark"] .pagination-meta-group span[style*="color: #475569"],
[data-theme="dark"] .pagination-meta-group span[style*="color:#475569"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-meta-group span strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-limit-box label,
[data-theme="dark"] .pagination-limit-box label[style*="color: #64748b"],
[data-theme="dark"] .pagination-limit-box label[style*="color:#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-limit-select {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] .pagination-limit-select option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .pagination-btn:hover:not(.disabled) {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn.active {
  background: var(--hrms-primary, #0092df) !important;
  border-color: var(--hrms-primary, #0092df) !important;
  color: #ffffff !important;
}
[data-theme="dark"] .pagination-btn.disabled {
  background: #0f172a !important;
  border-color: #1e293b !important;
  color: #475569 !important;
  opacity: 0.5 !important;
}
[data-theme="dark"] .pagination-ellipsis {
  color: #64748b !important;
}
[data-theme="dark"] .pagination-summary-group,
[data-theme="dark"] .pagination-controls-wrap > div:last-child {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-summary-group strong,
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong,
[data-theme="dark"] .pagination-summary-group span strong[style*="color: #334155"],
[data-theme="dark"] .pagination-summary-group span strong[style*="color:#334155"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-summary-group span strong[style*="color: #0284c7"],
[data-theme="dark"] .pagination-summary-group span strong[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pagination-summary-group span[style*="color: #cbd5e1"],
[data-theme="dark"] .pagination-summary-group span[style*="color:#cbd5e1"] {
  color: #475569 !important;
}

/* Empty States in Table */
[data-theme="dark"] .marksheet-table tbody td div[style*="background: #f1f5f9"],
[data-theme="dark"] .marksheet-table tbody td div[style*="background:#f1f5f9"] {
  background: #0f172a !important;
  color: #64748b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .marksheet-table tbody td h4[style*="color: #0f172a"],
[data-theme="dark"] .marksheet-table tbody td h4[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .marksheet-table tbody td p[style*="color: #64748b"] strong {
  color: #f8fafc !important;
}

/* Modal: Create Marksheet Form & Bulk Subject Modal */
[data-theme="dark"] #createMarksheetModal .hrms-modal-content,
[data-theme="dark"] #bulkAddSubjectModal .hrms-modal-content {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 16px !important;
  -webkit-border-radius: 16px !important;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7) !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal .hrms-modal-content > div:first-child,
[data-theme="dark"] #bulkAddSubjectModal .hrms-modal-content > div:first-child {
  border-bottom: 1.5px solid #334155 !important;
}
[data-theme="dark"] #createMarksheetModal h3,
[data-theme="dark"] #bulkAddSubjectModal h3 {
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal .hrms-modal-content button[onclick*="closeCreateMarksheetModal"],
[data-theme="dark"] #bulkAddSubjectModal .hrms-modal-content button[onclick*="closeBulkAddSubjectModal"] {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 50% !important;
  color: #cbd5e1 !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #createMarksheetModal .hrms-modal-content button[onclick*="closeCreateMarksheetModal"]:hover,
[data-theme="dark"] #bulkAddSubjectModal .hrms-modal-content button[onclick*="closeBulkAddSubjectModal"]:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal label,
[data-theme="dark"] #bulkAddSubjectModal label {
  color: #cbd5e1 !important;
}
[data-theme="dark"] #createMarksheetModal label[style*="color: #334155"],
[data-theme="dark"] #createMarksheetModal label[style*="color:#334155"],
[data-theme="dark"] #createMarksheetModal label[style*="color: #0f172a"],
[data-theme="dark"] #createMarksheetModal label[style*="color:#0f172a"],
[data-theme="dark"] #bulkAddSubjectModal label[style*="color: #334155"],
[data-theme="dark"] #bulkAddSubjectModal label[style*="color:#334155"],
[data-theme="dark"] #bulkAddSubjectModal label[style*="color: #0f172a"],
[data-theme="dark"] #bulkAddSubjectModal label[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal .hrms-input,
[data-theme="dark"] #bulkAddSubjectModal .hrms-input {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #f8fafc !important;
  color-scheme: dark !important;
}
[data-theme="dark"] #createMarksheetModal .hrms-input:focus,
[data-theme="dark"] #bulkAddSubjectModal .hrms-input:focus {
  background: #0f172a !important;
  border-color: var(--hrms-primary, #0092df) !important;
  color: #ffffff !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] #createMarksheetModal select.hrms-input option,
[data-theme="dark"] #bulkAddSubjectModal select.hrms-input option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal input[type="date"]::-webkit-calendar-picker-indicator,
[data-theme="dark"] #bulkAddSubjectModal input[type="date"]::-webkit-calendar-picker-indicator {
  filter: invert(1) brightness(0.9);
  cursor: pointer;
  opacity: 0.9;
}
[data-theme="dark"] #createMarksheetModal input[type="date"]::-webkit-calendar-picker-indicator:hover,
[data-theme="dark"] #bulkAddSubjectModal input[type="date"]::-webkit-calendar-picker-indicator:hover {
  opacity: 1;
}
[data-theme="dark"] #bulkAddSubjectModal div[style*="background: #f8fafc"] {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] #bulkStudentTable thead tr {
  background: #0f172a !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #bulkStudentTable th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #bulkStudentTable tbody tr {
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #bulkStudentTable td {
  border-color: #334155 !important;
}
[data-theme="dark"] #createMarksheetModal button[onclick*="addSubjectRow"] {
  background: rgba(22, 101, 52, 0.2) !important;
  border: 1px solid rgba(22, 101, 52, 0.45) !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #4ade80 !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #createMarksheetModal button[onclick*="addSubjectRow"]:hover {
  background: rgba(22, 101, 52, 0.35) !important;
  border-color: #4ade80 !important;
  color: #86efac !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable {
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable thead tr {
  background: #0f172a !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable tbody tr {
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable td {
  border-color: #334155 !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable .hrms-input {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  -webkit-border-radius: 6px !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable .sub-obt-input {
  color: #38bdf8 !important;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable button[onclick*="removeSubjectRow"] {
  color: #f87171 !important;
  transition: color 0.15s ease;
}
[data-theme="dark"] #createMarksheetModal #modalSubjectsTable button[onclick*="removeSubjectRow"]:hover {
  color: #ef4444 !important;
}

/* Modal Calculation Ribbon */
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
}
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon span[style*="color: #0369a1"],
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon span[style*="color:#0369a1"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon #calcTotalObtained {
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon #calcTotalMax {
  color: #94a3b8 !important;
}
[data-theme="dark"] #createMarksheetModal .modal-calc-ribbon #calcPercentage {
  color: #38bdf8 !important;
}

/* Modal Action Footer */
[data-theme="dark"] #createMarksheetModal .action-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #cbd5e1 !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #createMarksheetModal .action-btn:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #createMarksheetModal .action-primary-btn {
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
  border-radius: 8px !important;
  -webkit-border-radius: 8px !important;
  color: #ffffff !important;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.4) !important;
}
[data-theme="dark"] #createMarksheetModal .action-primary-btn:hover {
  background: linear-gradient(135deg, #0369a1 0%, #075985 100%) !important;
  box-shadow: 0 6px 18px rgba(2, 132, 199, 0.5) !important;
}
</style>


<!-- ══════════════════════════════════════════════════════
     TOP SCHOLAR CONTROL & EXAM SELECTION BAR
     ══════════════════════════════════════════════════════ -->
<div class="scholar-control-card no-print">
  
  <!-- Current Scholar Info Pill -->
  <div class="current-scholar-pill">
    <?php 
      $cur_has_photo = false;
      if ($student_profile && !empty($student_profile['photo']) && $student_profile['photo'] !== '/assets/imgs/ksv-logo.jpg') {
          $cur_photo_rel = ltrim($student_profile['photo'], '/\\');
          $cur_photo_path = realpath(__DIR__ . '/../../' . $cur_photo_rel);
          if ($cur_photo_path && (
              ($allowed_base_uploads && strpos($cur_photo_path, $allowed_base_uploads) === 0) ||
              ($allowed_base_assets && strpos($cur_photo_path, $allowed_base_assets) === 0)
          ) && file_exists($cur_photo_path)) {
              $cur_has_photo = true;
          }
      }
      $cur_first_letter = $student_profile ? strtoupper(substr($student_profile['student_name'] ?? 'S', 0, 1)) : 'S';
      $cur_avatar_bg = $grad_palette[ord($cur_first_letter) % count($grad_palette)];
    ?>
    <?php if ($cur_has_photo): ?>
      <img src="<?php echo htmlspecialchars($student_profile['photo'], ENT_QUOTES, 'UTF-8'); ?>" alt="" class="scholar-mini-avatar">
    <?php else: ?>
      <div class="scholar-mini-init" style="background: <?php echo $cur_avatar_bg; ?>;">
        <?php echo htmlspecialchars($cur_first_letter, ENT_QUOTES, 'UTF-8'); ?>
      </div>
    <?php endif; ?>

    <div class="current-scholar-meta">
      <h4>
        <span><?php echo htmlspecialchars($student_profile['student_name'] ?? 'Select Scholar', ENT_QUOTES, 'UTF-8'); ?></span>
        <?php if ($student_profile): ?>
          <span class="roll-badge-pill" style="font-size: 0.7rem; padding: 2px 6px;">
            <?php echo htmlspecialchars($student_profile['roll_no'], ENT_QUOTES, 'UTF-8'); ?>
          </span>
        <?php endif; ?>
      </h4>
      <div class="meta-pills">
        <span style="color: #64748b;">
          <?php echo htmlspecialchars($student_profile['standard'] ?? 'Standard', ENT_QUOTES, 'UTF-8'); ?> &bull; Section <?php echo htmlspecialchars($student_profile['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <span style="color: #cbd5e1;">&bull;</span>
        <a href="#student-directory" style="color: var(--hrms-primary); text-decoration: none; font-weight: 700;">
          <i class="fa-solid fa-list-check"></i> Browse Directory
        </a>
      </div>
    </div>
  </div>

  <!-- Right: Exam Selector & Action Buttons -->
  <div class="marksheet-top-actions" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
    
    <?php if (!empty($student_marksheets)): ?>
      <form method="GET" action="<?php echo htmlspecialchars(ADMIN_URL . '/marksheet', ENT_QUOTES, 'UTF-8'); ?>" class="marksheet-exam-form" style="display: flex; align-items: center; gap: 8px; flex-wrap: nowrap;">
        <input type="hidden" name="student_id" value="<?php echo intval($selected_student_id); ?>">
        <?php if (!empty($search)): ?>
          <input type="hidden" name="search" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>">
        <?php endif; ?>
        <?php if (!empty($filter_standard)): ?>
          <input type="hidden" name="standard" value="<?php echo htmlspecialchars($filter_standard, ENT_QUOTES, 'UTF-8'); ?>">
        <?php endif; ?>
        <?php if ($limit !== 10): ?>
          <input type="hidden" name="limit" value="<?php echo intval($limit); ?>">
        <?php endif; ?>
        <?php if ($page > 1): ?>
          <input type="hidden" name="page" value="<?php echo intval($page); ?>">
        <?php endif; ?>
        <label style="font-size: 13px; font-weight: 700; color: #475569; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; flex-shrink: 0;">
          <i class="fa-solid fa-book-bookmark" style="color: #0092df;"></i> <span>Exam:</span>
        </label>
        <select name="marksheet_id" onchange="this.form.submit()" class="hrms-input marksheet-exam-select" style="padding: 8px 14px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; border: 1.5px solid #cbd5e1; background: #f8fafc;">
          <?php foreach ($student_marksheets as $m_item): ?>
            <option value="<?php echo intval($m_item['id']); ?>" <?php echo ($active_marksheet && $m_item['id'] == $active_marksheet['id']) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($m_item['exam_name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo htmlspecialchars($m_item['percentage'], ENT_QUOTES, 'UTF-8'); ?>% • <?php echo htmlspecialchars($m_item['overall_grade'], ENT_QUOTES, 'UTF-8'); ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </form>
    <?php endif; ?>

    <?php if ($active_marksheet): ?>
      <button type="button" onclick="downloadMarksheetPNG();" class="ms-btn-action ms-btn-secondary" style="font-size: 0.76rem; font-weight: 700; gap: 6px; padding: 8px 14px; border-radius: 8px; cursor: pointer; border: 1.5px solid #cbd5e1; background: #ffffff; color: #334155;">
        <i class="fa-solid fa-download" style="color: #0284c7;"></i>
        <span>Download (PNG)</span>
      </button>
      <button type="button" onclick="window.print();" class="action-primary-btn marksheet-print-btn" style="background: #0092df; color: #ffffff; border: none; padding: 9px 18px; border-radius: 8px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(0, 146, 223, 0.25);">
        <i class="fa-solid fa-print"></i>
        <span>Print Report Card</span>
      </button>
    <?php endif; ?>

  </div>

</div>

<!-- ══════════════════════════════════════════════════════
     OFFICIAL PRINTABLE REPORT CARD (High-End Certificate Style)
     ══════════════════════════════════════════════════════ -->
<?php if ($active_marksheet && $student_profile): ?>
  <?php 
    $subjects = json_decode($active_marksheet['subjects_json'], true) ?: [];
    $is_overall_pass = ($active_marksheet['result_status'] === 'PASS');
    $sub_count = count($subjects);
    if ($sub_count <= 4) {
        $tier_class = 'tier-few';
    } elseif ($sub_count <= 7) {
        $tier_class = 'tier-medium';
    } elseif ($sub_count <= 10) {
        $tier_class = 'tier-compact';
    } else {
        $tier_class = 'tier-dense';
    }
  ?>
  <div id="report-card-view" class="marksheet-print-canvas report-card-container <?php echo $tier_class; ?>" data-sub-count="<?php echo $sub_count; ?>">
    
    <!-- Watermark Logo -->
    <div style="position: absolute; top: 52%; left: 50%; transform: translate(-50%, -50%); opacity: 0.04; pointer-events: none; z-index: 0;">
      <img src="<?php echo htmlspecialchars($school_settings['logo_url'] ?? '/assets/imgs/ksv-logo.jpg', ENT_QUOTES, 'UTF-8'); ?>" alt="" style="width: 360px; height: 360px;">
    </div>

    <!-- Official Header Section -->
    <div class="report-header-banner">
      <div class="report-brand-row">
        
        <!-- Left: Academy Crest -->
        <div class="report-brand-logo-wrap" style="width: 80px; text-align: left;">
          <img class="school-logo-img" src="<?php echo htmlspecialchars($school_settings['logo_url'] ?? '/assets/imgs/ksv-logo.jpg', ENT_QUOTES, 'UTF-8'); ?>" alt="KSV Logo" style="width: 64px; height: 64px; border-radius: 50%; border: 2px solid #0092df; padding: 2px; background: #ffffff;">
        </div>

        <!-- Center: Institutional Identity -->
        <div class="report-brand-center" style="flex: 1; text-align: center;">
          <h1 class="report-school-title">
            <?php echo htmlspecialchars($school_settings['school_name'] ?? 'KSV Academy', ENT_QUOTES, 'UTF-8'); ?>
          </h1>
          <div class="report-school-tagline">
            <?php echo htmlspecialchars($school_settings['tagline'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
          </div>
          <div class="report-school-subinfo" style="font-size: 11px; color: #64748b; margin-top: 4px;">
            <?php echo htmlspecialchars($school_settings['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?> &bull; Helpline: <?php echo htmlspecialchars($school_settings['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
          </div>
        </div>

        <!-- Right: Verification QR Code -->
        <div class="verification-qr-wrap" style="width: 80px; text-align: right;">
          <?php if (!empty($verification_qr_url)): ?>
            <div style="display: inline-block; padding: 4px; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);" title="Biometric QR Verification Pass">
              <img src="<?php echo htmlspecialchars($verification_qr_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Verification QR" style="width: 58px; height: 58px; display: block;">
              <span class="qr-verify-badge" style="font-size: 7.5px; font-weight: 800; color: #0284c7; text-transform: uppercase; display: block; text-align: center; margin-top: 2px;">VERIFIED</span>
            </div>
          <?php endif; ?>
        </div>

      </div>
      
      <!-- Academic Session Ribbon -->
      <div class="report-session-ribbon">
        <i class="fa-solid fa-award"></i>
        <span>STATEMENT OF ACADEMIC MARKS &bull; SESSION <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></span>
      </div>
    </div>

    <!-- Student & Exam Details Box -->
    <div class="report-details-grid">
      <div class="detail-item">
        <strong>Scholar Name:</strong>
        <span style="font-size: 15px; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
          <?php echo htmlspecialchars($student_profile['student_name'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>
      <div class="detail-item">
        <strong>Class &amp; Section:</strong>
        <span style="font-weight: 800; color: #007cbd;">
          <?php echo htmlspecialchars($student_profile['standard'], ENT_QUOTES, 'UTF-8'); ?> &bull; Section <?php echo htmlspecialchars($student_profile['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>

      <div class="detail-item">
        <strong>Roll Number:</strong>
        <span style="font-family: monospace; font-weight: 800; font-size: 14px; color: #0284c7; background: #e0f2fe; padding: 1px 8px; border-radius: 4px;">
          <?php echo htmlspecialchars($student_profile['roll_no'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>
      <div class="detail-item">
        <strong>Father's Name:</strong>
        <span style="font-weight: 700;">
          <?php echo htmlspecialchars($student_profile['parent_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>

      <div class="detail-item">
        <strong>Admission No:</strong>
        <span style="font-family: monospace; color: #475569; font-weight: 600;">
          <?php echo htmlspecialchars($student_profile['admission_no'] ?? ('ADM-' . $student_profile['id']), ENT_QUOTES, 'UTF-8'); ?>
        </span>
      </div>
      <div class="detail-item">
        <strong>Examination:</strong>
        <span style="color: #0f172a; font-weight: 800;">
          <?php echo htmlspecialchars($active_marksheet['exam_name'], ENT_QUOTES, 'UTF-8'); ?>
          <span style="font-weight: 600; color: #64748b; font-size: 11.5px;">(<?php echo date('M Y', strtotime($active_marksheet['exam_date'])); ?>)</span>
        </span>
      </div>
    </div>

    <!-- Statement of Marks Table -->
    <div class="report-table-responsive" style="position: relative; z-index: 1;">
      <table class="report-table">
        <thead>
          <tr>
            <th style="width: 6%; text-align: center;">#</th>
            <th style="text-align: left; width: 44%;">SUBJECT TITLE</th>
            <th style="width: 14%;">MAX MARKS</th>
            <th style="width: 14%;">PASS MARKS</th>
            <th style="width: 14%;">OBTAINED</th>
            <th style="width: 14%;">GRADE</th>
          </tr>
        </thead>
        <tbody>
          <?php $idx_sub = 1; ?>
          <?php foreach ($subjects as $sub): ?>
            <tr>
              <td style="text-align: center; color: #94a3b8; font-weight: 700;"><?php echo $idx_sub++; ?></td>
              <td style="font-weight: 700; color: #1e293b;"><?php echo htmlspecialchars($sub['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
              <td style="text-align: center; color: #64748b; font-weight: 600;"><?php echo htmlspecialchars($sub['max'] ?? 100, ENT_QUOTES, 'UTF-8'); ?></td>
              <td style="text-align: center; color: #64748b; font-weight: 600;"><?php echo htmlspecialchars($sub['pass'] ?? 35, ENT_QUOTES, 'UTF-8'); ?></td>
              <td style="text-align: center; font-weight: 900; font-size: 14px; font-family: 'Outfit', sans-serif; color: <?php echo ($sub['obtained'] ?? 0) >= ($sub['pass'] ?? 35) ? '#059669' : '#dc2626'; ?>;">
                <?php echo htmlspecialchars($sub['obtained'] ?? 0, ENT_QUOTES, 'UTF-8'); ?>
              </td>
              <td style="text-align: center; font-weight: 800; color: #0284c7;">
                <span class="grade-pill-badge <?php echo ($sub['obtained'] ?? 0) >= ($sub['pass'] ?? 35) ? 'pass' : 'fail'; ?>">
                  <?php echo htmlspecialchars($sub['grade'] ?? 'F', ENT_QUOTES, 'UTF-8'); ?>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
          <!-- Grand Total Row -->
          <tr style="background: #f8fafc; font-weight: 900; font-size: 14px; border-top: 2px solid #0092df;">
            <td colspan="2" style="text-align: left; font-weight: 900; color: #0f172a; letter-spacing: 0.04em;">
              GRAND TOTAL MARKS
            </td>
            <td style="text-align: center; color: #334155;"><?php echo htmlspecialchars($active_marksheet['total_max'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td style="text-align: center; color: #94a3b8;">—</td>
            <td style="text-align: center; color: #007cbd; font-size: 16px; font-family: 'Outfit', sans-serif;"><?php echo htmlspecialchars($active_marksheet['total_obtained'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td style="text-align: center; color: #007cbd;"><?php echo htmlspecialchars($active_marksheet['overall_grade'], ENT_QUOTES, 'UTF-8'); ?></td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Performance Summary KPI Row -->
    <div class="report-summary-kpi-row">
      <div class="summary-kpi-card percentage">
        <div class="kpi-title" style="color: #15803d;">OVERALL PERCENTAGE</div>
        <div class="kpi-val" style="color: #166534;"><?php echo htmlspecialchars($active_marksheet['percentage'], ENT_QUOTES, 'UTF-8'); ?>%</div>
      </div>
      <div class="summary-kpi-card grade">
        <div class="kpi-title" style="color: #1d4ed8;">ACADEMIC GRADE</div>
        <div class="kpi-val" style="color: #1e40af;"><?php echo htmlspecialchars($active_marksheet['overall_grade'], ENT_QUOTES, 'UTF-8'); ?></div>
      </div>
      <div class="summary-kpi-card <?php echo $is_overall_pass ? 'pass' : 'fail'; ?>">
        <div class="kpi-title" style="color: <?php echo $is_overall_pass ? '#15803d' : '#991b1b'; ?>;">EXAMINATION RESULT</div>
        <div class="kpi-val" style="color: <?php echo $is_overall_pass ? '#166534' : '#b91c1c'; ?>; display: flex; align-items: center; justify-content: center; gap: 6px;">
          <i class="fa-solid <?php echo $is_overall_pass ? 'fa-circle-check' : 'fa-circle-xmark'; ?>" style="font-size: 1.1rem;"></i>
          <span><?php echo htmlspecialchars($active_marksheet['result_status'], ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
      </div>
    </div>

    <!-- Remarks Callout -->
    <div class="report-remarks-card">
      <i class="fa-solid fa-quote-left"></i>
      <div>
        <strong>Faculty Evaluation &amp; Discipline Remarks:</strong>
        <div style="margin-top: 3px; font-style: italic; color: #475569;">
          "<?php echo htmlspecialchars($active_marksheet['remarks'] ?? 'Consistent academic effort, good participation and disciplined conduct throughout.', ENT_QUOTES, 'UTF-8'); ?>"
        </div>
      </div>
    </div>

    <!-- Signatures and Official Seals -->
    <div class="report-signatures-row">
      <div class="sig-block">
        <div class="sig-spacer" style="height: 38px;"></div>
        <div class="sig-line">Class Teacher</div>
      </div>
      
      <div class="sig-block">
        <div class="sig-crest-circle" style="width: 54px; height: 54px; border: 2px dashed #0092df; border-radius: 50%; margin: 0 auto 6px; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 8px; color: #0092df; font-weight: 900; line-height: 1.2;">
          <span>KSV</span>
          <span style="font-size: 6.5px; color: #64748b;">OFFICIAL</span>
        </div>
        <div class="sig-crest-lbl" style="font-size: 10px; color: #94a3b8; font-weight: 800; text-transform: uppercase;">Institutional Crest</div>
      </div>

      <div class="sig-block">
        <div class="sig-principal-name" style="font-family: 'Outfit', cursive; font-size: 16px; color: #007cbd; height: 28px; font-weight: 800;">Salam Khan</div>
        <div class="sig-line">Principal Signature</div>
      </div>
    </div>

  </div>
<?php else: ?>
  <div id="report-card-view" class="hrms-card report-empty-state-card" style="text-align: center; padding: 46px 20px; margin-bottom: 28px; border-radius: 14px; border: 1.5px dashed #cbd5e1;">
    <div style="width: 58px; height: 58px; border-radius: 50%; background: #e0f2fe; color: #0284c7; display: flex; align-items: center; justify-content: center; margin: 0 auto 14px; font-size: 1.6rem;">
      <i class="fa-solid fa-file-circle-question"></i>
    </div>
    <h3 style="margin: 0 0 6px; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
      No Marksheet Record Generated Yet
    </h3>
    <p style="margin: 0 0 18px; color: #64748b; font-size: 0.9rem; max-width: 500px; margin-left: auto; margin-right: auto;">
      Scholar <strong><?php echo htmlspecialchars($student_profile['student_name'] ?? 'Selected Scholar', ENT_QUOTES, 'UTF-8'); ?></strong> does not have an evaluation for Session <strong><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong>.
    </p>
    <?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
      <button type="button" onclick="openCreateMarksheetModal(<?php echo intval($selected_student_id); ?>);" class="action-primary-btn" style="background: #0092df; color: #fff; padding: 10px 22px; border-radius: 8px; font-weight: 700; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(0, 146, 223, 0.25);">
        <i class="fa-solid fa-plus-circle"></i> Generate First Marksheet Now
      </button>
    <?php endif; ?>
  </div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════
     FILTER TOOLBAR (Exact match to student-id.php & students.php)
     ══════════════════════════════════════════════════════ -->
<div id="student-directory" class="roaster-toolbar-card no-print" style="margin-top: 30px; margin-bottom: 20px;">
  <div class="roaster-toolbar-inner">
    
    <!-- Filter form -->
    <form method="GET" action="<?php echo htmlspecialchars(ADMIN_URL . '/marksheet', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-filter-form">
      <input type="hidden" name="limit" value="<?php echo intval($limit); ?>">
      <?php if ($selected_student_id > 0): ?>
        <input type="hidden" name="student_id" value="<?php echo intval($selected_student_id); ?>">
      <?php endif; ?>
      <?php if ($selected_marksheet_id > 0): ?>
        <input type="hidden" name="marksheet_id" value="<?php echo intval($selected_marksheet_id); ?>">
      <?php endif; ?>

      <div class="roaster-search-box">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="search" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search student name, roll no, phone..." autocomplete="off">
        <?php if (!empty($search)): ?>
          <a href="<?php echo htmlspecialchars(get_marksheet_pagination_url(1, '', $filter_standard, $selected_student_id, $selected_marksheet_id, $limit), ENT_QUOTES, 'UTF-8'); ?>" class="clear-search-btn" title="Clear search">&times;</a>
        <?php endif; ?>
      </div>

        <div class="marksheet-filter-row" style="display: flex; gap: 8px; align-items: center;">
          <div class="roaster-select-box">
            <i class="fa-solid fa-filter"></i>
            <select name="standard" onchange="this.form.submit()" style="min-width: 175px; max-width: 250px; font-weight: 600; text-overflow: ellipsis;">
              <option value="">All Academic Classes</option>
              <?php echo render_standards_dropdown_options($filter_standard, false, $academic_categories, $custom_db_standards); ?>
            </select>
            <i class="fa-solid fa-chevron-down select-chevron"></i>
          </div>

          <button type="submit" class="roaster-btn secondary">
            <i class="fa-solid fa-sliders"></i> Filter
          </button>

          <?php if (!empty($search) || !empty($filter_standard)): ?>
            <?php 
              $rp = [];
              if ($selected_student_id > 0) $rp['student_id'] = intval($selected_student_id);
              if ($selected_marksheet_id > 0) $rp['marksheet_id'] = intval($selected_marksheet_id);
              if ($limit !== 10) $rp['limit'] = intval($limit);
              $reset_filter_url = ADMIN_URL . '/marksheet' . (!empty($rp) ? '?' . http_build_query($rp) : '');
            ?>
            <a href="<?php echo htmlspecialchars($reset_filter_url, ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn ghost" title="Reset all filters">
              <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
          <?php endif; ?>
        </div>
      </form>

      <!-- Right: Scholars Live Count & Quick Switch to ID Cards -->
      <div class="roaster-toolbar-actions">
        <div class="scholars-count-badge">
          <span class="count-dot"></span>
          <span><strong><?php echo $total_records; ?></strong> Scholars</span>
        </div>
      </div>

    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       STUDENT DATA TABLE (Simple & Sober - Like student-id.php)
       ══════════════════════════════════════════════════════ -->
  <div class="hrms-card no-print marksheet-directory-card" id="marksheetDirectoryCard" style="margin-bottom: 30px; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">
    <div class="hrms-card-header marksheet-card-header" style="border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 16px 20px;">
      <div class="marksheet-title-block">
        <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 1rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif;">
          <i class="fa-solid fa-graduation-cap" style="color: #0284c7;"></i>
          Scholar Academic Directory &amp; Marksheet Register
          <span class="marksheet-session-badge" style="font-size: 0.74rem; font-weight: 600; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
            Session <?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?>
          </span>
        </h3>
        <p style="margin: 3px 0 0; font-size: 0.78rem; color: #64748b;">
          Click <strong>View Report Card</strong> on any student row below to load their official report card above.
        </p>
      </div>

      <div class="marksheet-actions-wrap" style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
        <span class="marksheet-records-count" style="font-size: 0.78rem; color: #64748b; font-weight: 600;">
          Total Records: <strong style="color: #0f172a;"><?php echo intval($total_records); ?></strong>
        </span>
        <?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
          <button type="button" id="bulkAddSubjectBtn" onclick="openBulkAddSubjectModal('edit');" class="ms-btn-action" style="display: none; background: #0284c7; color: #ffffff; border-color: #0284c7; font-size: 0.76rem; gap: 6px; font-weight: 700; padding: 6px 14px; border-radius: 8px; cursor: pointer; box-shadow: 0 2px 8px rgba(2, 132, 199, 0.25);">
            <i class="fa-solid fa-list-check"></i>
            <span>Open Subject Evaluation (<span id="bulkSelectedCount">0</span>)</span>
          </button>
          <button type="button" onclick="openCreateMarksheetModal(<?php echo intval($selected_student_id); ?>);" class="ms-btn-action ms-btn-secondary ms-generate-btn" style="font-size: 0.76rem; gap: 5px;">
            <i class="fa-solid fa-file-circle-plus" style="color: #059669;"></i>
            <span>New Evaluation</span>
          </button>
        <?php endif; ?>
      </div>
    </div>

  <div class="table-responsive">
    <table class="hrms-table marksheet-table">
      <thead>
        <tr>
          <?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
            <th style="width: 44px; text-align: center; vertical-align: middle; padding: 12px 6px;">
              <input type="checkbox" id="selectAllStudentsCb" onchange="toggleSelectAllMarksheetStudents(this);" title="Select All Scholars on Page" style="width: 17px; height: 17px; cursor: pointer; accent-color: #0284c7;">
            </th>
          <?php endif; ?>
          <th style="min-width: 165px;">Student Profile</th>
          <th style="min-width: 105px;">Roll &amp; Admission</th>
          <th style="min-width: 115px;">Standard &amp; Section</th>
          <th style="min-width: 115px;">Guardian Info</th>
          <th style="min-width: 120px;">Evaluations / Exam</th>
          <th style="min-width: 120px;">Latest Performance</th>
          <th style="min-width: 85px;">Status</th>
          <th style="min-width: 130px; text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($table_students)): ?>
          <tr>
            <td colspan="<?php echo ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff') ? 9 : 8; ?>" style="text-align: center; padding: 50px 20px; color: #64748b;">
              <div style="width: 52px; height: 52px; border-radius: 50%; background: #f1f5f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; font-size: 1.4rem; color: #94a3b8;">
                <i class="fa-solid fa-user-slash"></i>
              </div>
              <h4 style="font-size: 1rem; font-weight: 800; color: #0f172a; margin-bottom: 4px; font-family: 'Outfit', sans-serif;">No Scholars Matching Filters</h4>
              <p style="font-size: 0.82rem; color: #64748b; margin: 0 0 14px;">
                No student records matched your query in Session <strong><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong>.
              </p>
              <?php
                $reset_table_params = [];
                if ($selected_student_id > 0) $reset_table_params['student_id'] = intval($selected_student_id);
                $reset_table_url = ADMIN_URL . '/marksheet' . (!empty($reset_table_params) ? '?' . http_build_query($reset_table_params) : '');
              ?>
              <a href="<?php echo htmlspecialchars($reset_table_url, ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn secondary" style="display: inline-flex; text-decoration: none;">
                <i class="fa-solid fa-rotate-left"></i> Reset All Filters
              </a>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($table_students as $stu): ?>
            <?php 
              $is_cur_viewing = (intval($stu['id']) === intval($selected_student_id));
              $stu_photo_path = !empty($stu['photo']) ? (string)$stu['photo'] : '';
              $has_photo = false;
              if (!empty($stu_photo_path) && $stu_photo_path !== '/assets/imgs/ksv-logo.jpg' && !str_contains($stu_photo_path, '..')) {
                  $full_stu_photo = realpath(__DIR__ . '/../..' . $stu_photo_path);
                  $allowed_base_dir = ($p = realpath(__DIR__ . '/../..')) ? rtrim($p, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : false;
                  if ($full_stu_photo && $allowed_base_dir && strpos($full_stu_photo, $allowed_base_dir) === 0 && file_exists($full_stu_photo)) {
                      $has_photo = true;
                  }
              }
              $first_letter = strtoupper(substr($stu['student_name'] ?? 'S', 0, 1));

              // Marksheet statistics for this student
              $ms_info = $stu_ms_summary[$stu['id']] ?? null;
              $has_ms = !empty($ms_info) && intval($ms_info['total_marksheets'] ?? 0) > 0;
              $is_pass = $has_ms && (($ms_info['latest_status'] ?? '') === 'PASS');

              $switch_params = ['student_id' => intval($stu['id'])];
              if (!empty($search)) $switch_params['search'] = $search;
              if (!empty($filter_standard)) $switch_params['standard'] = $filter_standard;
              if ($limit !== 10) $switch_params['limit'] = intval($limit);
              if ($page > 1) $switch_params['page'] = intval($page);
              $switch_url = ADMIN_URL . '/marksheet?' . http_build_query($switch_params) . '#report-card-view';
            ?>
            <tr class="<?php echo $is_cur_viewing ? 'active-student-row' : ''; ?>">
              
              <?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
                <td style="width: 44px; text-align: center; vertical-align: middle; padding: 12px 6px;">
                  <input type="checkbox" class="ms-student-cb"
                         value="<?php echo intval($stu['id']); ?>"
                         data-id="<?php echo intval($stu['id']); ?>"
                         data-name="<?php echo htmlspecialchars($stu['student_name'], ENT_QUOTES, 'UTF-8'); ?>"
                         data-roll="<?php echo htmlspecialchars($stu['roll_no'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         data-standard="<?php echo htmlspecialchars($stu['standard'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         data-section="<?php echo htmlspecialchars($stu['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?>"
                         data-admission="<?php echo htmlspecialchars($stu['admission_no'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         data-initial="<?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>"
                         data-has-photo="<?php echo $has_photo ? '1' : '0'; ?>"
                         data-photo="<?php echo htmlspecialchars($stu['photo'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         onchange="onMarksheetStudentSelectChange();"
                         style="width: 17px; height: 17px; cursor: pointer; accent-color: #0284c7;">
                </td>
              <?php endif; ?>

              <!-- 1. Student Profile -->
              <td>
                <div class="user-cell" style="display: flex; align-items: center; gap: 12px;">
                  <?php if ($has_photo): ?>
                    <img src="<?php echo htmlspecialchars($stu['photo'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($stu['student_name'], ENT_QUOTES, 'UTF-8'); ?>" class="staff-avatar-img" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1.5px solid #e2e8f0; flex-shrink: 0;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="staff-avatar-init" style="width: 40px; height: 40px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 15px; border: 1px solid #e2e8f0; display: none; align-items: center; justify-content: center; flex-shrink: 0;">
                      <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                  <?php else: ?>
                    <div class="staff-avatar-init" style="width: 40px; height: 40px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 15px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                      <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                  <?php endif; ?>
                  
                  <div>
                    <div style="font-weight: 700; color: #0f172a; font-size: 0.90rem; font-family: 'Outfit', sans-serif; line-height: 1.25;">
                      <?php echo htmlspecialchars($stu['student_name'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                    <div style="font-size: 0.74rem; color: #64748b; margin-top: 2px; display: flex; align-items: center; gap: 6px;">
                      <span><?php echo htmlspecialchars($stu['gender'] ?? 'Scholar', ENT_QUOTES, 'UTF-8'); ?></span>
                      <span>&bull;</span>
                      <span class="ms-blood-badge">Blood: <?php echo htmlspecialchars($stu['blood_group'] ?? 'O+', ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                  </div>
                </div>
              </td>

              <!-- 2. Roll & Admission -->
              <td>
                <span class="ms-roll-pill">
                  <i class="fa-solid fa-hashtag" style="font-size: 0.62rem;"></i>
                  <span><?php echo htmlspecialchars($stu['roll_no'], ENT_QUOTES, 'UTF-8'); ?></span>
                </span>
                <div style="font-size: 0.74rem; color: #64748b; margin-top: 4px;">
                  Adm: <?php echo htmlspecialchars($stu['admission_no'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
                </div>
              </td>

              <!-- 3. Standard & Section -->
              <td>
                <span class="ms-std-pill">
                  <i class="fa-solid fa-graduation-cap" style="font-size: 0.65rem; color: #64748b;"></i>
                  <span><?php echo htmlspecialchars($stu['standard'], ENT_QUOTES, 'UTF-8'); ?></span>
                </span>
                <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 4px;">
                  Section <?php echo htmlspecialchars($stu['section'] ?? 'A', ENT_QUOTES, 'UTF-8'); ?>
                </div>
              </td>

              <!-- 4. Guardian Info -->
              <td>
                <div style="font-size: 0.78rem; font-weight: 600; color: #334155;">
                  <?php echo htmlspecialchars($stu['parent_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
                </div>
                <div style="font-size: 0.74rem; color: #64748b; margin-top: 3px; display: inline-flex; align-items: center; gap: 5px;">
                  <i class="fa-solid fa-phone" style="font-size: 0.65rem; color: #64748b;"></i>
                  <span><?php echo htmlspecialchars($stu['parent_phone'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
              </td>

              <!-- 5. Evaluations / Exam Info -->
              <td>
                <?php if ($has_ms): ?>
                  <span class="ms-exam-chip" title="Evaluations Generated">
                    <i class="fa-solid fa-file-lines" style="color: #0284c7; font-size: 0.72rem;"></i>
                    <span><?php echo intval($ms_info['total_marksheets']); ?> <?php echo intval($ms_info['total_marksheets']) == 1 ? 'Evaluation' : 'Evaluations'; ?></span>
                  </span>
                  <div style="font-size: 0.72rem; color: #64748b; margin-top: 3px; max-width: 140px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?php echo htmlspecialchars($ms_info['latest_exam_name'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars($ms_info['latest_exam_name'], ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                <?php else: ?>
                  <span style="font-size: 0.74rem; color: #94a3b8; font-style: italic; display: inline-flex; align-items: center; gap: 4px;">
                    <i class="fa-regular fa-folder-open"></i> No Marksheet
                  </span>
                <?php endif; ?>
              </td>

              <!-- 6. Latest Performance -->
              <td>
                <?php if ($has_ms): ?>
                  <div>
                    <span class="ms-perf-badge <?php echo $is_pass ? 'pass' : 'fail'; ?>">
                      <i class="fa-solid <?php echo $is_pass ? 'fa-check' : 'fa-xmark'; ?>" style="font-size: 0.65rem;"></i>
                      <span><?php echo htmlspecialchars(strval($ms_info['latest_percentage']), ENT_QUOTES, 'UTF-8'); ?>% &bull; <?php echo htmlspecialchars(strval($ms_info['latest_grade']), ENT_QUOTES, 'UTF-8'); ?></span>
                    </span>
                  </div>
                  <div style="font-size: 0.70rem; font-weight: 700; color: <?php echo $is_pass ? '#166534' : '#991b1b'; ?>; margin-top: 3px;">
                    <?php echo htmlspecialchars(strval($ms_info['latest_status']), ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                <?php else: ?>
                  <span class="ms-perf-badge none">
                    <i class="fa-solid fa-minus" style="font-size: 0.65rem;"></i>
                    <span>Pending</span>
                  </span>
                <?php endif; ?>
              </td>

              <!-- 7. Status -->
              <td>
                <?php if ($is_cur_viewing): ?>
                  <span class="ms-status-active">
                    <span class="pulse-dot"></span> In Preview
                  </span>
                <?php elseif ($has_ms): ?>
                  <span class="ms-status-verified">
                    <i class="fa-solid fa-check" style="font-size: 0.65rem;"></i> Generated
                  </span>
                <?php else: ?>
                  <span class="ms-status-pending">
                    <i class="fa-solid fa-clock" style="font-size: 0.65rem;"></i> Not Created
                  </span>
                <?php endif; ?>
              </td>

              <!-- 8. Actions -->
              <td style="text-align: right;">
                <div style="display: inline-flex; gap: 5px; justify-content: flex-end; align-items: center;">
                  <?php if ($is_cur_viewing): ?>
                    <button type="button" onclick="document.getElementById('report-card-view').scrollIntoView({behavior: 'smooth'});" class="ms-btn-action ms-btn-secondary" style="background: #f0f9ff; border-color: #bae6fd; color: #0284c7;" title="Scroll up to current report card">
                      <i class="fa-solid fa-eye" style="font-size: 0.72rem;"></i>
                      <span>Viewing</span>
                    </button>
                    <?php if ($active_marksheet): ?>
                      <button type="button" onclick="window.print();" class="ms-btn-action ms-btn-secondary" title="Print this Report Card">
                        <i class="fa-solid fa-print" style="color: #0284c7; font-size: 0.72rem;"></i>
                        <span>Print</span>
                      </button>
                    <?php endif; ?>
                  <?php else: ?>
                    <a href="<?php echo htmlspecialchars($switch_url, ENT_QUOTES, 'UTF-8'); ?>" class="ms-btn-action ms-btn-secondary" title="Load student report card into preview">
                      <i class="fa-solid fa-file-lines" style="color: #0284c7; font-size: 0.72rem;"></i>
                      <span>View Report Card</span>
                    </a>
                  <?php endif; ?>

                  <?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
                    <button type="button" onclick="openCreateMarksheetModal(<?php echo intval($stu['id']); ?>);" class="ms-btn-action ms-btn-secondary" style="padding: 5px 8px;" title="Create New Marksheet for this scholar">
                      <i class="fa-solid fa-plus" style="color: #059669; font-size: 0.72rem;"></i>
                    </button>
                  <?php endif; ?>
                </div>
              </td>

            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Table Pagination & Per-Page Controls -->
  <div class="pagination-controls-wrap">
    
    <!-- Left: Showing summary & Limit Selector -->
    <div class="pagination-meta-group">
      <span style="font-size: 0.82rem; color: #475569;">
        <?php if ($total_records > 0): ?>
          Showing <strong><?php echo $start_record; ?></strong>–<strong><?php echo $end_record; ?></strong> of <strong><?php echo $total_records; ?></strong> scholars
        <?php else: ?>
          Showing <strong>0</strong> scholars
        <?php endif; ?>
      </span>

      <div class="pagination-limit-box">
        <label for="perPageLimitSelect" style="color: #64748b; font-size: 0.8rem; margin: 0; font-weight: 500;">Show Per Page</label>
        <select id="perPageLimitSelect" class="pagination-limit-select" onchange="window.location.href = this.value;">
          <?php foreach ($allowed_limits as $l): ?>
            <option value="<?php echo htmlspecialchars(get_marksheet_pagination_url(1, $search, $filter_standard, $selected_student_id, $selected_marksheet_id, $l)); ?>" <?php echo $limit === $l ? 'selected' : ''; ?>>
              <?php echo $l; ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <!-- Center/Right: Navigation page buttons -->
    <?php if ($total_pages > 1): ?>
      <nav class="pagination-nav" aria-label="Scholar Academic Directory Pagination">
        <!-- Prev Page -->
        <a href="<?php echo $page > 1 ? htmlspecialchars(get_marksheet_pagination_url($page - 1, $search, $filter_standard, $selected_student_id, $selected_marksheet_id, $limit)) : '#'; ?>" 
           class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" 
           aria-label="Previous Page"
           title="Previous Page">
          <i class="fa-solid fa-chevron-left" style="font-size: 0.72rem;"></i>
        </a>

        <!-- Page Numbers -->
        <?php
          $range = 2;
          for ($p = 1; $p <= $total_pages; $p++):
            if ($p == 1 || $p == $total_pages || ($p >= $page - $range && $p <= $page + $range)):
        ?>
          <a href="<?php echo htmlspecialchars(get_marksheet_pagination_url($p, $search, $filter_standard, $selected_student_id, $selected_marksheet_id, $limit)); ?>" 
             class="pagination-btn <?php echo $p === $page ? 'active' : ''; ?>">
            <?php echo $p; ?>
          </a>
        <?php 
            elseif (($p == 2 && $page - $range > 2) || ($p == $total_pages - 1 && $page + $range < $total_pages - 1)):
        ?>
          <span class="pagination-ellipsis">&hellip;</span>
        <?php 
            endif;
          endfor;
        ?>

        <!-- Next Page -->
        <a href="<?php echo $page < $total_pages ? htmlspecialchars(get_marksheet_pagination_url($page + 1, $search, $filter_standard, $selected_student_id, $selected_marksheet_id, $limit)) : '#'; ?>" 
           class="pagination-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>" 
           aria-label="Next Page"
           title="Next Page">
          <i class="fa-solid fa-chevron-right" style="font-size: 0.72rem;"></i>
        </a>
      </nav>
    <?php endif; ?>

    <!-- Session info & evaluation summary -->
    <div class="pagination-summary-group" style="font-size: 0.78rem; color: #64748b; display: flex; align-items: center; gap: 12px; margin-left: auto;">
      <span>Total Evaluations: <strong style="color: #0284c7;"><?php echo $total_marksheets_count; ?></strong></span>
      <span style="color: #cbd5e1;">|</span>
      <span>Session: <strong style="color: #334155;"><?php echo htmlspecialchars($current_session_name, ENT_QUOTES, 'UTF-8'); ?></strong></span>
    </div>

  </div>
</div>

<?php if ($current_user['role'] === 'super_admin' || $current_user['role'] === 'staff'): ?>
<!-- ══════════════════════════════════════════════════════
     MODAL: Create New Marksheet Form (With Dynamic Calculation)
     ══════════════════════════════════════════════════════ -->
<div id="createMarksheetModal" class="hrms-modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 1000; align-items: center; justify-content: center; backdrop-filter: blur(5px); overflow-y: auto; padding: 20px;">
  <div class="hrms-modal-content" style="background: #ffffff; border-radius: 16px; width: 100%; max-width: 720px; padding: 28px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); max-height: 92vh; overflow-y: auto; border: 1px solid #e2e8f0;">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1.5px solid #f1f5f9; padding-bottom: 14px;">
      <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 10px;">
        <i class="fa-solid fa-file-circle-plus" style="color: #0092df;"></i>
        <span>Generate Academic Statement of Marks</span>
      </h3>
      <button type="button" onclick="closeCreateMarksheetModal();" style="background: #f1f5f9; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 18px; cursor: pointer; color: #64748b; display: flex; align-items: center; justify-content: center;">&times;</button>
    </div>

    <form method="POST" action="<?php echo htmlspecialchars(ADMIN_URL . '/marksheet', ENT_QUOTES, 'UTF-8'); ?>" id="marksheetGenForm">
      <input type="hidden" name="action" value="create_marksheet">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
      <div style="display:none;" aria-hidden="true"><input type="text" name="marksheet_hp" tabindex="-1" autocomplete="off"></div>

      <div class="modal-form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
        <div class="form-group">
          <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 6px; color: #334155;">Enrolled Scholar *</label>
          <select name="student_id" id="modalStudentSelect" class="hrms-input" required style="width: 100%; padding: 9px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-weight: 600;">
            <?php foreach ($all_students_list as $s): ?>
              <option value="<?php echo intval($s['id']); ?>" <?php echo intval($s['id']) === intval($selected_student_id) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($s['student_name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo htmlspecialchars($s['roll_no'], ENT_QUOTES, 'UTF-8'); ?> &bull; <?php echo htmlspecialchars($s['standard'], ENT_QUOTES, 'UTF-8'); ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="form-group">
          <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 6px; color: #334155;">Examination Title *</label>
          <select name="exam_name" id="createExamSelect" onchange="toggleCustomExamInput(this);" class="hrms-input" style="width: 100%; padding: 9px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-weight: 600;">
            <option value="Unit Test 1">Unit Test 1</option>
            <option value="First Term Mid-Term Examination">First Term Mid-Term Examination</option>
            <option value="Unit Test 2">Unit Test 2</option>
            <option value="Annual Board Examination">Annual Board Examination</option>
            <option value="Pre-Board Mock Evaluation">Pre-Board Mock Evaluation</option>
            <option value="Other">Other</option>
          </select>
          <div id="customExamFieldWrap" style="display: none; margin-top: 8px;">
            <label style="display: block; font-size: 11px; font-weight: 700; margin-bottom: 4px; color: #0284c7;">Custom Examination Title *</label>
            <input type="text" name="custom_exam_name" id="customExamInput" placeholder="Enter custom examination title..." class="hrms-input" style="width: 100%; padding: 8px 12px; border: 1.5px solid #0284c7; border-radius: 8px; font-weight: 600;">
          </div>
        </div>
      </div>

      <div class="form-group" style="margin-bottom: 20px;">
        <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 6px; color: #334155;">Evaluation &amp; Issue Date</label>
        <input type="date" name="exam_date" value="<?php echo date('Y-m-d'); ?>" class="hrms-input" style="width: 100%; padding: 9px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px;">
      </div>

      <!-- Subject Wise Statement Inputs -->
      <div style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
          <label style="font-size: 13px; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-book-open" style="color: #0092df;"></i> Subject Wise Statement of Marks:
          </label>
          <button type="button" onclick="addSubjectRow();" style="background: #f0fdf4; border: 1px solid #86efac; color: #166534; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
            <i class="fa-solid fa-plus"></i> Add Subject
          </button>
        </div>
        
        <table style="width: 100%; border-collapse: collapse; font-size: 13px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;" id="modalSubjectsTable">
          <thead>
            <tr style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
              <th style="padding: 10px 12px; text-align: left; font-weight: 800; color: #475569;">Subject Name</th>
              <th style="padding: 10px 12px; text-align: center; width: 22%; font-weight: 800; color: #475569;">Max Marks</th>
              <th style="padding: 10px 12px; text-align: center; width: 24%; font-weight: 800; color: #475569;">Marks Obtained</th>
              <th style="padding: 10px 6px; width: 8%; text-align: center;"></th>
            </tr>
          </thead>
          <tbody id="modalSubjectsBody">
            <?php 
              $default_subjects = ['Mathematics', 'Physics / Science', 'Chemistry / Social Studies', 'English Core', 'Computer Science / IT', 'Hindi / Language'];
              foreach ($default_subjects as $idx => $subj):
            ?>
              <tr style="border-bottom: 1px solid #f1f5f9;">
                <td style="padding: 6px 10px;">
                  <input type="text" name="subjects[]" value="<?php echo htmlspecialchars($subj, ENT_QUOTES, 'UTF-8'); ?>" class="hrms-input sub-name-input" required style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px;">
                </td>
                <td style="padding: 6px 10px;">
                  <input type="number" name="max_marks[]" value="100" min="1" class="hrms-input sub-max-input" oninput="recalcModalTotals();" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-size: 13px; font-weight: 600;">
                </td>
                <td style="padding: 6px 10px;">
                  <input type="number" step="0.5" name="obtained[]" value="<?php echo rand(75, 96); ?>" min="0" class="hrms-input sub-obt-input" oninput="recalcModalTotals();" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-weight: 800; font-size: 13px; color: #0284c7;">
                </td>
                <td style="padding: 6px 6px; text-align: center;">
                  <button type="button" onclick="removeSubjectRow(this);" style="background: none; border: none; color: #ef4444; font-size: 14px; cursor: pointer;" title="Remove row">&times;</button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <!-- Dynamic Calculation Preview Ribbon -->
        <div class="modal-calc-ribbon" style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; padding: 10px 16px; margin-top: 10px; display: flex; justify-content: space-between; align-items: center; font-size: 13px;">
          <div>
            <span style="color: #0369a1; font-weight: 700;">Total Score: </span>
            <strong id="calcTotalObtained" style="color: #0f172a; font-size: 15px;">0</strong> / <span id="calcTotalMax" style="color: #64748b;">0</span>
          </div>
          <div>
            <span style="color: #0369a1; font-weight: 700;">Percentage: </span>
            <strong id="calcPercentage" style="color: #0284c7; font-size: 16px;">0%</strong>
          </div>
          <div>
            <span style="color: #0369a1; font-weight: 700;">Predicted Grade: </span>
            <span id="calcGradeBadge" class="grade-pill-badge pass" style="font-size: 12px;">A</span>
          </div>
        </div>
      </div>

      <div class="form-group" style="margin-bottom: 22px;">
        <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 6px; color: #334155;">Faculty Remarks &amp; Feedback</label>
        <textarea name="remarks" rows="2" class="hrms-input" placeholder="e.g. Excellent conceptual understanding and disciplined work ethic." style="width: 100%; padding: 9px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-size: 13px;"></textarea>
      </div>

      <div class="modal-action-footer" style="display: flex; justify-content: flex-end; gap: 10px;">
        <button type="button" onclick="closeCreateMarksheetModal();" class="action-btn" style="background: #f1f5f9; border: 1px solid #cbd5e1; padding: 9px 18px; border-radius: 8px; font-weight: 700; cursor: pointer; color: #475569;">Cancel</button>
        <button type="submit" class="action-primary-btn" style="background: #0092df; color: #ffffff; border: none; padding: 9px 24px; border-radius: 8px; font-weight: 800; cursor: pointer; box-shadow: 0 4px 12px rgba(0, 146, 223, 0.25);">Save &amp; Generate Report Card</button>
      </div>
    </form>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════
     MODAL: Bulk Add / View Single Subject to Selected Scholars & PDF Export
     ══════════════════════════════════════════════════════ -->
<div id="bulkAddSubjectModal" class="hrms-modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.65); z-index: 1050; align-items: center; justify-content: center; backdrop-filter: blur(5px); overflow-y: auto; padding: 20px;">
  <div class="hrms-modal-content" style="background: #ffffff; border-radius: 16px; width: 100%; max-width: 980px; padding: 28px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); max-height: 92vh; overflow-y: auto; border: 1px solid #e2e8f0;">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; border-bottom: 1.5px solid #f1f5f9; padding-bottom: 14px; flex-wrap: wrap; gap: 12px;">
      <div>
        <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif; display: flex; align-items: center; gap: 10px;">
          <i class="fa-solid fa-list-check" style="color: #0284c7;"></i>
          <span>Single Subject Evaluation &amp; PDF Export</span>
          <span id="bulkModalCountBadge" style="font-size: 0.75rem; background: #e0f2fe; color: #0369a1; padding: 3px 10px; border-radius: 20px; font-weight: 700; border: 1px solid #bae6fd;">
            0 Scholars Selected
          </span>
        </h3>
        <p style="margin: 4px 0 0; font-size: 0.80rem; color: #64748b;">
          Enter marks for a single subject or review already created scores across checked scholars, and export directly in official A4 PDF register.
        </p>
      </div>
      <div>
        <button type="button" onclick="closeBulkAddSubjectModal();" style="background: #f1f5f9; border: none; width: 34px; height: 34px; border-radius: 50%; font-size: 20px; cursor: pointer; color: #64748b; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;">&times;</button>
      </div>
    </div>

    <form method="POST" action="<?php echo htmlspecialchars(ADMIN_URL . '/marksheet', ENT_QUOTES, 'UTF-8'); ?>" id="bulkAddSubjectForm">
      <input type="hidden" name="action" value="bulk_add_subject">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
      <div style="display:none;" aria-hidden="true"><input type="text" name="marksheet_hp" tabindex="-1" autocomplete="off"></div>

      <!-- Global Examination & Default Subject Config Box -->
      <div style="background: #f8fafc; border: 1.5px solid #e2e8f0; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
        <div style="font-size: 0.78rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #0284c7; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
          <i class="fa-solid fa-sliders"></i> Examination &amp; Default Subject Settings
        </div>

        <div style="display: grid; grid-template-columns: 1.4fr 1fr; gap: 14px; margin-bottom: 12px;">
          <div>
            <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #334155;">Examination Title *</label>
            <select name="bulk_exam_name" id="bulkExamSelect" onchange="onBulkExamChange(this)" class="hrms-input" style="width: 100%; padding: 8px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-weight: 600;">
              <option value="Unit Test 1">Unit Test 1</option>
              <option value="First Term Mid-Term Examination">First Term Mid-Term Examination</option>
              <option value="Unit Test 2">Unit Test 2</option>
              <option value="Annual Board Examination">Annual Board Examination</option>
              <option value="Pre-Board Mock Evaluation">Pre-Board Mock Evaluation</option>
              <option value="custom">+ Other / Custom Examination</option>
            </select>
            <input type="text" name="bulk_custom_exam_name" id="bulkCustomExamInput" placeholder="Enter custom examination title..." class="hrms-input" style="display: none; width: 100%; margin-top: 6px; padding: 8px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px;">
          </div>

          <div>
            <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #334155;">Evaluation &amp; Issue Date</label>
            <input type="date" name="bulk_exam_date" value="<?php echo date('Y-m-d'); ?>" class="hrms-input" style="width: 100%; padding: 8px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px;">
          </div>
        </div>

        <!-- Global Subject, Max, Pass Bar -->
        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 10px; align-items: flex-end;">
          <div>
            <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #334155;">Subject Title *</label>
            <input type="text" id="bulkGlobalSubject" list="bulkSubjectSuggestions" value="Mathematics" placeholder="e.g. Mathematics" oninput="onBulkSubjectInputChange(this.value);" class="hrms-input" style="width: 100%; padding: 8px 12px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-weight: 600;">
            <datalist id="bulkSubjectSuggestions">
              <option value="Mathematics"></option>
              <option value="Physics"></option>
              <option value="Chemistry"></option>
              <option value="Biology"></option>
              <option value="Science"></option>
              <option value="Social Studies"></option>
              <option value="English Core"></option>
              <option value="Computer Science"></option>
              <option value="Hindi"></option>
              <option value="Accountancy"></option>
              <option value="Business Studies"></option>
              <option value="Economics"></option>
            </datalist>
          </div>

          <div>
            <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #334155;">Max Marks *</label>
            <input type="number" id="bulkGlobalMax" value="100" min="1" class="hrms-input" style="width: 100%; padding: 8px 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; text-align: center; font-weight: 600;">
          </div>

          <div>
            <label style="display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #334155;">Pass Marks *</label>
            <input type="number" id="bulkGlobalPass" value="35" min="0" class="hrms-input" style="width: 100%; padding: 8px 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; text-align: center; font-weight: 600;">
          </div>

          <div>
            <button type="button" onclick="applyBulkGlobalValues();" class="roaster-btn secondary" style="padding: 9px 14px; font-size: 0.78rem; font-weight: 700; border-radius: 8px; white-space: nowrap; height: 38px;" title="Apply this subject, max, and pass marks to all student rows below">
              <i class="fa-solid fa-arrows-rotate"></i> Apply to All
            </button>
          </div>
        </div>

        <!-- Evaluated subjects quick-switch ribbon -->
        <div id="bulkEvaluatedSubjectsBar" style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed #cbd5e1; display: none; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 0.76rem;">
          <span style="font-weight: 700; color: #475569; display: flex; align-items: center; gap: 5px;">
            <i class="fa-solid fa-layer-group" style="color: #0284c7;"></i> Evaluated in this Exam:
          </span>
          <div id="bulkEvaluatedSubjectsList" style="display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap;">
            <!-- Populated dynamically via JS -->
          </div>
        </div>
      </div>

      <!-- Table of Checked Students -->
      <div style="border: 1.5px solid #e2e8f0; border-radius: 12px; overflow: hidden; margin-bottom: 18px;">
        <div style="max-height: 380px; overflow-y: auto;">
          <table style="width: 100%; border-collapse: collapse; font-size: 13px;" id="bulkStudentTable">
            <thead style="position: sticky; top: 0; background: #f8fafc; z-index: 2; border-bottom: 1.5px solid #e2e8f0;">
              <tr>
                <th style="padding: 10px 14px; text-align: left; font-weight: 800; color: #475569; width: 30%;">Student Name</th>
                <th style="padding: 10px 10px; text-align: left; font-weight: 800; color: #475569; width: 22%;">Subjects</th>
                <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #475569; width: 12%;">MAX MARKS</th>
                <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #475569; width: 12%;">PASS MARKS</th>
                <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #475569; width: 13%;">OBTAINED</th>
                <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #475569; width: 8%;">GRADE</th>
                <th style="padding: 10px 8px; text-align: center; width: 3%;"></th>
              </tr>
            </thead>
            <tbody id="bulkTableBody">
              <!-- Dynamically populated from checked checkboxes -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- Footer & Actions -->
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.80rem; color: #64748b;">
          <span>Quick Fill:</span>
          <button type="button" onclick="bulkQuickFillObtained(75);" style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 11px; font-weight: 700; cursor: pointer; color: #334155;">75 (A+)</button>
          <button type="button" onclick="bulkQuickFillObtained(85);" style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 11px; font-weight: 700; cursor: pointer; color: #334155;">85 (A+)</button>
          <button type="button" onclick="bulkQuickFillObtained(35);" style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 11px; font-weight: 700; cursor: pointer; color: #334155;">35 (D)</button>
          <button type="button" onclick="bulkQuickFillObtained('');" style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 11px; font-weight: 700; cursor: pointer; color: #ef4444;">Clear</button>
        </div>

        <div style="display: flex; gap: 10px; align-items: center;">
          <button type="button" onclick="exportSingleSubjectPDF();" class="roaster-btn secondary" style="background: #fef2f2; border: 1.5px solid #fca5a5; color: #dc2626; font-size: 0.80rem; font-weight: 700; gap: 6px; padding: 9px 18px; border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; box-shadow: 0 2px 6px rgba(220, 38, 38, 0.15);" title="Export single subject evaluation in official A4 PDF">
            <i class="fa-solid fa-file-pdf"></i>
            <span>Export in PDF</span>
          </button>
          <button type="button" onclick="closeBulkAddSubjectModal();" class="action-btn" style="background: #f1f5f9; border: 1px solid #cbd5e1; padding: 9px 18px; border-radius: 8px; font-weight: 700; cursor: pointer; color: #475569;">Cancel</button>
          <button type="submit" class="action-primary-btn" style="background: #0284c7; color: #ffffff; border: none; padding: 9px 24px; border-radius: 8px; font-weight: 800; cursor: pointer; box-shadow: 0 4px 12px rgba(2, 132, 199, 0.25); display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-cloud-arrow-up"></i>
            <span>Save Marks</span>
          </button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- html2canvas Library for High-Res Report Card Export -->
<script src="<?php echo htmlspecialchars(HRMS_URL, ENT_QUOTES, 'UTF-8'); ?>/assets/js/html2canvas.min.js"></script>

<script>
window.KSV_PAGE_EVALUATIONS = <?php echo json_encode($stu_evaluations_map ?? [], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?> || {};
window.KSV_SCHOOL_INFO = {
  name: <?php echo json_encode($school_settings['school_name'] ?? 'KSV Academy'); ?>,
  tagline: <?php echo json_encode($school_settings['tagline'] ?? 'WHERE LEARNING MEETS EXCELLENCE'); ?>,
  address: <?php echo json_encode($school_settings['address'] ?? 'Knowledge Valley Road, Sector 12, Academic Hub'); ?>,
  phone: <?php echo json_encode($school_settings['phone'] ?? '+91 98765 43210'); ?>,
  logo: <?php echo json_encode($school_settings['logo_url'] ?? '/assets/imgs/ksv-logo.jpg'); ?>,
  session: <?php echo json_encode($current_session_name ?? '2025-2026'); ?>
};

function getSavedEvaluation(sid, examName, subName) {
  if (!window.KSV_PAGE_EVALUATIONS || !window.KSV_PAGE_EVALUATIONS[sid]) return null;
  const exams = window.KSV_PAGE_EVALUATIONS[sid];
  if (!exams[examName]) return null;
  const subs = exams[examName];
  for (const k in subs) {
    if (k.toLowerCase().trim() === subName.toLowerCase().trim()) {
      return subs[k];
    }
  }
  return null;
}

function onMarksheetStudentSelectChange() {
  const cbs = document.querySelectorAll('.ms-student-cb');
  let checkedCount = 0;
  cbs.forEach(cb => {
    if (cb.checked) checkedCount++;
  });

  const btn = document.getElementById('bulkAddSubjectBtn');
  const countSpan = document.getElementById('bulkSelectedCount');

  if (countSpan) countSpan.innerText = checkedCount;
  if (btn) btn.style.display = checkedCount > 0 ? 'inline-flex' : 'none';

  const masterCb = document.getElementById('selectAllStudentsCb');
  if (masterCb) {
    if (checkedCount === 0) {
      masterCb.checked = false;
      masterCb.indeterminate = false;
    } else if (checkedCount === cbs.length) {
      masterCb.checked = true;
      masterCb.indeterminate = false;
    } else {
      masterCb.checked = false;
      masterCb.indeterminate = true;
    }
  }
}

function toggleSelectAllMarksheetStudents(masterCb) {
  const cbs = document.querySelectorAll('.ms-student-cb');
  cbs.forEach(cb => {
    cb.checked = masterCb.checked;
  });
  onMarksheetStudentSelectChange();
}

function onBulkExamChange(sel) {
  const customInput = document.getElementById('bulkCustomExamInput');
  if (customInput) {
    if (sel.value === 'custom') {
      customInput.style.display = 'block';
      customInput.focus();
    } else {
      customInput.style.display = 'none';
    }
  }
  reloadBulkStudentRows();
}

function updateEvaluatedSubjectsBar() {
  const checkedCbs = Array.from(document.querySelectorAll('.ms-student-cb:checked'));
  const examName = (document.getElementById('bulkExamSelect')?.value === 'custom' 
    ? document.getElementById('bulkCustomExamInput')?.value 
    : document.getElementById('bulkExamSelect')?.value) || '';

  const bar = document.getElementById('bulkEvaluatedSubjectsBar');
  const list = document.getElementById('bulkEvaluatedSubjectsList');
  if (!bar || !list) return;

  const currentSub = (document.getElementById('bulkGlobalSubject')?.value || '').toLowerCase().trim();
  const foundSubs = new Map();

  checkedCbs.forEach(cb => {
    const sid = cb.value;
    if (window.KSV_PAGE_EVALUATIONS && window.KSV_PAGE_EVALUATIONS[sid] && window.KSV_PAGE_EVALUATIONS[sid][examName]) {
      const subs = window.KSV_PAGE_EVALUATIONS[sid][examName];
      for (const sname in subs) {
        foundSubs.set(sname, (foundSubs.get(sname) || 0) + 1);
      }
    }
  });

  if (foundSubs.size === 0) {
    bar.style.display = 'none';
    list.innerHTML = '';
    return;
  }

  bar.style.display = 'flex';
  list.innerHTML = '';

  foundSubs.forEach((cnt, sname) => {
    const isAct = sname.toLowerCase().trim() === currentSub;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'eval-sub-pill';
    btn.style.cssText = `
      background: ${isAct ? '#0284c7' : '#ffffff'};
      color: ${isAct ? '#ffffff' : '#0369a1'};
      border: 1px solid ${isAct ? '#0284c7' : '#bae6fd'};
      padding: 3px 10px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: all 0.15s ease;
    `;
    btn.innerHTML = `<i class="fa-solid fa-book-open" style="font-size: 10px;"></i> ${sname} (${cnt}/${checkedCbs.length})`;
    btn.onclick = () => selectEvaluatedSubject(sname);
    list.appendChild(btn);
  });
}

function selectEvaluatedSubject(sname) {
  const subInp = document.getElementById('bulkGlobalSubject');
  if (subInp) {
    subInp.value = sname;
  }
  reloadBulkStudentRows();
}

function onBulkSubjectInputChange(val) {
  reloadBulkStudentRows();
}

function reloadBulkStudentRows() {
  const checkedCbs = Array.from(document.querySelectorAll('.ms-student-cb:checked'));
  const examName = (document.getElementById('bulkExamSelect')?.value === 'custom' 
    ? document.getElementById('bulkCustomExamInput')?.value 
    : document.getElementById('bulkExamSelect')?.value) || '';
  const currentSub = (document.getElementById('bulkGlobalSubject')?.value || 'Mathematics').trim();
  const globalMax = parseFloat(document.getElementById('bulkGlobalMax')?.value) || 100;
  const globalPass = parseFloat(document.getElementById('bulkGlobalPass')?.value) || 35;

  updateEvaluatedSubjectsBar();

  checkedCbs.forEach(cb => {
    const sid = cb.value;
    const tr = document.getElementById('bulkRow_' + sid);
    if (!tr) return;

    const subInp = tr.querySelector('.bulk-sub-cell');
    const maxInp = tr.querySelector('.bulk-max-cell');
    const passInp = tr.querySelector('.bulk-pass-cell');
    const obtInp = tr.querySelector('.bulk-obt-cell');
    const evalTag = tr.querySelector('.bulk-eval-tag');

    const saved = getSavedEvaluation(sid, examName, currentSub);
    if (subInp) subInp.value = currentSub;

    if (saved) {
      if (maxInp) maxInp.value = saved.max;
      if (passInp) passInp.value = saved.pass;
      if (obtInp) {
        obtInp.value = saved.obtained;
        obtInp.style.borderColor = '#16a34a';
        obtInp.style.background = '#f0fdf4';
      }
      if (evalTag) {
        evalTag.innerHTML = `<i class="fa-solid fa-check-circle" style="color: #16a34a;"></i> <span style="color:#15803d; font-weight:700;">Saved</span>`;
        evalTag.style.background = '#dcfce7';
      }
    } else {
      if (maxInp) maxInp.value = globalMax;
      if (passInp) passInp.value = globalPass;
      if (obtInp) {
        obtInp.value = '';
        obtInp.style.borderColor = '#0284c7';
        obtInp.style.background = '#ffffff';
      }
      if (evalTag) {
        evalTag.innerHTML = `<span style="color:#64748b; font-weight:600;">Pending</span>`;
        evalTag.style.background = '#f1f5f9';
      }
    }

    if (obtInp) calcBulkRow(obtInp);
  });
}

function openBulkAddSubjectModal(initialMode = 'edit') {
  const checkedCbs = Array.from(document.querySelectorAll('.ms-student-cb:checked'));
  if (checkedCbs.length === 0) {
    alert('Please select at least one student using the checkboxes.');
    return;
  }

  const examName = (document.getElementById('bulkExamSelect')?.value === 'custom' 
    ? document.getElementById('bulkCustomExamInput')?.value 
    : document.getElementById('bulkExamSelect')?.value) || 'Unit Test 1';
  const globalSub = (document.getElementById('bulkGlobalSubject')?.value || 'Mathematics').trim();
  const globalMax = parseFloat(document.getElementById('bulkGlobalMax')?.value) || 100;
  const globalPass = parseFloat(document.getElementById('bulkGlobalPass')?.value) || 35;

  const tbody = document.getElementById('bulkTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  checkedCbs.forEach(cb => {
    const sid = cb.value;
    const name = cb.getAttribute('data-name') || 'Student';
    const roll = cb.getAttribute('data-roll') || '';
    const standard = cb.getAttribute('data-standard') || '';
    const initial = cb.getAttribute('data-initial') || name.charAt(0).toUpperCase();
    const photo = cb.getAttribute('data-photo') || '';
    const hasPhoto = cb.getAttribute('data-has-photo') === '1' && photo;

    // Check if scholar already has evaluated score for this exam and subject
    const saved = getSavedEvaluation(sid, examName, globalSub);
    const rowSub = globalSub;
    const rowMax = saved ? saved.max : globalMax;
    const rowPass = saved ? saved.pass : globalPass;
    const rowObt = saved ? saved.obtained : '';
    const isSaved = (saved !== null);

    const tr = document.createElement('tr');
    tr.id = 'bulkRow_' + sid;
    tr.style.borderBottom = '1px solid #f1f5f9';

    const avatarHtml = hasPhoto 
      ? `<img src="${photo}" alt="${name}" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1.5px solid #e2e8f0; flex-shrink: 0;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
         <div style="width: 32px; height: 32px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 13px; border: 1px solid #e2e8f0; display: none; align-items: center; justify-content: center; flex-shrink: 0;">${initial}</div>`
      : `<div style="width: 32px; height: 32px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 13px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">${initial}</div>`;

    tr.innerHTML = `
      <td style="padding: 8px 12px; vertical-align: middle;">
        <input type="hidden" name="bulk_student_ids[]" value="${sid}">
        <div style="display: flex; align-items: center; gap: 10px;">
          ${avatarHtml}
          <div>
            <div style="font-weight: 700; color: #0f172a; font-size: 13px; line-height: 1.2; display: flex; align-items: center; gap: 6px;">
              <span class="bulk-student-name">${name}</span>
              <span class="bulk-eval-tag" style="font-size: 10px; padding: 1px 6px; border-radius: 4px; ${isSaved ? 'background:#dcfce7; color:#15803d; font-weight:700;' : 'background:#f1f5f9; color:#64748b; font-weight:600;'}">
                ${isSaved ? '<i class="fa-solid fa-check-circle" style="color:#16a34a;"></i> Saved' : 'Pending'}
              </span>
            </div>
            <div class="bulk-student-meta" style="font-size: 11px; color: #64748b; margin-top: 1px;">
              ${roll ? '#' + roll : ''} ${standard ? '&bull; ' + standard : ''}
            </div>
          </div>
        </div>
      </td>
      <td style="padding: 8px 10px; vertical-align: middle;">
        <input type="text" name="bulk_subjects[${sid}]" value="${rowSub}" class="hrms-input bulk-sub-cell" required style="width: 100%; padding: 6px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px; font-weight: 600;">
      </td>
      <td style="padding: 8px 8px; text-align: center; vertical-align: middle;">
        <input type="number" name="bulk_max_marks[${sid}]" value="${rowMax}" min="1" class="hrms-input bulk-max-cell" oninput="calcBulkRow(this);" required style="width: 100%; padding: 6px 8px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-size: 13px; font-weight: 600;">
      </td>
      <td style="padding: 8px 8px; text-align: center; vertical-align: middle;">
        <input type="number" name="bulk_pass_marks[${sid}]" value="${rowPass}" min="0" class="hrms-input bulk-pass-cell" required style="width: 100%; padding: 6px 8px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-size: 13px; font-weight: 600;">
      </td>
      <td style="padding: 8px 8px; text-align: center; vertical-align: middle;">
        <input type="number" step="0.5" name="bulk_obtained[${sid}]" value="${rowObt !== '' ? rowObt : ''}" placeholder="e.g. 75" min="0" class="hrms-input bulk-obt-cell" oninput="calcBulkRow(this);" required style="width: 100%; padding: 6px 8px; border: 1.5px solid ${isSaved ? '#16a34a' : '#0284c7'}; ${isSaved ? 'background:#f0fdf4;' : ''} border-radius: 6px; text-align: center; font-weight: 800; font-size: 13px; color: #0f172a;">
      </td>
      <td style="padding: 8px 8px; text-align: center; vertical-align: middle;">
        <span class="bulk-grade-badge" style="display: inline-block; min-width: 36px; padding: 4px 6px; border-radius: 6px; font-size: 11px; font-weight: 800; background: #f1f5f9; color: #64748b;">-</span>
        <input type="hidden" name="bulk_grades[${sid}]" class="bulk-grade-val" value="">
      </td>
      <td style="padding: 8px 6px; text-align: center; vertical-align: middle;">
        <button type="button" onclick="removeBulkStudentRow(${sid});" style="background: none; border: none; color: #ef4444; font-size: 16px; cursor: pointer; padding: 4px;" title="Remove student from this bulk entry">&times;</button>
      </td>
    `;
    tbody.appendChild(tr);

    const obtInput = tr.querySelector('.bulk-obt-cell');
    if (obtInput) calcBulkRow(obtInput);
  });

  const countBadge = document.getElementById('bulkModalCountBadge');
  if (countBadge) countBadge.innerText = checkedCbs.length + ' Scholar' + (checkedCbs.length === 1 ? '' : 's') + ' Selected';

  updateEvaluatedSubjectsBar();

  const modal = document.getElementById('bulkAddSubjectModal');
  if (modal) modal.style.display = 'flex';

  if (initialMode === 'export') {
    setTimeout(() => {
      exportSingleSubjectPDF();
    }, 200);
  } else {
    const firstObt = tbody.querySelector('.bulk-obt-cell');
    if (firstObt) firstObt.focus();
  }
}

function closeBulkAddSubjectModal() {
  const modal = document.getElementById('bulkAddSubjectModal');
  if (modal) modal.style.display = 'none';
}

function removeBulkStudentRow(sid) {
  const tr = document.getElementById('bulkRow_' + sid);
  if (tr) tr.remove();

  const cb = document.querySelector(`.ms-student-cb[value="${sid}"]`);
  if (cb) cb.checked = false;
  onMarksheetStudentSelectChange();

  const remaining = document.querySelectorAll('#bulkTableBody tr').length;
  const countBadge = document.getElementById('bulkModalCountBadge');
  if (countBadge) countBadge.innerText = remaining + ' Scholar' + (remaining === 1 ? '' : 's') + ' Selected';

  if (remaining === 0) {
    closeBulkAddSubjectModal();
  } else {
    updateEvaluatedSubjectsBar();
  }
}

function calcBulkRow(inputEl) {
  const tr = inputEl.closest('tr');
  if (!tr) return;

  const maxInp = tr.querySelector('.bulk-max-cell');
  const obtInp = tr.querySelector('.bulk-obt-cell');
  const gradeBadge = tr.querySelector('.bulk-grade-badge');
  const gradeVal = tr.querySelector('.bulk-grade-val');

  const maxM = parseFloat(maxInp?.value) || 0;
  const rawObt = obtInp?.value !== '' ? parseFloat(obtInp?.value) : null;

  if (rawObt === null || isNaN(rawObt) || maxM <= 0) {
    if (gradeBadge) {
      gradeBadge.innerText = '-';
      gradeBadge.style.background = '#f1f5f9';
      gradeBadge.style.color = '#64748b';
    }
    if (gradeVal) gradeVal.value = '';
    return;
  }

  const pct = (rawObt / maxM) * 100;
  let grade = 'F';
  let bg = '#fee2e2';
  let color = '#b91c1c';

  if (pct >= 90) {
    grade = 'A+'; bg = '#dcfce7'; color = '#15803d';
  } else if (pct >= 80) {
    grade = 'A'; bg = '#dcfce7'; color = '#15803d';
  } else if (pct >= 70) {
    grade = 'B+'; bg = '#e0f2fe'; color = '#0369a1';
  } else if (pct >= 60) {
    grade = 'B'; bg = '#e0f2fe'; color = '#0369a1';
  } else if (pct >= 50) {
    grade = 'C'; bg = '#fef9c3'; color = '#a16207';
  } else if (pct >= 35) {
    grade = 'D'; bg = '#fef9c3'; color = '#a16207';
  }

  if (gradeBadge) {
    gradeBadge.innerText = grade;
    gradeBadge.style.background = bg;
    gradeBadge.style.color = color;
  }
  if (gradeVal) gradeVal.value = grade;
}

function applyBulkGlobalValues() {
  const globalSub = (document.getElementById('bulkGlobalSubject')?.value || 'Mathematics').trim();
  const globalMax = parseFloat(document.getElementById('bulkGlobalMax')?.value) || 100;
  const globalPass = parseFloat(document.getElementById('bulkGlobalPass')?.value) || 35;

  document.querySelectorAll('#bulkTableBody tr').forEach(tr => {
    const subInp = tr.querySelector('.bulk-sub-cell');
    const maxInp = tr.querySelector('.bulk-max-cell');
    const passInp = tr.querySelector('.bulk-pass-cell');

    if (subInp && globalSub) subInp.value = globalSub;
    if (maxInp) maxInp.value = globalMax;
    if (passInp) passInp.value = globalPass;

    const obtInp = tr.querySelector('.bulk-obt-cell');
    if (obtInp) calcBulkRow(obtInp);
  });
}

function bulkQuickFillObtained(score) {
  document.querySelectorAll('#bulkTableBody tr').forEach(tr => {
    const obtInp = tr.querySelector('.bulk-obt-cell');
    if (obtInp) {
      obtInp.value = score !== '' ? score : '';
      calcBulkRow(obtInp);
    }
  });
}

// ── Export Single Subject Evaluation in Official A4 Landscape PDF ──
function exportSingleSubjectPDF() {
  const rows = Array.from(document.querySelectorAll('#bulkTableBody tr'));
  if (rows.length === 0) {
    alert('Please select at least one student before exporting.');
    return;
  }

  const examName = (document.getElementById('bulkExamSelect')?.value === 'custom' 
    ? document.getElementById('bulkCustomExamInput')?.value 
    : document.getElementById('bulkExamSelect')?.value) || 'Examination Evaluation';
  
  const subjectName = (document.getElementById('bulkGlobalSubject')?.value || 'Mathematics').trim();
  const examDate = document.querySelector('input[name="bulk_exam_date"]')?.value || new Date().toISOString().split('T')[0];

  const studentData = [];
  let totalMaxAll = 0;
  let totalObtAll = 0;
  let passCount = 0;
  let failCount = 0;
  let highestScore = -1;
  let highestScorer = '';

  rows.forEach((tr, idx) => {
    const sid = tr.id.replace('bulkRow_', '');
    const nameEl = tr.querySelector('.bulk-student-name');
    const name = nameEl ? nameEl.innerText.trim() : 'Scholar';
    const metaEl = tr.querySelector('.bulk-student-meta');
    const metaText = metaEl ? metaEl.innerText.trim() : '';
    
    const metaParts = metaText.split('•').map(s => s.trim());
    const roll = metaParts[0] || ('#' + sid);
    const standard = metaParts[1] || 'Standard';

    const maxM = parseFloat(tr.querySelector('.bulk-max-cell')?.value) || 100;
    const passM = parseFloat(tr.querySelector('.bulk-pass-cell')?.value) || 35;
    const obtVal = tr.querySelector('.bulk-obt-cell')?.value;
    const obtM = obtVal !== '' && !isNaN(parseFloat(obtVal)) ? parseFloat(obtVal) : 0;
    const isEvaluated = (obtVal !== '' && !isNaN(parseFloat(obtVal)));
    
    const pct = maxM > 0 ? ((obtM / maxM) * 100).toFixed(1) : '0';
    const isPass = isEvaluated && (obtM >= passM);
    if (isPass) passCount++;
    else if (isEvaluated) failCount++;

    if (isEvaluated && obtM > highestScore) {
      highestScore = obtM;
      highestScorer = name;
    }

    const gradeBadge = tr.querySelector('.bulk-grade-badge');
    const grade = gradeBadge ? gradeBadge.innerText.trim() : (isPass ? 'A' : 'F');

    if (isEvaluated) {
      totalMaxAll += maxM;
      totalObtAll += obtM;
    }

    studentData.push({
      sr: idx + 1,
      sid,
      name,
      roll,
      standard,
      max: maxM,
      pass: passM,
      obtained: isEvaluated ? obtM : '-',
      pct: isEvaluated ? pct + '%' : '-',
      grade: isEvaluated ? grade : '-',
      status: isEvaluated ? (isPass ? 'PASS' : 'FAIL') : 'PENDING'
    });
  });

  const evaluatedCount = passCount + failCount;
  const passRate = evaluatedCount > 0 ? Math.round((passCount / evaluatedCount) * 100) : 0;
  const classAvgPct = (evaluatedCount > 0 && totalMaxAll > 0) ? ((totalObtAll / totalMaxAll) * 100).toFixed(1) : '0';

  const school = window.KSV_SCHOOL_INFO || {
    name: 'KSV Academy',
    tagline: 'WHERE LEARNING MEETS EXCELLENCE',
    address: 'Knowledge Valley Road, Sector 12, Academic Hub',
    phone: '+91 98765 43210',
    logo: '/assets/imgs/ksv-logo.jpg',
    session: '2025-2026'
  };

  let printIframe = document.getElementById('ksvSubjectPdfFrame');
  if (!printIframe) {
    printIframe = document.createElement('iframe');
    printIframe.id = 'ksvSubjectPdfFrame';
    printIframe.style.position = 'fixed';
    printIframe.style.right = '0';
    printIframe.style.bottom = '0';
    printIframe.style.width = '0';
    printIframe.style.height = '0';
    printIframe.style.border = '0';
    document.body.appendChild(printIframe);
  }

  const tableRowsHtml = studentData.map(st => {
    let gradeColor = '#64748b';
    let gradeBg = '#f1f5f9';
    if (st.grade === 'A+' || st.grade === 'A') { gradeColor = '#15803d'; gradeBg = '#dcfce7'; }
    else if (st.grade === 'B+' || st.grade === 'B') { gradeColor = '#0369a1'; gradeBg = '#e0f2fe'; }
    else if (st.grade === 'C' || st.grade === 'D') { gradeColor = '#a16207'; gradeBg = '#fef9c3'; }
    else if (st.grade === 'F') { gradeColor = '#b91c1c'; gradeBg = '#fee2e2'; }

    let statusHtml = '<span style="color:#64748b; font-weight:700;">PENDING</span>';
    if (st.status === 'PASS') {
      statusHtml = '<span style="color:#15803d; font-weight:800; background:#dcfce7; padding:2px 8px; border-radius:4px; font-size:11px;">PASS</span>';
    } else if (st.status === 'FAIL') {
      statusHtml = '<span style="color:#b91c1c; font-weight:800; background:#fee2e2; padding:2px 8px; border-radius:4px; font-size:11px;">FAIL</span>';
    }

    return `
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="padding: 7px 10px; text-align: center; color: #64748b; font-weight: 600;">${st.sr}</td>
        <td style="padding: 7px 10px; font-weight: 700; color: #0284c7; white-space: nowrap;">${st.roll}</td>
        <td style="padding: 7px 12px; font-weight: 700; color: #0f172a;">${st.name}</td>
        <td style="padding: 7px 10px; color: #475569; font-size: 11.5px;">${st.standard}</td>
        <td style="padding: 7px 10px; text-align: center; font-weight: 600; color: #475569;">${st.max}</td>
        <td style="padding: 7px 10px; text-align: center; color: #64748b;">${st.pass}</td>
        <td style="padding: 7px 10px; text-align: center; font-weight: 800; color: #0f172a; font-size: 13px;">${st.obtained}</td>
        <td style="padding: 7px 10px; text-align: center; font-weight: 700; color: #0284c7;">${st.pct}</td>
        <td style="padding: 7px 10px; text-align: center;">
          <span style="display:inline-block; min-width:32px; padding:2px 6px; border-radius:4px; font-weight:800; font-size:11px; background:${gradeBg}; color:${gradeColor};">
            ${st.grade}
          </span>
        </td>
        <td style="padding: 7px 10px; text-align: center;">${statusHtml}</td>
      </tr>
    `;
  }).join('');

  const printHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Single Subject Academic Evaluation - ${subjectName} (${examName})</title>
      <style>
        @page {
          size: A4 landscape;
          margin: 8mm 10mm;
        }
        * {
          box-sizing: border-box;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        body {
          margin: 0;
          padding: 0;
          background: #ffffff;
          color: #0f172a;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          font-size: 12px;
          line-height: 1.4;
        }
        .cert-container {
          width: 100%;
          border: 2px solid #0284c7;
          border-radius: 8px;
          padding: 14px 18px;
          position: relative;
        }
        .header-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 2px solid #0f172a;
          padding-bottom: 10px;
          margin-bottom: 12px;
        }
        .header-logo {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          object-fit: cover;
          border: 1.5px solid #0284c7;
          padding: 2px;
        }
        .header-title-wrap {
          text-align: center;
          flex: 1;
          padding: 0 14px;
        }
        .school-name {
          font-size: 20px;
          font-weight: 800;
          color: #0f172a;
          letter-spacing: -0.02em;
          margin: 0;
          text-transform: uppercase;
        }
        .school-tagline {
          font-size: 10.5px;
          font-weight: 700;
          color: #0284c7;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          margin-top: 2px;
        }
        .school-sub {
          font-size: 10px;
          color: #64748b;
          margin-top: 2px;
        }
        .meta-strip {
          background: #f8fafc;
          border: 1px solid #cbd5e1;
          border-radius: 6px;
          padding: 8px 14px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }
        .meta-item strong {
          color: #475569;
          font-size: 11px;
          text-transform: uppercase;
        }
        .meta-item span {
          color: #0f172a;
          font-weight: 800;
          font-size: 12px;
          margin-left: 4px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 14px;
        }
        thead th {
          background: #0f172a !important;
          color: #ffffff !important;
          font-weight: 800;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 8px 10px;
        }
        tbody tr:nth-child(even) {
          background: #f8fafc;
        }
        .stats-ribbon {
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          gap: 10px;
          margin-bottom: 14px;
        }
        .stat-card {
          border: 1px solid #e2e8f0;
          border-radius: 6px;
          padding: 6px 10px;
          background: #f8fafc;
          text-align: center;
        }
        .stat-card .label {
          font-size: 9.5px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
        }
        .stat-card .val {
          font-size: 14px;
          font-weight: 800;
          color: #0f172a;
          margin-top: 2px;
        }
        .signatures-row {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          padding-top: 18px;
          border-top: 1px dashed #cbd5e1;
          margin-top: 10px;
        }
        .sig-block {
          text-align: center;
          width: 28%;
        }
        .sig-line {
          border-top: 1px solid #94a3b8;
          margin-bottom: 4px;
        }
        .sig-title {
          font-size: 10.5px;
          font-weight: 700;
          color: #334155;
          text-transform: uppercase;
        }
        .sig-sub {
          font-size: 9px;
          color: #64748b;
        }
        .watermark {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          opacity: 0.04;
          pointer-events: none;
          z-index: 0;
          width: 320px;
          height: 320px;
        }
      </style>
    </head>
    <body>
      <div class="cert-container">
        <img class="watermark" src="${school.logo}" alt="">

        <div class="header-top">
          <img class="header-logo" src="${school.logo}" alt="Logo">
          <div class="header-title-wrap">
            <h1 class="school-name">${school.name}</h1>
            <div class="school-tagline">${school.tagline}</div>
            <div class="school-sub">${school.address} &bull; Contact: ${school.phone}</div>
            <div style="font-size: 11px; font-weight: 800; color: #0284c7; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em;">
              Official Statement of Academic Marks &bull; Single Subject Register
            </div>
          </div>
          <div style="text-align: right; width: 80px;">
            <div style="border: 1px solid #cbd5e1; border-radius: 4px; padding: 4px; display: inline-block;">
              <span style="font-size: 9px; font-weight: 800; color: #0284c7; display: block;">VERIFIED</span>
              <span style="font-size: 8px; color: #64748b;">OFFICIAL</span>
            </div>
          </div>
        </div>

        <div class="meta-strip">
          <div class="meta-item"><strong>Examination:</strong> <span>${examName}</span></div>
          <div class="meta-item"><strong>Subject:</strong> <span style="color: #0284c7;">${subjectName}</span></div>
          <div class="meta-item"><strong>Academic Session:</strong> <span>${school.session}</span></div>
          <div class="meta-item"><strong>Evaluation Date:</strong> <span>${examDate}</span></div>
          <div class="meta-item"><strong>Max / Pass:</strong> <span>${studentData[0]?.max || 100} / ${studentData[0]?.pass || 35}</span></div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 4%;">#</th>
              <th style="width: 13%;">Roll Number</th>
              <th style="width: 28%;">Scholar Full Name</th>
              <th style="width: 20%;">Academic Class / Batch</th>
              <th style="width: 7%; text-align: center;">Max</th>
              <th style="width: 7%; text-align: center;">Pass</th>
              <th style="width: 7%; text-align: center;">Obtained</th>
              <th style="width: 7%; text-align: center;">Percentage</th>
              <th style="width: 7%; text-align: center;">Grade</th>
              <th style="width: 8%; text-align: center;">Result</th>
            </tr>
          </thead>
          <tbody>
            ${tableRowsHtml}
          </tbody>
        </table>

        <div class="stats-ribbon">
          <div class="stat-card">
            <div class="label">Total Scholars</div>
            <div class="val">${studentData.length}</div>
          </div>
          <div class="stat-card">
            <div class="label">Passed Candidates</div>
            <div class="val" style="color: #15803d;">${passCount} (${passRate}%)</div>
          </div>
          <div class="stat-card">
            <div class="label">Failed Candidates</div>
            <div class="val" style="color: ${failCount > 0 ? '#b91c1c' : '#64748b'};">${failCount}</div>
          </div>
          <div class="stat-card">
            <div class="label">Class Subject Average</div>
            <div class="val" style="color: #0284c7;">${classAvgPct}%</div>
          </div>
          <div class="stat-card">
            <div class="label">Subject Highest Score</div>
            <div class="val" style="color: #15803d;">${highestScore >= 0 ? highestScore : '-'}</div>
          </div>
        </div>

        <div class="signatures-row">
          <div class="sig-block">
            <div class="sig-line"></div>
            <div class="sig-title">Subject Faculty / Evaluator</div>
            <div class="sig-sub">Signature &amp; Date</div>
          </div>
          <div class="sig-block">
            <div class="sig-line"></div>
            <div class="sig-title">Controller of Examinations</div>
            <div class="sig-sub">Verification Stamp</div>
          </div>
          <div class="sig-block">
            <div class="sig-line"></div>
            <div class="sig-title">Head of Institution / Principal</div>
            <div class="sig-sub">Official Academy Seal</div>
          </div>
        </div>

        <div style="margin-top: 8px; font-size: 8.5px; color: #94a3b8; display: flex; justify-content: space-between;">
          <span>Generated on: ${new Date().toLocaleString()} &bull; KSV Academy ERP &amp; Portal</span>
          <span>Official Academic Transcript Document &bull; Single Subject Evaluation Register</span>
        </div>
      </div>
    </body>
    </html>
  `;

  const doc = printIframe.contentWindow.document;
  doc.open();
  doc.write(printHtml);
  doc.close();

  setTimeout(() => {
    printIframe.contentWindow.focus();
    printIframe.contentWindow.print();
  }, 350);
}

function downloadMarksheetPNG() {
  const card = document.getElementById('report-card-view');
  if (!card) {
    alert('Please select a student and evaluation above to download report card.');
    return;
  }
  const studentName = <?php echo json_encode($student_profile['student_name'] ?? 'Scholar'); ?>;
  const examName = <?php echo json_encode($active_marksheet['exam_name'] ?? 'ReportCard'); ?>;
  const filename = `Marksheet_${studentName.replace(/\s+/g, '_')}_${examName.replace(/\s+/g, '_')}.png`;

  if (typeof html2canvas === 'function') {
    html2canvas(card, {
      scale: 2.5,
      useCORS: true,
      backgroundColor: '#ffffff',
      logging: false
    }).then(canvas => {
      const link = document.createElement('a');
      link.download = filename;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }).catch(err => {
      console.error('Download error:', err);
      window.print();
    });
  } else {
    window.print();
  }
}

function toggleCustomExamInput(sel) {
  const wrap = document.getElementById('customExamFieldWrap');
  const input = document.getElementById('customExamInput');
  if (!wrap || !input) return;
  if (sel && sel.value === 'Other') {
    wrap.style.display = 'block';
    input.setAttribute('required', 'required');
    setTimeout(() => { try { input.focus(); } catch(e){} }, 50);
  } else {
    wrap.style.display = 'none';
    input.removeAttribute('required');
    input.value = '';
  }
}

function openCreateMarksheetModal(studentId = null) {
  const modal = document.getElementById('createMarksheetModal');
  if (!modal) return;
  if (studentId) {
    const sel = document.getElementById('modalStudentSelect');
    if (sel) sel.value = studentId;
  }
  const examSelect = document.getElementById('createExamSelect');
  if (examSelect) {
    toggleCustomExamInput(examSelect);
  }
  modal.style.display = 'flex';
  recalcModalTotals();
}

function closeCreateMarksheetModal() {
  const modal = document.getElementById('createMarksheetModal');
  if (modal) modal.style.display = 'none';
  const examSelect = document.getElementById('createExamSelect');
  if (examSelect && examSelect.value === 'Other') {
    examSelect.value = 'Unit Test 1';
    toggleCustomExamInput(examSelect);
  }
}

function addSubjectRow() {
  const tbody = document.getElementById('modalSubjectsBody');
  const tr = document.createElement('tr');
  tr.style.borderBottom = '1px solid #f1f5f9';
  tr.innerHTML = `
    <td style="padding: 6px 10px;">
      <input type="text" name="subjects[]" placeholder="Enter Subject Title" class="hrms-input sub-name-input" required style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px;">
    </td>
    <td style="padding: 6px 10px;">
      <input type="number" name="max_marks[]" value="100" min="1" class="hrms-input sub-max-input" oninput="recalcModalTotals();" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-size: 13px; font-weight: 600;">
    </td>
    <td style="padding: 6px 10px;">
      <input type="number" step="0.5" name="obtained[]" value="85" min="0" class="hrms-input sub-obt-input" oninput="recalcModalTotals();" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; text-align: center; font-weight: 800; font-size: 13px; color: #0284c7;">
    </td>
    <td style="padding: 6px 6px; text-align: center;">
      <button type="button" onclick="removeSubjectRow(this);" style="background: none; border: none; color: #ef4444; font-size: 14px; cursor: pointer;" title="Remove row">&times;</button>
    </td>
  `;
  tbody.appendChild(tr);
  recalcModalTotals();
}

function removeSubjectRow(btn) {
  const row = btn.closest('tr');
  if (row) {
    row.remove();
    recalcModalTotals();
  }
}

function recalcModalTotals() {
  const maxInputs = document.querySelectorAll('.sub-max-input');
  const obtInputs = document.querySelectorAll('.sub-obt-input');
  let totalMax = 0;
  let totalObt = 0;

  for (let i = 0; i < maxInputs.length; i++) {
    const m = parseFloat(maxInputs[i].value) || 0;
    const o = parseFloat(obtInputs[i]?.value) || 0;
    totalMax += m;
    totalObt += o;
  }

  const pct = totalMax > 0 ? ((totalObt / totalMax) * 100).toFixed(2) : 0;
  let grade = 'F';
  let isPass = pct >= 35;

  if (pct >= 90) grade = 'A+';
  else if (pct >= 80) grade = 'A';
  else if (pct >= 70) grade = 'B+';
  else if (pct >= 60) grade = 'B';
  else if (pct >= 50) grade = 'C';
  else if (pct >= 35) grade = 'D';

  const elObt = document.getElementById('calcTotalObtained');
  if (elObt) elObt.innerText = totalObt;
  const elMax = document.getElementById('calcTotalMax');
  if (elMax) elMax.innerText = totalMax;
  const elPct = document.getElementById('calcPercentage');
  if (elPct) elPct.innerText = pct + '%';

  const badge = document.getElementById('calcGradeBadge');
  if (badge) {
    badge.innerText = grade + (isPass ? ' (PASS)' : ' (FAIL)');
    badge.className = 'grade-pill-badge ' + (isPass ? 'pass' : 'fail');
  }
}

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeCreateMarksheetModal();
    closeBulkAddSubjectModal();
  }
});

// Run initial calculation
document.addEventListener('DOMContentLoaded', recalcModalTotals);
</script>

<?php require_once __DIR__ . '/../includes/layout-footer.php'; ?>
