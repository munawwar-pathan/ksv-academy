<?php
// HTTP Security Headers (Defense-in-depth across Apache, LiteSpeed, Nginx, PHP built-in server)
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
}

require_once __DIR__ . '/../config.php';

$current_user = require_login(['super_admin', 'staff', 'parent', 'student']);
if ($current_user['role'] === 'staff') {
    require_menu_permission('admin_fees');
}
$page_title = 'Fee Management & Accounts';
$page_heading = 'Fee Management';
$page_subheading = 'Tuition Invoices, Payment Receipts, Outstanding Balances & Ledger Records';
$active_menu = 'fees';

$db = get_db_connection();
$active_session = get_active_session();
$session_id = $active_session ? intval($active_session['id']) : 1;
$current_session_name = $active_session['session_name'] ?? (defined('CURRENT_SESSION') ? CURRENT_SESSION : date('Y'));
$school_settings = get_school_settings();

// Academic Standards & Specialized Course Categories (Matching Student Roaster & Attendance)
$academic_categories = get_default_academic_categories();
$flat_predefined_standards = [];
foreach ($academic_categories as $cat => $std_list) {
    foreach ($std_list as $s_item) {
        $flat_predefined_standards[] = $s_item;
    }
}
$db_standards = $db->query("SELECT DISTINCT standard FROM students WHERE session_id = " . intval($session_id) . " AND standard IS NOT NULL AND standard != ''")->fetchAll(PDO::FETCH_COLUMN) ?: [];
$standards = array_values(array_unique(array_filter(array_merge($flat_predefined_standards, $db_standards))));
$custom_db_standards = array_values(array_diff($db_standards, $flat_predefined_standards));

$allowed_methods = ['Cash', 'UPI', 'Net Banking', 'Cheque', 'Credit Card'];
$allowed_fee_types = ['Tuition Fee', 'Admission Fee', 'Examination Fee', 'Laboratory Charges', 'Library Fee', 'Transport Fee', 'Annual Charges'];

// Filters
$search = trim((string)($_GET['search'] ?? ''));
$raw_standard = trim((string)($_GET['standard'] ?? ''));
$filter_standard = ($raw_standard !== '' && $raw_standard !== 'all' && in_array($raw_standard, $standards, true)) ? $raw_standard : '';
$filter_method = isset($_GET['method']) && in_array($_GET['method'], $allowed_methods, true) ? (string)$_GET['method'] : '';
$filter_student_id = intval($_GET['student_id'] ?? 0);

// Pagination & Limits Setup (10, 20, 30, 40, 50)
$allowed_limits = [10, 20, 30, 40, 50];
$limit = intval($_GET['limit'] ?? 10);
if (!in_array($limit, $allowed_limits, true)) {
    $limit = 10;
}
$page = max(1, intval($_GET['page'] ?? 1));

// Resolve authorization for parent/student roles (Prevent IDOR & unauthorized directory browsing)
$is_parent_or_student = in_array($current_user['role'], ['student', 'parent'], true);
$allowed_student_ids = [];
if ($is_parent_or_student) {
    if ($current_user['role'] === 'student') {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    } else {
        $stmt_auth = $db->prepare("SELECT id FROM students WHERE parent_user_id = ? AND session_id = ?");
        $stmt_auth->execute([$current_user['id'], $session_id]);
    }
    $allowed_student_ids = array_map('intval', $stmt_auth->fetchAll(PDO::FETCH_COLUMN));

    if (empty($allowed_student_ids)) {
        $filter_student_id = -1;
    } elseif ($filter_student_id > 0 && in_array($filter_student_id, $allowed_student_ids, true)) {
        // Valid selected child
    } elseif (count($allowed_student_ids) === 1) {
        $filter_student_id = $allowed_student_ids[0];
    } else {
        // Multi-child parent without a specific child selected
        $filter_student_id = 0;
    }
}

// Rate Limiting Protection (Max 30 fee submissions per 5 minutes per session)
$now = time();
if (!isset($_SESSION['fees_post_attempts']) || !is_array($_SESSION['fees_post_attempts'])) {
    $_SESSION['fees_post_attempts'] = [];
}
$_SESSION['fees_post_attempts'] = array_filter($_SESSION['fees_post_attempts'], function($timestamp) use ($now) {
    return ($now - (int)$timestamp) < 300;
});
$is_rate_limited = (count($_SESSION['fees_post_attempts']) >= 30);

// Handle Record Fee Collection (Super Admin Only)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($current_user['role'] !== 'super_admin') {
        http_response_code(403);
        set_flash('error', 'Unauthorized action: Fee collection is restricted to administrators.');
        header('Location: ' . ADMIN_URL . '/fees');
        exit;
    }

    // 1. Anti-bot honeypot check
    if (!empty($_POST['fees_hp'])) {
        usleep(300000);
        set_flash('error', 'Invalid submission detected.');
        header('Location: ' . ADMIN_URL . '/fees');
        exit;
    }

    // 2. Brute-force flood lockout
    if ($is_rate_limited) {
        set_flash('error', 'Too many requests in a short period. Please wait a moment and try again.');
        header('Location: ' . ADMIN_URL . '/fees');
        exit;
    }
    $_SESSION['fees_post_attempts'][] = $now;

    // 3. CSRF token validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash('error', 'Security session expired or invalid CSRF token. Please refresh the page and try again.');
        header('Location: ' . ADMIN_URL . '/fees');
        exit;
    }

    $action = trim((string)($_POST['action'] ?? ''));

    if ($action === 'collect_fee') {
        $student_id = intval($_POST['student_id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $discount = max(0, min(10000000, floatval($_POST['discount'] ?? 0)));
        $payment_method = trim((string)($_POST['payment_method'] ?? 'Cash'));
        if (!in_array($payment_method, $allowed_methods, true)) {
            $payment_method = 'Cash';
        }
        $fee_type = trim((string)($_POST['fee_type'] ?? 'Tuition Fee'));
        if (!in_array($fee_type, $allowed_fee_types, true)) {
            $fee_type = 'Tuition Fee';
        }

        // Strict payment date validation with Gregorian calendar check
        $payment_date = date('Y-m-d');
        if (!empty($_POST['payment_date']) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', (string)$_POST['payment_date'], $m)) {
            if (checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
                $payment_date = (string)$_POST['payment_date'];
            }
        }

        $remarks = mb_substr(trim((string)($_POST['remarks'] ?? 'Fee payment received')), 0, 255);

        if ($student_id <= 0 || $amount <= 0 || $amount > 10000000) {
            set_flash('error', 'Please enter a valid student and payment amount.');
            header('Location: ' . ADMIN_URL . '/fees');
            exit;
        }

        // Verify that the student exists and belongs to the active session
        $stmt_stu_chk = $db->prepare("SELECT id, student_name, roll_no, total_fees, paid_fees FROM students WHERE id = ? AND session_id = ? LIMIT 1");
        $stmt_stu_chk->execute([$student_id, $session_id]);
        $stu_row = $stmt_stu_chk->fetch(PDO::FETCH_ASSOC);

        if ($stu_row) {
            try {
                $receipt_no = 'RCPT-' . strtoupper(substr(bin2hex(random_bytes(5)), 0, 8));

                $stmt = $db->prepare("
                    INSERT INTO fee_payments (session_id, student_id, receipt_no, amount, payment_method, payment_date, fee_type, discount, remarks)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$session_id, $student_id, $receipt_no, $amount, $payment_method, $payment_date, $fee_type, $discount, $remarks]);

                // Update student paid_fees with session isolation
                $upd_stmt = $db->prepare("UPDATE students SET paid_fees = paid_fees + ? WHERE id = ? AND session_id = ?");
                $upd_stmt->execute([$amount, $student_id, $session_id]);

                // Sync installment statuses and fee splits
                refresh_student_fee_installment_statuses($student_id, $session_id);

                set_flash('success', "Fee payment of ₹" . number_format($amount, 2) . " recorded for " . htmlspecialchars($stu_row['student_name'], ENT_QUOTES, 'UTF-8') . " with Receipt #{$receipt_no}!");
                header('Location: ' . ADMIN_URL . '/fees?receipt=' . urlencode($receipt_no));
                exit;
            } catch (Exception $e) {
                error_log("Fee collection error: " . $e->getMessage());
                set_flash('error', 'An error occurred while recording the fee collection. Please try again.');
                header('Location: ' . ADMIN_URL . '/fees');
                exit;
            }
        } else {
            set_flash('error', 'Invalid student selection or record not found in active session.');
            header('Location: ' . ADMIN_URL . '/fees');
            exit;
        }
    }
}

// Fetch all students and their configured fee installments (Created in Add Student)
$students_list = [];
$students_installments_map = [];
if ($current_user['role'] === 'super_admin') {
    $all_students = $db->prepare("SELECT id, student_name, roll_no, standard, total_fees, paid_fees, fee_splits FROM students WHERE session_id = ? ORDER BY student_name ASC");
    $all_students->execute([$session_id]);
    $students_list = $all_students->fetchAll(PDO::FETCH_ASSOC);

    foreach ($students_list as $stu) {
        $sid = intval($stu['id']);
        $splits = get_student_fee_splits($sid, $session_id);
        if (empty($splits) && floatval($stu['total_fees']) > 0) {
            $tot = floatval($stu['total_fees']);
            $pd = floatval($stu['paid_fees']);
            $rem = max(0, $tot - $pd);
            $splits = [[
                'id' => 0,
                'student_id' => $sid,
                'installment_no' => 1,
                'title' => 'Installment 1',
                'amount' => $tot,
                'paid_amount' => $pd,
                'pending_amount' => $rem,
                'due_date' => date('Y-m-d', strtotime('+30 days')),
                'due_date_formatted' => date('d M Y', strtotime('+30 days')),
                'status' => ($rem <= 0 ? 'paid' : ($pd > 0 ? 'partially_paid' : 'pending')),
                'is_paid' => ($rem <= 0),
                'is_overdue' => false,
                'is_due_soon' => false
            ]];
        }
        $students_installments_map[$sid] = $splits;
    }
}

// Build WHERE filter conditions
$where_clauses = ["fp.session_id = ?"];
$where_params = [$session_id];

if ($is_parent_or_student) {
    if (empty($allowed_student_ids)) {
        $where_clauses[] = "1 = 0";
    } elseif ($filter_student_id > 0 && in_array($filter_student_id, $allowed_student_ids, true)) {
        $where_clauses[] = "fp.student_id = ?";
        $where_params[] = $filter_student_id;
    } elseif (count($allowed_student_ids) === 1) {
        $where_clauses[] = "fp.student_id = ?";
        $where_params[] = $allowed_student_ids[0];
    } else {
        $in_auth_ph = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $where_clauses[] = "fp.student_id IN ($in_auth_ph)";
        $where_params = array_merge($where_params, $allowed_student_ids);
    }
} else {
    if ($filter_student_id > 0) {
        $where_clauses[] = "fp.student_id = ?";
        $where_params[] = $filter_student_id;
    }
}

if (!empty($search)) {
    $search_clean = mb_substr($search, 0, 100);
    $search_like = '%' . addcslashes($search_clean, '%_\\') . '%';
    $where_clauses[] = "(s.student_name LIKE ? OR s.roll_no LIKE ? OR fp.receipt_no LIKE ? OR s.admission_no LIKE ? OR s.parent_phone LIKE ? OR fp.remarks LIKE ?)";
    $where_params[] = $search_like;
    $where_params[] = $search_like;
    $where_params[] = $search_like;
    $where_params[] = $search_like;
    $where_params[] = $search_like;
    $where_params[] = $search_like;
}

if (!empty($filter_standard)) {
    $where_clauses[] = "s.standard = ?";
    $where_params[] = $filter_standard;
}

if (!empty($filter_method)) {
    if ($filter_method === 'UPI') {
        $where_clauses[] = "fp.payment_method LIKE '%UPI%'";
    } else {
        $where_clauses[] = "fp.payment_method LIKE ?";
        $where_params[] = "%$filter_method%";
    }
}

$where_sql = implode(' AND ', $where_clauses);

// Count total matching payment records
$count_query = "
    SELECT COUNT(*)
    FROM fee_payments fp
    JOIN students s ON fp.student_id = s.id
    WHERE {$where_sql}
";
$count_stmt = $db->prepare($count_query);
$count_stmt->execute($where_params);
$total_records = intval($count_stmt->fetchColumn());

// Calculate total pages & offset
$total_pages = max(1, (int)ceil($total_records / $limit));
if ($page > $total_pages) {
    $page = $total_pages;
}
$offset = ($page - 1) * $limit;

// Query Payments with Search, Filters and Pagination
$query = "
    SELECT fp.*, s.student_name, s.roll_no, s.standard, s.total_fees, s.paid_fees, s.photo, s.admission_no, s.parent_phone, s.gender, s.blood_group, s.section
    FROM fee_payments fp
    JOIN students s ON fp.student_id = s.id
    WHERE {$where_sql}
    ORDER BY fp.id DESC
    LIMIT ? OFFSET ?
";
$stmt = $db->prepare($query);
$bind_idx = 1;
foreach ($where_params as $val) {
    $stmt->bindValue($bind_idx++, $val);
}
$stmt->bindValue($bind_idx++, $limit, PDO::PARAM_INT);
$stmt->bindValue($bind_idx++, $offset, PDO::PARAM_INT);
$stmt->execute();
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Pagination indicators
$start_record = $total_records > 0 ? $offset + 1 : 0;
$end_record = min($offset + $limit, $total_records);

// Helper for generating fee pagination links
function get_fee_pagination_url($target_page, $search, $filter_standard, $filter_method, $filter_student_id, $limit) {
    $params = [];
    if (!empty($search)) $params['search'] = $search;
    if (!empty($filter_standard)) $params['standard'] = $filter_standard;
    if (!empty($filter_method)) $params['method'] = $filter_method;
    if ($filter_student_id > 0) $params['student_id'] = $filter_student_id;
    if ($limit != 10) $params['limit'] = $limit;
    if ($target_page > 1) $params['page'] = $target_page;
    return ADMIN_URL . '/fees' . (!empty($params) ? '?' . http_build_query($params) : '');
}

// Fetch all payments mapped by student_id to show installment history (Scoped to current page & session)
$page_student_ids = array_values(array_unique(array_filter(array_map('intval', array_column($payments, 'student_id')))));
$student_payments_map = [];

if (!empty($page_student_ids)) {
    $ph = implode(',', array_fill(0, count($page_student_ids), '?'));
    $stmt_asp = $db->prepare("
        SELECT fp.*, s.student_name, s.roll_no, s.standard, s.total_fees, s.paid_fees
        FROM fee_payments fp
        JOIN students s ON fp.student_id = s.id
        WHERE fp.session_id = ? AND fp.student_id IN ($ph)
        ORDER BY fp.payment_date ASC, fp.id ASC
    ");
    $stmt_asp->execute(array_merge([$session_id], $page_student_ids));
    $all_stu_payments = $stmt_asp->fetchAll(PDO::FETCH_ASSOC);

    foreach ($all_stu_payments as $sp) {
        $student_payments_map[$sp['student_id']][] = $sp;
    }
}

foreach ($payments as &$p) {
    $p['all_payments'] = $student_payments_map[$p['student_id']] ?? [$p];
}
unset($p);

// Financial KPI Metrics (Scoped to authorized students for parents/students, or academy-wide for staff/admin)
if ($is_parent_or_student) {
    if (empty($allowed_student_ids)) {
        $total_collected = 0.0;
        $total_receivable = 0.0;
        $receipts_count = 0;
    } else {
        $in_auth_ph = implode(',', array_fill(0, count($allowed_student_ids), '?'));
        $stmt_tc = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM fee_payments WHERE session_id = ? AND student_id IN ($in_auth_ph)");
        $stmt_tc->execute(array_merge([$session_id], $allowed_student_ids));
        $total_collected = floatval($stmt_tc->fetchColumn());

        $stmt_tr = $db->prepare("SELECT COALESCE(SUM(total_fees), 0) FROM students WHERE session_id = ? AND id IN ($in_auth_ph)");
        $stmt_tr->execute(array_merge([$session_id], $allowed_student_ids));
        $total_receivable = floatval($stmt_tr->fetchColumn());

        $stmt_rc = $db->prepare("SELECT COUNT(*) FROM fee_payments WHERE session_id = ? AND student_id IN ($in_auth_ph)");
        $stmt_rc->execute(array_merge([$session_id], $allowed_student_ids));
        $receipts_count = intval($stmt_rc->fetchColumn());
    }
} else {
    $stmt_tc = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM fee_payments WHERE session_id = ?");
    $stmt_tc->execute([$session_id]);
    $total_collected = floatval($stmt_tc->fetchColumn());

    $stmt_tr = $db->prepare("SELECT COALESCE(SUM(total_fees), 0) FROM students WHERE session_id = ?");
    $stmt_tr->execute([$session_id]);
    $total_receivable = floatval($stmt_tr->fetchColumn());

    $stmt_rc = $db->prepare("SELECT COUNT(*) FROM fee_payments WHERE session_id = ?");
    $stmt_rc->execute([$session_id]);
    $receipts_count = intval($stmt_rc->fetchColumn());
}

$collection_rate = $total_receivable > 0 ? round(($total_collected / $total_receivable) * 100, 1) : 0;
$dues_rate = $total_receivable > 0 ? round(($total_dues / $total_receivable) * 100, 1) : 0;

require_once __DIR__ . '/../includes/layout-header.php';
?>

<!-- html2canvas Library for Receipt Image Generation -->
<script src="<?php echo HRMS_URL; ?>/assets/js/html2canvas.min.js"></script>

<style>
/* ── Academic & Coaching Institute Fee Receipt Styles ── */
.pay-receipt {
  padding: 0;
  background: #ffffff;
  color: #0f172a;
  font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
  width: 100%;
  max-width: 440px;
  margin: 0 auto;
  border-radius: 12px;
  overflow: hidden;
  border: 1.5px solid #cbd5e1;
  box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08);
}
.pay-receipt .ri-top-accent {
  height: 6px;
  background: linear-gradient(90deg, #0f172a 0%, #0092df 50%, #0284c7 100%);
}
.pay-receipt .receipt-body {
  padding: 14px 18px 12px;
}
.pay-receipt .ri-brand-row {
  display: flex;
  align-items: center;
  gap: 14px;
  padding-bottom: 12px;
  border-bottom: 2px solid #e2e8f0;
}
.pay-receipt .ri-logo-box {
  width: 54px;
  height: 54px;
  min-width: 54px;
  border-radius: 10px;
  border: 1.5px solid #e2e8f0;
  padding: 3px;
  background: #ffffff;
  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
}
.pay-receipt .ri-logo-box img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  border-radius: 6px;
}
.pay-receipt .ri-brand-info {
  flex: 1;
}
.pay-receipt .ri-title {
  margin: 0;
  font-size: 16px;
  font-weight: 800;
  color: #0f172a;
  font-family: 'Outfit', sans-serif;
  letter-spacing: -0.01em;
  line-height: 1.2;
}
.pay-receipt .ri-sub {
  font-size: 10px;
  font-weight: 700;
  color: #0284c7;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  margin-top: 2px;
}
.pay-receipt .ri-address {
  font-size: 9.5px;
  color: #64748b;
  margin-top: 2px;
  line-height: 1.3;
}

/* Document Title Bar */
.pay-receipt .receipt-doc-band {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 5px 10px;
  margin: 8px 0 6px;
}
.pay-receipt .receipt-doc-title {
  font-size: 11px;
  font-weight: 800;
  color: #0f172a;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  font-family: 'Outfit', sans-serif;
}
.pay-receipt .receipt-doc-session {
  font-size: 10px;
  font-weight: 700;
  color: #0284c7;
  background: #e0f2fe;
  padding: 2px 7px;
  border-radius: 5px;
}

/* Meta Grid */
.pay-receipt .receipt-meta-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 6px 10px;
  margin-bottom: 8px;
}
.pay-receipt .rmg-cell {
  display: flex;
  flex-direction: column;
}
.pay-receipt .rmg-label {
  font-size: 9px;
  color: #64748b;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 0.04em;
}
.pay-receipt .rmg-val {
  font-size: 11.5px;
  color: #0f172a;
  font-weight: 600;
  margin-top: 1px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.pay-receipt .rmg-val.bold {
  font-weight: 800;
  font-family: 'Outfit', sans-serif;
}
.pay-receipt .rmg-val.mono-badge {
  font-family: monospace;
  font-weight: 800;
  color: #0284c7;
}

/* Particulars Table */
.pay-receipt .receipt-table-wrapper {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 10px;
}
.pay-receipt .receipt-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11px;
}
.pay-receipt .receipt-table th {
  background: #f1f5f9;
  color: #334155;
  font-weight: 800;
  font-size: 9.5px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 6px 10px;
  border-bottom: 1px solid #cbd5e1;
}
.pay-receipt .receipt-table td {
  padding: 8px 10px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
}
.pay-receipt .receipt-table tr.total-row td {
  background: #f8fafc;
  border-top: 1.5px solid #cbd5e1;
  border-bottom: none;
  font-weight: 800;
  padding: 8px 10px;
}

/* Words Box */
.pay-receipt .receipt-words-box {
  background: #f0fdf4;
  border: 1px dashed #86efac;
  border-radius: 8px;
  padding: 7px 10px;
  margin-bottom: 12px;
  font-size: 10.5px;
}
.pay-receipt .receipt-words-box .words-label {
  font-weight: 800;
  color: #166534;
  text-transform: uppercase;
  font-size: 9px;
  letter-spacing: 0.04em;
  display: block;
  margin-bottom: 2px;
}
.pay-receipt .receipt-words-box .words-val {
  font-weight: 700;
  color: #14532d;
  font-style: italic;
}

/* Signatures & Seal Section */
.pay-receipt .receipt-auth-row {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin: 10px 0 8px;
  padding: 0 4px;
}
.pay-receipt .auth-sign-box {
  text-align: center;
  width: 115px;
}
.pay-receipt .auth-sign-line {
  border-bottom: 1.5px dashed #94a3b8;
  height: 24px;
  margin-bottom: 4px;
  font-size: 10.5px;
  font-weight: 700;
  color: #0f172a;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}
.pay-receipt .auth-sign-label {
  font-size: 9px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

/* Academy Stamp Badge */
.pay-receipt .auth-seal-badge {
  width: 72px;
  height: 72px;
  border-radius: 50%;
  border: 2px dashed #0284c7;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 4px;
  background: rgba(2, 132, 199, 0.03);
  transform: rotate(-6deg);
  margin: 0 auto;
}
.pay-receipt .seal-text-top {
  font-size: 7px;
  font-weight: 900;
  color: #0284c7;
  letter-spacing: 0.05em;
  line-height: 1;
}
.pay-receipt .seal-text-mid {
  font-size: 7.5px;
  font-weight: 900;
  color: #059669;
  letter-spacing: 0.08em;
  margin: 2px 0;
  line-height: 1;
}
.pay-receipt .seal-text-bot {
  font-size: 6.5px;
  font-weight: 800;
  color: #0284c7;
  line-height: 1;
}

/* Bottom QR & Terms */
.pay-receipt .receipt-bottom-bar {
  display: flex;
  gap: 10px;
  align-items: center;
  border-top: 1px solid #e2e8f0;
  padding-top: 8px;
  margin-top: 8px;
}
.pay-receipt .rb-qr-wrap {
  width: 62px;
  min-width: 62px;
  height: 62px;
  padding: 3px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
}
.pay-receipt .rb-qr-wrap img {
  width: 100%;
  height: 100%;
  display: block;
}
.pay-receipt .rb-notes {
  flex: 1;
  font-size: 8.5px;
  color: #64748b;
  line-height: 1.35;
}
.pay-receipt .rb-notes strong {
  color: #334155;
}

/* ── Receipt Modal Custom Visible Scrollbar & Layout ── */
#receiptPrintModal {
  overflow-y: auto !important;
}
#receiptPrintModal .receipt-modal-card {
  max-width: 530px !important;
  width: 95% !important;
  max-height: 90vh !important;
  display: flex !important;
  flex-direction: column !important;
  border-radius: 20px !important;
  overflow: hidden !important;
  box-shadow: 0 25px 60px -15px rgba(15, 23, 42, 0.4) !important;
  margin: auto !important;
}
#receiptModalBody {
  padding: 0 !important;
  background: #f8fafc !important;
  display: block !important;
  overflow-y: scroll !important; /* Force visible vertical scrollbar */
  overflow-x: hidden !important;
  flex: 1 1 auto !important;
  min-height: 220px !important;
  max-height: calc(90vh - 135px) !important;
  scroll-behavior: smooth !important;
  -webkit-overflow-scrolling: touch !important;
  position: relative !important;
  scrollbar-width: thin !important;
  scrollbar-color: #0284c7 #e2e8f0 !important;
}
#receiptModalBody::-webkit-scrollbar {
  width: 9px !important;
  display: block !important;
}
#receiptModalBody::-webkit-scrollbar-track {
  background: #f1f5f9 !important;
  border-left: 1px solid #e2e8f0 !important;
}
#receiptModalBody::-webkit-scrollbar-thumb {
  background: #0284c7 !important;
  border-radius: 10px !important;
  border: 2px solid #f1f5f9 !important;
}
#receiptModalBody::-webkit-scrollbar-thumb:hover {
  background: #0369a1 !important;
}

/* Print CSS */
@media print {
  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }
  html, body {
    background: #ffffff !important;
    color: #000000 !important;
    margin: 0 !important;
    padding: 0 !important;
    height: auto !important;
  }
  .hrms-sidebar, .hrms-topbar, .roaster-toolbar-card, .table-card, .stat-grid, .no-print, .modal-close-btn {
    display: none !important;
  }
  .hrms-main-content {
    margin: 0 !important;
    padding: 0 !important;
  }
  #receiptPrintModal {
    position: static !important;
    background: transparent !important;
    display: block !important;
    padding: 0 !important;
  }
  #receiptPrintModal .hrms-modal-card {
    max-width: 100% !important;
    box-shadow: none !important;
    border: none !important;
    background: transparent !important;
    max-height: none !important;
    overflow: visible !important;
  }
  #receiptModalBody {
    overflow: visible !important;
    max-height: none !important;
    height: auto !important;
    padding: 0 !important;
    display: block !important;
  }
  #receipt_print_area {
    display: flex !important;
    justify-content: center !important;
    padding: 10px 0 !important;
  }
  .pay-receipt {
    box-shadow: none !important;
    border: 1.5px solid #cbd5e1 !important;
    max-width: 480px !important;
    margin: 10px auto !important;
    page-break-inside: avoid !important;
    break-inside: avoid !important;
  }
}

/* ── Fee Ledger Table & Badge Styles (Simple & Sober - Matching staff-id & student-id) ── */
.staff-id-table, .student-id-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}
.staff-id-table thead th, .student-id-table thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 0.73rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
.staff-id-table tbody td, .student-id-table tbody td {
  padding: 11px 12px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
  font-size: 0.84rem;
}
.staff-id-table tbody tr, .student-id-table tbody tr {
  transition: background-color 0.15s ease;
}
.staff-id-table tbody tr:hover, .student-id-table tbody tr:hover {
  background-color: #f8fafc;
}

/* Badge & Tag Elements */
.sid-receipt-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  color: #0284c7;
  padding: 2px 7px;
  border-radius: 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.74rem;
  font-weight: 700;
  white-space: nowrap;
}
.sid-roll-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  color: #0284c7;
  padding: 2px 7px;
  border-radius: 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.74rem;
  font-weight: 700;
  white-space: nowrap;
}
.sid-std-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.75rem;
  font-weight: 600;
  white-space: nowrap;
}
.sid-blood-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
  font-size: 0.70rem;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  white-space: nowrap;
}
.sid-feehead-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.74rem;
  font-weight: 600;
  white-space: nowrap;
}
.sid-mode-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 2px 8px;
  border-radius: 5px;
  font-size: 0.74rem;
  font-weight: 600;
  white-space: nowrap;
}
.sid-mode-pill.upi {
  background: #f0f9ff;
  border-color: #bae6fd;
  color: #0284c7;
}
.sid-mode-pill.cash {
  background: #f0fdf4;
  border-color: #bbf7d0;
  color: #166534;
}
.sid-mode-pill.netbanking, .sid-mode-pill.bank {
  background: #f5f3ff;
  border-color: #ddd6fe;
  color: #7c3aed;
}
.sid-mode-pill.cheque {
  background: #fffbeb;
  border-color: #fde68a;
  color: #b45309;
}

/* Sober Action Buttons */
.sid-btn-action {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  font-size: 0.74rem;
  font-weight: 600;
  border-radius: 6px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.sid-btn-primary {
  color: #0284c7;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
}
.sid-btn-primary:hover {
  background: #0284c7;
  color: #ffffff;
  border-color: #0284c7;
}
.sid-btn-secondary {
  color: #166534;
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
}
.sid-btn-secondary:hover {
  background: #16a34a;
  color: #ffffff;
  border-color: #16a34a;
}

/* ══════════════════════════════════════════════════════════════════════
   RESPONSIVE MOBILE VIEW ENHANCEMENTS FOR FEE MANAGEMENT
   ══════════════════════════════════════════════════════════════════════ */

/* Tablet & Mobile Screens (<= 768px) */
@media (max-width: 768px) {
  /* Financial KPI Stat Metric Cards - Clean 2x2 Grid */
  .stat-grid {
    display: grid !important;
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 10px !important;
    margin-bottom: 14px !important;
  }
  .stat-card {
    padding: 10px 12px !important;
    border-radius: 10px !important;
  }
  .stat-label {
    font-size: 0.65rem !important;
    line-height: 1.2 !important;
  }
  .stat-number {
    font-size: 1.25rem !important;
    line-height: 1.2 !important;
  }
  .stat-icon-wrapper {
    width: 30px !important;
    height: 30px !important;
    min-width: 30px !important;
    font-size: 0.8rem !important;
  }
  .stat-card-progress {
    height: 3px !important;
    margin-top: 5px !important;
  }
  .stat-card-footer {
    margin-top: 6px !important;
    padding-top: 5px !important;
    font-size: 0.64rem !important;
    flex-wrap: wrap !important;
    gap: 3px !important;
  }

  /* Modern Filter Toolbar */
  .roaster-toolbar-card {
    padding: 12px 14px !important;
    margin-bottom: 14px !important;
    border-radius: 12px !important;
  }
  .roaster-toolbar-inner {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
    width: 100% !important;
  }
  .roaster-filter-form {
    flex-direction: column !important;
    align-items: stretch !important;
    width: 100% !important;
    gap: 8px !important;
  }
  .roaster-search-box {
    width: 100% !important;
    max-width: 100% !important;
    min-width: 0 !important;
    box-sizing: border-box !important;
    height: 40px !important;
    padding: 8px 12px !important;
    border-radius: 9px !important;
  }
  .fee-filter-selects {
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .fee-filter-selects .roaster-select-box {
    width: 100% !important;
    min-width: 0 !important;
  }
  .fee-filter-selects .roaster-select-box select {
    width: 100% !important;
    min-width: 0 !important;
    height: 40px !important;
    font-size: 0.80rem !important;
    border-radius: 9px !important;
    padding: 8px 24px 8px 28px !important;
  }
  .fee-filter-actions {
    display: flex !important;
    width: 100% !important;
    gap: 8px !important;
  }
  .fee-filter-actions .roaster-btn.secondary {
    flex: 1 !important;
    height: 38px !important;
    font-size: 0.80rem !important;
    justify-content: center !important;
    border-radius: 9px !important;
  }
  .fee-filter-actions .roaster-btn.ghost {
    flex: 1 !important;
    height: 38px !important;
    font-size: 0.80rem !important;
    justify-content: center !important;
    border-radius: 9px !important;
  }
  .roaster-toolbar-actions {
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
    width: 100% !important;
    margin: 2px 0 0 0 !important;
  }
  .scholars-count-badge {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.78rem !important;
    padding: 0 10px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
  }
  .roaster-add-btn {
    width: 100% !important;
    height: 38px !important;
    justify-content: center !important;
    font-size: 0.80rem !important;
    padding: 0 12px !important;
    box-sizing: border-box !important;
    border-radius: 9px !important;
    white-space: nowrap !important;
    margin: 0 !important;
  }
  .roaster-add-btn .btn-icon-circle {
    width: 22px !important;
    height: 22px !important;
    font-size: 0.72rem !important;
  }

  /* Fee Ledger Card Header */
  .fee-ledger-card {
    border-radius: 12px !important;
    margin-bottom: 20px !important;
  }
  .fee-card-header {
    padding: 12px 14px !important;
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 10px !important;
  }
  .fee-title-block {
    width: 100% !important;
  }
  .fee-title-block .card-title {
    font-size: 0.95rem !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
  }
  .fee-title-block p {
    font-size: 0.74rem !important;
    line-height: 1.4 !important;
  }
  .fee-records-count {
    width: 100% !important;
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    padding-top: 8px !important;
    border-top: 1px dashed #e2e8f0 !important;
    font-size: 0.75rem !important;
  }

  /* Table & Scrolling */
  .table-responsive {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch !important;
    width: 100% !important;
    margin: 0 !important;
  }
  #feeLedgerTable {
    min-width: 1050px !important;
  }
  #feeLedgerTable thead th {
    padding: 9px 8px !important;
    font-size: 0.68rem !important;
  }
  #feeLedgerTable tbody td {
    padding: 9px 8px !important;
    font-size: 0.78rem !important;
  }
  #feeLedgerTable tbody td .user-cell {
    gap: 8px !important;
  }
  #feeLedgerTable tbody td .user-cell img {
    width: 34px !important;
    height: 34px !important;
  }
  #feeLedgerTable tbody td .user-cell > div:first-child {
    width: 34px !important;
    height: 34px !important;
    font-size: 13px !important;
  }
  .sid-btn-action {
    padding: 4px 8px !important;
    font-size: 0.70rem !important;
  }

  /* Pagination Controls */
  .pagination-controls-wrap {
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 12px !important;
    padding: 12px 14px !important;
  }
  .pagination-meta-group {
    flex-direction: column !important;
    align-items: flex-start !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .pagination-limit-box {
    width: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
  }
  .pagination-limit-select {
    padding: 4px 8px !important;
    font-size: 0.75rem !important;
    height: 30px !important;
  }
  .pagination-nav {
    display: flex !important;
    justify-content: center !important;
    width: 100% !important;
    margin: 2px 0 !important;
  }
  .pagination-btn {
    min-width: 32px !important;
    height: 32px !important;
    font-size: 0.74rem !important;
    padding: 0 4px !important;
  }
  .pagination-controls-wrap > div:last-child {
    margin-left: 0 !important;
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    font-size: 0.74rem !important;
    text-align: center !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
  }

  /* Collect Fee Modal Responsive */
  #collectFeeModal {
    padding: 10px !important;
  }
  #collectFeeModal .hrms-modal-card {
    width: 100% !important;
    max-width: min(540px, 96vw) !important;
    margin: auto !important;
    max-height: calc(100vh - 20px) !important;
    max-height: calc(100dvh - 20px) !important;
    border-radius: 16px !important;
    display: flex !important;
    flex-direction: column !important;
    overflow: hidden !important;
  }
  #collectFeeModal .hrms-modal-header {
    padding: 12px 16px !important;
    flex-shrink: 0 !important;
  }
  #collectFeeModal .hrms-modal-header h3 {
    font-size: 1.02rem !important;
  }
  #collectFeeModal .hrms-modal-body {
    padding: 14px 16px !important;
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
    flex: 1 !important;
    max-height: calc(100dvh - 100px) !important;
  }
  #collectFeeModal .hrms-modal-body div[style*="grid-template-columns"] {
    grid-template-columns: 1fr !important;
    gap: 10px !important;
  }
  .collect-modal-actions {
    display: flex !important;
    gap: 8px !important;
    width: 100% !important;
  }
  .collect-cancel-btn {
    flex: 1 !important;
    height: 40px !important;
    justify-content: center !important;
    font-size: 0.82rem !important;
  }
  .collect-submit-btn {
    flex: 2 !important;
    height: 40px !important;
    justify-content: center !important;
    font-size: 0.82rem !important;
  }

  /* Receipt Print Modal Responsive */
  #receiptPrintModal {
    padding: 10px !important;
  }
  #receiptPrintModal .receipt-modal-card {
    width: 100% !important;
    max-width: min(520px, 96vw) !important;
    margin: auto !important;
    max-height: calc(100vh - 20px) !important;
    max-height: calc(100dvh - 20px) !important;
    border-radius: 16px !important;
  }
  #receiptPrintModal .hrms-modal-header {
    padding: 12px 16px !important;
  }
  #receiptModalBody {
    max-height: calc(100dvh - 120px) !important;
  }
  #receiptPrintModal .receipt-modal-card > div.no-print:last-child {
    padding: 10px 14px !important;
    grid-template-columns: 1fr 1fr 1fr !important;
    gap: 6px !important;
  }
  #receiptPrintModal .receipt-modal-card > div.no-print:last-child button {
    padding: 8px 6px !important;
    font-size: 0.76rem !important;
    height: 38px !important;
  }
}

/* Mobile Phones (<= 480px) */
@media (max-width: 480px) {
  .stat-grid {
    gap: 8px !important;
  }
  .stat-card {
    padding: 8px 10px !important;
  }
  .stat-number {
    font-size: 1.15rem !important;
  }
  .stat-icon-wrapper {
    width: 26px !important;
    height: 26px !important;
    min-width: 26px !important;
    font-size: 0.72rem !important;
  }
  .fee-title-block .card-title {
    font-size: 0.90rem !important;
  }
  .pay-receipt {
    max-width: 100% !important;
    border-radius: 8px !important;
  }
  .pay-receipt .receipt-body {
    padding: 10px 12px !important;
  }
  .pay-receipt .ri-brand-row {
    gap: 10px !important;
  }
  .pay-receipt .ri-logo-box {
    width: 44px !important;
    height: 44px !important;
    min-width: 44px !important;
  }
  .pay-receipt .ri-title {
    font-size: 14px !important;
  }
}

/* Micro Devices (<= 360px) */
@media (max-width: 360px) {
  .fee-filter-selects {
    grid-template-columns: 1fr !important;
  }
  .roaster-toolbar-actions {
    grid-template-columns: 1fr !important;
  }
}

/* ══════════════════════════════════════════════════════════════════════
   DARK THEME COMPREHENSIVE ADAPTATIONS FOR FEE MANAGEMENT
   ══════════════════════════════════════════════════════════════════════ */

/* 1. Financial KPI Stat Metric Cards */
[data-theme="dark"] .stat-card {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .stat-label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .stat-number {
  color: #f8fafc !important;
}
[data-theme="dark"] .stat-card.amber .stat-number[style*="color: #dc2626"],
[data-theme="dark"] .stat-card.amber .stat-number[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .stat-card-progress {
  background: #334155 !important;
}
[data-theme="dark"] .stat-card-footer {
  border-top-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .stat-card-footer span strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .stat-card.green .stat-icon-wrapper {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border: 1px solid rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .stat-card.blue .stat-icon-wrapper {
  background: rgba(2, 132, 199, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] .stat-card.amber .stat-icon-wrapper {
  background: rgba(239, 68, 68, 0.15) !important;
  color: #f87171 !important;
  border: 1px solid rgba(239, 68, 68, 0.3) !important;
}
[data-theme="dark"] .stat-card.purple .stat-icon-wrapper {
  background: rgba(139, 92, 246, 0.15) !important;
  color: #a78bfa !important;
  border: 1px solid rgba(139, 92, 246, 0.3) !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #059669"],
[data-theme="dark"] .stat-card-footer span[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #0284c7"],
[data-theme="dark"] .stat-card-footer span[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #dc2626"],
[data-theme="dark"] .stat-card-footer span[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .stat-card-footer span[style*="color: #9333ea"],
[data-theme="dark"] .stat-card-footer span[style*="color:#9333ea"] {
  color: #c084fc !important;
}

/* 2. Enhanced Filter Toolbar */
[data-theme="dark"] .roaster-toolbar-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .roaster-search-box {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
}
[data-theme="dark"] .roaster-search-box:focus-within {
  background: #0f172a !important;
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-search-box i {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-search-box input {
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-search-box input::placeholder {
  color: #64748b !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn {
  background: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-search-box .clear-search-btn:hover {
  background: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-select-box > i:first-child,
[data-theme="dark"] .roaster-select-box .select-chevron {
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-select-box select {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-select-box select:focus {
  background: #0f172a !important;
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .roaster-select-box select option,
[data-theme="dark"] .roaster-select-box select optgroup {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .roaster-btn.secondary {
  background: #334155 !important;
  color: #f1f5f9 !important;
  border: 1px solid #475569 !important;
  border-radius: 8px !important;
}
[data-theme="dark"] .roaster-btn.secondary:hover {
  background: #475569 !important;
  color: #ffffff !important;
}
[data-theme="dark"] .roaster-btn.ghost {
  background: rgba(255, 255, 255, 0.05) !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .roaster-btn.ghost:hover {
  background: rgba(239, 68, 68, 0.15) !important;
  border-color: rgba(239, 68, 68, 0.35) !important;
  color: #f87171 !important;
}
[data-theme="dark"] .scholars-count-badge {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .scholars-count-badge strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .scholars-count-badge .count-dot {
  background: #10b981 !important;
  box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2) !important;
}

/* 3. Fee Ledger Card & Header */
[data-theme="dark"] .fee-ledger-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .fee-card-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .fee-title-block .card-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .fee-title-block .card-title i[style*="color: #0284c7"],
[data-theme="dark"] .fee-title-block .card-title i[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .fee-session-badge {
  background: #0f172a !important;
  color: #cbd5e1 !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .fee-title-block p {
  color: #94a3b8 !important;
}
[data-theme="dark"] .fee-records-count {
  border-top-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .fee-records-count strong {
  color: #f8fafc !important;
}

/* 4. Table Header, Rows & Cells */
[data-theme="dark"] #feeLedgerTable thead th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td {
  border-bottom: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] #feeLedgerTable tbody tr:hover {
  background-color: rgba(51, 65, 85, 0.3) !important;
}

/* Empty State Table Cell */
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] div[style*="background: #f1f5f9"],
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] div[style*="background:#f1f5f9"] {
  background: #334155 !important;
  color: #94a3b8 !important;
  border: 1px solid #475569 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] h4 {
  color: #f8fafc !important;
}
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] p {
  color: #94a3b8 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] p strong {
  color: #f8fafc !important;
}
[data-theme="dark"] #feeLedgerTable tbody td[colspan="9"] .roaster-btn.secondary {
  background: #334155 !important;
  color: #f1f5f9 !important;
  border: 1px solid #475569 !important;
  border-radius: 8px !important;
}

/* Student Profile Cell & Initial Circle */
[data-theme="dark"] #feeLedgerTable tbody td .user-cell > div > div:first-child {
  color: #f8fafc !important;
}
[data-theme="dark"] #feeLedgerTable tbody td .user-cell > div > div:last-child {
  color: #94a3b8 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td .user-cell img {
  border-color: #334155 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td .user-cell > div[style*="background: #f1f5f9"],
[data-theme="dark"] #feeLedgerTable tbody td .user-cell > div[style*="background:#f1f5f9"],
[data-theme="dark"] #feeLedgerTable tbody td .user-cell div[style*="background: #f1f5f9"],
[data-theme="dark"] #feeLedgerTable tbody td .user-cell div[style*="background:#f1f5f9"] {
  background: #334155 !important;
  color: #f8fafc !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .sid-blood-badge {
  background: rgba(225, 29, 72, 0.15) !important;
  border: 1px solid rgba(225, 29, 72, 0.35) !important;
  color: #fb7185 !important;
}

/* Badges & Indicators */
[data-theme="dark"] .sid-receipt-pill {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-roll-pill {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color: #64748b"],
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color:#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .sid-std-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-std-pill i {
  color: #94a3b8 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color: #94a3b8"],
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color:#94a3b8"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .sid-feehead-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-feehead-pill i {
  color: #38bdf8 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color: #059669"],
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color: #dc2626"],
[data-theme="dark"] #feeLedgerTable tbody td div[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .sid-mode-pill {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .sid-mode-pill.cash {
  background: rgba(22, 101, 52, 0.15) !important;
  border-color: rgba(22, 101, 52, 0.35) !important;
  color: #4ade80 !important;
}
[data-theme="dark"] .sid-mode-pill.upi {
  background: rgba(2, 132, 199, 0.15) !important;
  border-color: rgba(2, 132, 199, 0.35) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-mode-pill.netbanking,
[data-theme="dark"] .sid-mode-pill.bank {
  background: rgba(124, 58, 237, 0.15) !important;
  border-color: rgba(124, 58, 237, 0.35) !important;
  color: #a78bfa !important;
}
[data-theme="dark"] .sid-mode-pill.cheque {
  background: rgba(180, 83, 9, 0.15) !important;
  border-color: rgba(180, 83, 9, 0.35) !important;
  color: #fbbf24 !important;
}
[data-theme="dark"] .sid-mode-pill.creditcard {
  background: rgba(217, 70, 239, 0.15) !important;
  border-color: rgba(217, 70, 239, 0.35) !important;
  color: #e879f9 !important;
}
[data-theme="dark"] #feeLedgerTable tbody td span[style*="color: #64748b"],
[data-theme="dark"] #feeLedgerTable tbody td span[style*="color:#64748b"] {
  color: #94a3b8 !important;
}

/* Action Buttons in Ledger Row */
[data-theme="dark"] .sid-btn-action {
  border-radius: 6px !important;
}
[data-theme="dark"] .sid-btn-primary {
  background: rgba(2, 132, 199, 0.15) !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .sid-btn-primary:hover {
  background: #0284c7 !important;
  color: #ffffff !important;
  border-color: #0284c7 !important;
}
[data-theme="dark"] .sid-btn-primary:hover i {
  color: #ffffff !important;
}
[data-theme="dark"] .sid-btn-secondary {
  background: rgba(22, 101, 52, 0.15) !important;
  border: 1px solid rgba(22, 101, 52, 0.3) !important;
  color: #4ade80 !important;
}
[data-theme="dark"] .sid-btn-secondary:hover {
  background: #16a34a !important;
  color: #ffffff !important;
  border-color: #16a34a !important;
}
[data-theme="dark"] .sid-btn-secondary i[style*="color: #059669"],
[data-theme="dark"] .sid-btn-secondary i[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .sid-btn-secondary:hover i {
  color: #ffffff !important;
}

/* 5. Pagination Controls */
[data-theme="dark"] .pagination-controls-wrap {
  background: #1e293b !important;
  border-top: 1px solid #334155 !important;
}
[data-theme="dark"] .pagination-meta-group span {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-meta-group span strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-limit-box label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-limit-select {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-limit-select:focus {
  border-color: var(--hrms-primary, #0092df) !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .pagination-limit-select option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 6px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .pagination-btn:hover:not(.disabled) {
  background: #334155 !important;
  color: #f8fafc !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .pagination-btn.active {
  background: var(--hrms-primary, #0092df) !important;
  border-color: var(--hrms-primary, #0092df) !important;
  color: #ffffff !important;
}
[data-theme="dark"] .pagination-btn.disabled {
  background: #0f172a !important;
  border-color: #1e293b !important;
  color: #475569 !important;
  opacity: 0.5 !important;
  cursor: not-allowed !important;
}
[data-theme="dark"] .pagination-ellipsis {
  color: #64748b !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong[style*="color: #059669"],
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong[style*="color: #334155"],
[data-theme="dark"] .pagination-controls-wrap > div:last-child strong[style*="color:#334155"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-controls-wrap > div:last-child span[style*="color: #cbd5e1"],
[data-theme="dark"] .pagination-controls-wrap > div:last-child span[style*="color:#cbd5e1"] {
  color: #475569 !important;
}

/* 6. Collect Fee Modal (#collectFeeModal) */
#collectFeeModal {
  align-items: center;
  justify-content: center;
  padding: 16px;
}
#collectFeeModal .hrms-modal-card {
  width: 100%;
  max-width: 580px;
  max-height: calc(100vh - 32px);
  max-height: calc(100dvh - 32px);
  display: flex !important;
  flex-direction: column !important;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 25px 60px -15px rgba(15, 23, 42, 0.4);
  background: #ffffff;
  margin: auto;
}
#collectFeeModal .hrms-modal-header {
  flex-shrink: 0;
  padding: 16px 22px;
  background: #ffffff;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
#collectFeeModal form {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  margin: 0;
  overflow: hidden;
}
#collectFeeModal .hrms-modal-body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 18px 22px;
  -webkit-overflow-scrolling: touch;
}
#collectFeeModal .collect-modal-actions {
  flex-shrink: 0;
  padding: 14px 22px;
  background: #f8fafc;
  border-top: 1px solid #e2e8f0;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.due-banner {
  margin-top: 8px;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 0.78rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all 0.2s ease;
}
.due-banner.is-due {
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #991b1b;
}
.due-banner.is-due strong {
  font-size: 0.9rem;
  font-family: 'Outfit', sans-serif;
  color: #991b1b;
}
.due-banner.is-cleared {
  background: #ecfdf5;
  border: 1px solid #a7f3d0;
  color: #065f46;
}
.due-banner.is-cleared strong {
  font-size: 0.88rem;
  font-family: 'Outfit', sans-serif;
  color: #059669;
}

/* Installments Schedule Cards in Collect Fee Modal */
.inst-card {
  padding: 10px 14px;
  border-radius: 10px;
  border: 1.5px solid #e2e8f0;
  background: #f8fafc;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  transition: all 0.2s ease;
  user-select: none;
}
.inst-card:hover {
  border-color: #0284c7;
  background: #ffffff;
  box-shadow: 0 3px 10px rgba(2, 132, 199, 0.08);
}
.inst-card.selected {
  border-color: #0284c7;
  background: #f0f9ff;
  box-shadow: 0 0 0 2px rgba(2, 132, 199, 0.25);
}
.inst-card.is-paid {
  border-color: #d1fae5;
  background: #f0fdf4;
  cursor: default;
  opacity: 0.9;
}
.inst-badge {
  font-size: 0.68rem;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  text-transform: uppercase;
  letter-spacing: 0.03em;
}
.inst-badge.paid {
  background: #dcfce7;
  color: #15803d;
  border: 1px solid #bbf7d0;
}
.inst-badge.overdue {
  background: #fee2e2;
  color: #b91c1c;
  border: 1px solid #fecaca;
}
.inst-badge.due-soon {
  background: #fef3c7;
  color: #b45309;
  border: 1px solid #fde68a;
}
.inst-badge.pending {
  background: #f1f5f9;
  color: #475569;
  border: 1px solid #e2e8f0;
}
.inst-chip {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 20px;
  padding: 4px 10px;
  font-size: 0.74rem;
  font-weight: 600;
  color: #334155;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: all 0.15s ease;
}
.inst-chip:hover {
  border-color: #0284c7;
  color: #0284c7;
  background: #f0f9ff;
}
.inst-chip.active {
  background: #0284c7;
  color: #ffffff;
  border-color: #0284c7;
}

[data-theme="dark"] .inst-card {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .inst-card:hover {
  background: #1e293b !important;
  border-color: #38bdf8 !important;
}
[data-theme="dark"] .inst-card.selected {
  background: rgba(2, 132, 199, 0.15) !important;
  border-color: #38bdf8 !important;
}
[data-theme="dark"] .inst-card.is-paid {
  background: rgba(16, 185, 129, 0.1) !important;
  border-color: rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .inst-badge.paid {
  background: rgba(16, 185, 129, 0.2) !important;
  color: #4ade80 !important;
  border-color: rgba(16, 185, 129, 0.4) !important;
}
[data-theme="dark"] .inst-badge.overdue {
  background: rgba(239, 68, 68, 0.2) !important;
  color: #f87171 !important;
  border-color: rgba(239, 68, 68, 0.4) !important;
}
[data-theme="dark"] .inst-badge.due-soon {
  background: rgba(245, 158, 11, 0.2) !important;
  color: #fbbf24 !important;
  border-color: rgba(245, 158, 11, 0.4) !important;
}
[data-theme="dark"] .inst-badge.pending {
  background: #334155 !important;
  color: #cbd5e1 !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .inst-chip {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .inst-chip:hover {
  background: #1e293b !important;
  border-color: #38bdf8 !important;
  color: #38bdf8 !important;
}
[data-theme="dark"] .inst-chip.active {
  background: #0284c7 !important;
  color: #ffffff !important;
}

[data-theme="dark"] #collectFeeModal .hrms-modal-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 18px !important;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7) !important;
}
[data-theme="dark"] #collectFeeModal .hrms-modal-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #collectFeeModal .hrms-modal-header > div > div:first-child {
  background: rgba(2, 132, 199, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] #collectFeeModal .hrms-modal-header h3 {
  color: #f8fafc !important;
}
[data-theme="dark"] #collectFeeModal .hrms-modal-header p {
  color: #94a3b8 !important;
}
[data-theme="dark"] #collectFeeModal .modal-close-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #cbd5e1 !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #collectFeeModal .modal-close-btn:hover {
  background: #334155 !important;
  color: #f8fafc !important;
  border-color: #475569 !important;
}
[data-theme="dark"] #collectFeeModal .hrms-modal-body {
  background: #1e293b !important;
}
[data-theme="dark"] #collectFeeModal label.form-label {
  color: #e2e8f0 !important;
}
[data-theme="dark"] #collectFeeModal label.form-label span[style*="color: #dc2626"],
[data-theme="dark"] #collectFeeModal label.form-label span[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] #collectFeeModal input.hrms-input,
[data-theme="dark"] #collectFeeModal select.hrms-input {
  background: #0f172a !important;
  color: #f8fafc !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
}
[data-theme="dark"] #collectFeeModal input[type="date"] {
  color-scheme: dark !important;
}
[data-theme="dark"] #collectFeeModal input.hrms-input:focus,
[data-theme="dark"] #collectFeeModal select.hrms-input:focus {
  background: #18263e !important;
  border-color: var(--hrms-primary, #0092df) !important;
  color: #ffffff !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] #collectFeeModal input::placeholder {
  color: #64748b !important;
}
[data-theme="dark"] #collectFeeModal select.hrms-input option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #collectFeeModal #collectAmountInput {
  background: #0f172a !important;
  color: #34d399 !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
}
[data-theme="dark"] #collectFeeModal #collectAmountInput:focus {
  background: #18263e !important;
  border-color: #10b981 !important;
  box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2) !important;
}
[data-theme="dark"] #collectFeeModal #collectAmountInput::placeholder {
  color: #475569 !important;
}
[data-theme="dark"] #collectFeeModal span[style*="color: #059669"],
[data-theme="dark"] #collectFeeModal span[style*="color:#059669"] {
  color: #34d399 !important;
}
[data-theme="dark"] input[type="date"]::-webkit-calendar-picker-indicator,
[data-theme="dark"] #collectFeeModal input[type="date"]::-webkit-calendar-picker-indicator {
  filter: invert(1) brightness(0.9);
  cursor: pointer;
  opacity: 0.9;
  transition: opacity 0.2s ease;
}
[data-theme="dark"] input[type="date"]::-webkit-calendar-picker-indicator:hover,
[data-theme="dark"] #collectFeeModal input[type="date"]::-webkit-calendar-picker-indicator:hover {
  opacity: 1;
}
[data-theme="dark"] .due-banner.is-due,
[data-theme="dark"] #studentDueBanner.is-due,
[data-theme="dark"] #studentDueBanner {
  background: rgba(239, 68, 68, 0.14) !important;
  border: 1px solid rgba(239, 68, 68, 0.35) !important;
  border-radius: 8px !important;
  color: #f87171 !important;
}
[data-theme="dark"] .due-banner.is-due strong,
[data-theme="dark"] #studentDueBanner.is-due #bannerDueAmount,
[data-theme="dark"] #studentDueBanner #bannerDueAmount {
  color: #fca5a5 !important;
}
[data-theme="dark"] .due-banner.is-cleared,
[data-theme="dark"] #studentDueBanner.is-cleared {
  background: rgba(16, 185, 129, 0.14) !important;
  border: 1px solid rgba(16, 185, 129, 0.35) !important;
  border-radius: 8px !important;
  color: #34d399 !important;
}
[data-theme="dark"] .due-banner.is-cleared strong,
[data-theme="dark"] #studentDueBanner.is-cleared #bannerDueAmount {
  color: #6ee7b7 !important;
}
[data-theme="dark"] #collectFeeModal .collect-modal-actions {
  background: #1e293b !important;
  border-top: 1px solid #334155 !important;
}
[data-theme="dark"] #collectFeeModal .collect-cancel-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #cbd5e1 !important;
  font-weight: 600 !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #collectFeeModal .collect-cancel-btn:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #collectFeeModal .collect-submit-btn {
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
  border: none !important;
  border-radius: 8px !important;
  color: #ffffff !important;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35) !important;
  transition: all 0.2s ease !important;
}
[data-theme="dark"] #collectFeeModal .collect-submit-btn:hover {
  background: linear-gradient(135deg, #0369a1 0%, #075985 100%) !important;
  box-shadow: 0 6px 20px rgba(2, 132, 199, 0.5) !important;
  transform: translateY(-1px);
}

/* 7. Official Receipt Modal (#receiptPrintModal) */
[data-theme="dark"] #receiptPrintModal .receipt-modal-card {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
  border-radius: 20px !important;
}
[data-theme="dark"] #receiptPrintModal .hrms-modal-header {
  background: #1e293b !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] #receiptPrintModal .hrms-modal-header > div > div:first-child {
  background: rgba(2, 132, 199, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] #receiptPrintModal .hrms-modal-header h4 {
  color: #f8fafc !important;
}
[data-theme="dark"] #receiptPrintModal #modalReceiptSub {
  color: #94a3b8 !important;
}
[data-theme="dark"] #receiptPrintModal .modal-close-btn {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] #receiptPrintModal .modal-close-btn:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #receiptModalBody {
  background: #0f172a !important;
  scrollbar-color: #0284c7 #1e293b !important;
}
[data-theme="dark"] #receiptModalBody::-webkit-scrollbar-track {
  background: #0f172a !important;
  border-left-color: #334155 !important;
}
[data-theme="dark"] #receiptModalBody::-webkit-scrollbar-thumb {
  background: #0284c7 !important;
  border-color: #0f172a !important;
}
[data-theme="dark"] #receiptPrintModal .receipt-modal-card > div.no-print:last-child {
  background: #1e293b !important;
  border-top: 1px solid #334155 !important;
}
[data-theme="dark"] #receiptPrintModal .btn-hrms-outline {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
  border-radius: 8px !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] #receiptPrintModal .btn-hrms-outline:hover {
  background: #334155 !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] #receiptPrintModal #btn_download_receipt,
[data-theme="dark"] #receiptPrintModal #btn_share_receipt {
  border-radius: 8px !important;
}

/* ── Dark Theme for Pay Receipt Card (Screen View inside Receipt Modal) ── */
[data-theme="dark"] .pay-receipt {
  background: #0f172a !important;
  border: 1.5px solid #334155 !important;
  color: #f8fafc !important;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5) !important;
}
[data-theme="dark"] .pay-receipt .ri-brand-row {
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .pay-receipt .ri-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .ri-sub {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .ri-address {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt .ri-logo-box {
  background: #1e293b !important;
  border-color: #334155 !important;
}

/* Document Type & Session Banner */
[data-theme="dark"] .pay-receipt .receipt-doc-band {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .pay-receipt .receipt-doc-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-doc-title i {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .receipt-doc-session {
  background: rgba(2, 132, 199, 0.2) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}

/* Student & Voucher Meta Grid */
[data-theme="dark"] .pay-receipt .receipt-meta-grid {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .pay-receipt .rmg-label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt .rmg-val {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .rmg-val.bold {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .rmg-val.mono-badge {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .rmg-val[style*="color: #0f172a"],
[data-theme="dark"] .pay-receipt .rmg-val[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .rmg-val[style*="color: #0284c7"],
[data-theme="dark"] .pay-receipt .rmg-val[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}

/* Particulars Table */
[data-theme="dark"] .pay-receipt .receipt-table-wrapper {
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .pay-receipt .receipt-table th {
  background: #1e293b !important;
  color: #94a3b8 !important;
  border-bottom: 1px solid #334155 !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td {
  border-bottom: 1px solid #1e293b !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .pay-receipt .receipt-table tr[style*="background: #f0f9ff"],
[data-theme="dark"] .pay-receipt .receipt-table tr[style*="background:#f0f9ff"] {
  background: rgba(2, 132, 199, 0.15) !important;
}
[data-theme="dark"] .pay-receipt .receipt-table tr[style*="background: #f0f9ff"] td,
[data-theme="dark"] .pay-receipt .receipt-table tr[style*="background:#f0f9ff"] td {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="color: #0f172a"],
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="background: #e0f2fe"],
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="background:#e0f2fe"] {
  background: rgba(2, 132, 199, 0.2) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="color: #0284c7"],
[data-theme="dark"] .pay-receipt .receipt-table td span[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td[style*="color: #0f172a"],
[data-theme="dark"] .pay-receipt .receipt-table td[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td div[style*="color: #64748b"],
[data-theme="dark"] .pay-receipt .receipt-table td div[style*="color:#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt .receipt-table td div[style*="color: #0284c7"],
[data-theme="dark"] .pay-receipt .receipt-table td div[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}

/* Table Total Row (fixes washed-out white bar) */
[data-theme="dark"] .pay-receipt .receipt-table tr.total-row td {
  background: #1e293b !important;
  border-top: 1.5px solid #334155 !important;
  border-bottom: none !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-table tr.total-row td[style*="color: #0f172a"],
[data-theme="dark"] .pay-receipt .receipt-table tr.total-row td[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .receipt-table tr.total-row td:last-child {
  color: #34d399 !important;
}

/* Course Fee & Due Balance Strip (fixes white rectangle) */
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"],
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] {
  background: #1e293b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] span[style*="color: #64748b"],
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] span[style*="color:#64748b"],
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] span,
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] span {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] strong,
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] strong[style*="color: #0f172a"],
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] strong[style*="color:#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] strong[style*="color: #dc2626"],
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] strong[style*="color:#dc2626"] {
  color: #f87171 !important;
}
[data-theme="dark"] .pay-receipt div[style*="background: #f8fafc"] strong[style*="color: #059669"],
[data-theme="dark"] .pay-receipt div[style*="background:#f8fafc"] strong[style*="color:#059669"] {
  color: #34d399 !important;
}

/* Words Box */
[data-theme="dark"] .pay-receipt .receipt-words-box {
  background: rgba(16, 185, 129, 0.1) !important;
  border: 1px dashed rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .pay-receipt .receipt-words-box .words-label {
  color: #34d399 !important;
}
[data-theme="dark"] .pay-receipt .receipt-words-box .words-val,
[data-theme="dark"] .pay-receipt .words-val {
  color: #a7f3d0 !important;
}

/* Signatures & Seal Section */
[data-theme="dark"] .pay-receipt .auth-sign-line {
  border-bottom: 1.5px dashed #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pay-receipt .auth-sign-line[style*="color: #0284c7"],
[data-theme="dark"] .pay-receipt .auth-sign-line[style*="color:#0284c7"] {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .auth-sign-label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt .auth-seal-badge {
  border-color: #38bdf8 !important;
  background: rgba(56, 189, 248, 0.08) !important;
}
[data-theme="dark"] .pay-receipt .seal-text-top {
  color: #38bdf8 !important;
}
[data-theme="dark"] .pay-receipt .seal-text-mid {
  color: #34d399 !important;
}
[data-theme="dark"] .pay-receipt .seal-text-bot {
  color: #38bdf8 !important;
}

/* Security QR & Terms Bottom Bar */
[data-theme="dark"] .pay-receipt .receipt-bottom-bar {
  border-top-color: #334155 !important;
}
[data-theme="dark"] .pay-receipt .rb-qr-wrap {
  background: #ffffff !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .pay-receipt .rb-notes {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pay-receipt .rb-notes strong {
  color: #f8fafc !important;
}

</style>

<!-- Financial KPI Stat Metric Cards -->
<div class="stat-grid" style="margin-bottom: 24px;">

  <!-- Total Collected -->
  <div class="stat-card green">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Total Collected</span>
          <span class="stat-number"><?php echo format_inr($total_collected); ?></span>
        </div>
        <div class="stat-icon-wrapper">
          <i class="fa-solid fa-indian-rupee-sign"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: <?php echo min(100, $collection_rate); ?>%;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span><strong><?php echo $collection_rate; ?>%</strong> Collection Realized</span>
      <span style="color: #059669; font-weight: 700;"><i class="fa-solid fa-arrow-trend-up"></i> In Vault</span>
    </div>
  </div>

  <!-- Total Receivable Demand -->
  <div class="stat-card blue">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Total Receivable</span>
          <span class="stat-number"><?php echo format_inr($total_receivable); ?></span>
        </div>
        <div class="stat-icon-wrapper">
          <i class="fa-solid fa-file-invoice"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span>Annual Enrolled Fee Demand</span>
      <span style="color: #0284c7; font-weight: 700;"><i class="fa-solid fa-building-columns"></i> Session <?php echo htmlspecialchars($current_session_name); ?></span>
    </div>
  </div>

  <!-- Outstanding Dues -->
  <div class="stat-card amber">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Outstanding Dues</span>
          <span class="stat-number" style="color: #dc2626;"><?php echo format_inr($total_dues); ?></span>
        </div>
        <div class="stat-icon-wrapper" style="background: rgba(220, 38, 38, 0.1); color: #dc2626;">
          <i class="fa-solid fa-hourglass-half"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: <?php echo min(100, $dues_rate); ?>%; background: #dc2626;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span><strong><?php echo $dues_rate; ?>%</strong> Pending Collection</span>
      <span style="color: #dc2626; font-weight: 700;">Reminders Due</span>
    </div>
  </div>

  <!-- Receipts Issued -->
  <div class="stat-card purple">
    <div>
      <div class="stat-card-top">
        <div class="stat-info">
          <span class="stat-label">Receipts Issued</span>
          <span class="stat-number"><?php echo $receipts_count; ?></span>
        </div>
        <div class="stat-icon-wrapper">
          <i class="fa-solid fa-receipt"></i>
        </div>
      </div>
      <div class="stat-card-progress">
        <div class="stat-card-progress-bar" style="width: 100%;"></div>
      </div>
    </div>
    <div class="stat-card-footer">
      <span>Verified Ledger Transactions</span>
      <span style="color: #9333ea; font-weight: 700;"><i class="fa-solid fa-circle-check"></i> Audit Ready</span>
    </div>
  </div>

</div>

<!-- ══════════════════════════════════════════════════════
     UPCOMING FEE INSTALLMENTS & DUE DATE REMINDERS
     ══════════════════════════════════════════════════════ -->
<?php
  $upcoming_reminders = get_upcoming_fee_reminders($session_id, 10);
?>
<?php if (!empty($upcoming_reminders)): ?>
  <div class="fee-reminders-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 20px; margin-bottom: 22px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.03);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 34px; height: 34px; border-radius: 8px; background: #fef2f2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 1rem;">
          <i class="fa-solid fa-bell"></i>
        </div>
        <div>
          <h4 style="margin: 0; font-size: 0.98rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
            Installment Due Reminders &amp; Upcoming Deadlines
          </h4>
          <span style="font-size: 0.74rem; color: #64748b;">
            Scholars with overdue installments or scheduled fee milestones due within next 10 days
          </span>
        </div>
      </div>
      <span style="font-size: 0.74rem; font-weight: 700; background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; padding: 3px 10px; border-radius: 12px;">
        <?php echo count($upcoming_reminders); ?> Actionable Reminders
      </span>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 12px;">
      <?php foreach ($upcoming_reminders as $rem): ?>
        <?php
          $rem_due_amt = floatval($rem['amount']) - floatval($rem['paid_amount']);
          $is_od = !empty($rem['is_overdue']);
        ?>
        <div style="background: <?php echo $is_od ? '#fef2f2' : '#fffbeb'; ?>; border: 1px solid <?php echo $is_od ? '#fecaca' : '#fde68a'; ?>; border-radius: 10px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
          <div>
            <div style="font-weight: 800; font-size: 0.88rem; color: #0f172a; font-family: 'Outfit', sans-serif;">
              <?php echo htmlspecialchars($rem['student_name']); ?>
              <span style="font-size: 0.72rem; color: #64748b; font-weight: 600;">(<?php echo htmlspecialchars($rem['roll_no']); ?>)</span>
            </div>
            <div style="font-size: 0.75rem; color: #475569; margin: 3px 0;">
              <?php echo htmlspecialchars($rem['title']); ?> • <strong style="color: <?php echo $is_od ? '#dc2626' : '#d97706'; ?>;"><?php echo format_inr($rem_due_amt); ?></strong>
            </div>
            <div style="font-size: 0.72rem; color: <?php echo $is_od ? '#b91c1c' : '#92400e'; ?>; font-weight: 700;">
              <?php if ($is_od): ?>
                <i class="fa-solid fa-triangle-exclamation"></i> Overdue since <?php echo htmlspecialchars($rem['due_date_formatted']); ?> (<?php echo intval($rem['days_overdue']); ?>d ago)
              <?php else: ?>
                <i class="fa-regular fa-clock"></i> Due on <?php echo htmlspecialchars($rem['due_date_formatted']); ?> (In <?php echo intval($rem['days_remaining']); ?>d)
              <?php endif; ?>
            </div>
          </div>
          <div>
            <button type="button" class="roaster-btn primary" onclick="event.stopPropagation(); quickCollectFee(<?php echo intval($rem['student_id']); ?>, <?php echo floatval($rem_due_amt); ?>, <?php echo htmlspecialchars(json_encode($rem['title']), ENT_QUOTES, 'UTF-8'); ?>)" style="padding: 6px 11px; font-size: 0.76rem; white-space: nowrap;">
              <i class="fa-solid fa-hand-holding-dollar"></i> Collect
            </button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<!-- Modern Enhanced Filter Toolbar & Collect Fee Button (Like student.php) -->
<div class="roaster-toolbar-card" style="padding: 12px 18px;">
  <div class="roaster-toolbar-inner" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
    
    <!-- Filter form -->
    <form method="GET" action="<?php echo htmlspecialchars(ADMIN_URL . '/fees', ENT_QUOTES, 'UTF-8'); ?>" class="roaster-filter-form" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; flex: 1;">
      <input type="hidden" name="limit" value="<?php echo intval($limit); ?>">
      <?php if ($filter_student_id > 0): ?>
        <input type="hidden" name="student_id" value="<?php echo intval($filter_student_id); ?>">
      <?php endif; ?>

      <div class="roaster-search-box" style="min-width: 200px; max-width: 250px; padding: 7px 12px;">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="search" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search name, receipt, roll..." autocomplete="off" maxlength="100">
        <?php if (!empty($search)): ?>
          <a href="<?php echo htmlspecialchars(get_fee_pagination_url(1, '', $filter_standard, $filter_method, $filter_student_id, $limit)); ?>" class="clear-search-btn" title="Clear search">&times;</a>
        <?php endif; ?>
      </div>

      <div class="fee-filter-selects" style="display: flex; gap: 8px; align-items: center;">
        <div class="roaster-select-box">
          <i class="fa-solid fa-school"></i>
          <select name="standard" onchange="this.form.submit()" style="min-width: 175px; max-width: 250px; padding: 7px 28px 7px 30px; font-size: 0.82rem; font-weight: 600; text-overflow: ellipsis;">
            <option value="">All Standards</option>
            <?php echo render_standards_dropdown_options($filter_standard, false, $academic_categories, $custom_db_standards); ?>
          </select>
          <i class="fa-solid fa-chevron-down select-chevron" style="right: 10px;"></i>
        </div>

        <div class="roaster-select-box">
          <i class="fa-solid fa-wallet"></i>
          <select name="method" onchange="this.form.submit()" style="min-width: 145px; padding: 7px 28px 7px 30px; font-size: 0.82rem;">
            <option value="">All Modes</option>
            <option value="Cash" <?php echo $filter_method === 'Cash' ? 'selected' : ''; ?>>Cash</option>
            <option value="UPI" <?php echo $filter_method === 'UPI' ? 'selected' : ''; ?>>UPI / QR</option>
            <option value="Net Banking" <?php echo $filter_method === 'Net Banking' ? 'selected' : ''; ?>>Net Banking</option>
            <option value="Cheque" <?php echo $filter_method === 'Cheque' ? 'selected' : ''; ?>>Cheque</option>
            <option value="Credit Card" <?php echo $filter_method === 'Credit Card' ? 'selected' : ''; ?>>Credit Card</option>
          </select>
          <i class="fa-solid fa-chevron-down select-chevron" style="right: 10px;"></i>
        </div>
      </div>

      <div class="fee-filter-actions" style="display: flex; gap: 8px; align-items: center;">
        <button type="submit" class="roaster-btn secondary" style="padding: 7px 14px; font-size: 0.82rem;">
          <i class="fa-solid fa-sliders"></i> Filter
        </button>

        <?php if (!empty($search) || !empty($filter_standard) || !empty($filter_method) || $filter_student_id > 0): ?>
          <a href="<?php echo htmlspecialchars(ADMIN_URL . '/fees' . ($limit !== 10 ? '?limit=' . $limit : ''), ENT_QUOTES, 'UTF-8'); ?>" class="roaster-btn ghost" style="padding: 7px 12px; font-size: 0.82rem;" title="Reset all filters">
            <i class="fa-solid fa-rotate-left"></i> Reset
          </a>
        <?php endif; ?>
      </div>
    </form>

    <!-- Right: Receipts Live Count & Collect Fee Button -->
    <div class="roaster-toolbar-actions" style="display: flex; align-items: center; gap: 10px; margin-left: auto;">
      <div class="scholars-count-badge" style="padding: 6px 12px; font-size: 0.8rem;">
        <span class="count-dot"></span>
        <span><strong><?php echo $total_records; ?></strong> Receipts</span>
      </div>

      <?php if ($current_user['role'] === 'super_admin'): ?>
        <button type="button" class="roaster-add-btn" onclick="event.stopPropagation(); openCollectModal()" style="padding: 7px 16px; font-size: 0.82rem;">
          <div class="btn-icon-circle" style="width: 22px; height: 22px; font-size: 0.72rem;"><i class="fa-solid fa-plus"></i></div>
          <span>Collect Fee</span>
        </button>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Main Fee Payment Ledger Card (Simple & Sober - Like student-id) -->
<div class="hrms-card fee-ledger-card" style="margin-bottom: 24px; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); background: #ffffff; overflow: hidden;">

  <!-- Card Header -->
  <div class="hrms-card-header no-print fee-card-header" style="border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 16px 20px;">
    <div class="fee-title-block">
      <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 1rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif;">
        <i class="fa-solid fa-file-invoice-dollar" style="color: #0284c7;"></i>
        Fee Payment Ledger &amp; Receipts
        <span class="fee-session-badge" style="font-size: 0.74rem; font-weight: 600; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 6px;">
          Session <?php echo htmlspecialchars($current_session_name); ?>
        </span>
      </h3>
      <p style="margin: 3px 0 0; font-size: 0.78rem; color: #64748b;">
        Verified student fee vouchers, ledger transactions &amp; official receipt generation.
      </p>
    </div>
    <div class="fee-records-count" style="font-size: 0.78rem; color: #64748b; font-weight: 600;">
      <span>Total Records: <strong style="color: #0f172a;"><?php echo $total_records; ?></strong></span>
    </div>
  </div>

  <!-- Fee Transactions Table -->
  <div class="table-responsive">
    <table class="hrms-table staff-id-table student-id-table" id="feeLedgerTable">
      <thead>
        <tr>
          <th style="min-width: 120px;">Receipt No</th>
          <th style="min-width: 170px;">Student Profile</th>
          <th style="min-width: 110px;">Roll &amp; Admission</th>
          <th style="min-width: 130px;">Standard &amp; Section</th>
          <th style="min-width: 115px;">Fee Head</th>
          <th style="min-width: 115px;">Amount Paid</th>
          <th style="min-width: 110px;">Payment Mode</th>
          <th style="min-width: 100px;">Date</th>
          <th style="min-width: 135px; text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payments)): ?>
          <tr>
            <td colspan="9" style="text-align: center; padding: 50px 20px; color: #64748b;">
              <div style="width: 52px; height: 52px; border-radius: 50%; background: #f1f5f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; font-size: 1.4rem; color: #94a3b8;">
                <i class="fa-solid fa-receipt"></i>
              </div>
              <h4 style="font-size: 1rem; font-weight: 800; color: #0f172a; margin-bottom: 4px; font-family: 'Outfit', sans-serif;">No Fee Transactions Recorded</h4>
              <p style="font-size: 0.82rem; color: #64748b; margin: 0 0 14px;">
                No fee collection receipts match the selected filters in Session <strong><?php echo htmlspecialchars($current_session_name); ?></strong>.
              </p>
              <a href="<?php echo ADMIN_URL; ?>/fees" class="roaster-btn secondary" style="display: inline-flex; text-decoration: none;">
                <i class="fa-solid fa-rotate-left"></i> Reset All Filters
              </a>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($payments as $p): ?>
            <?php 
              $has_photo = !empty($p['photo']) && $p['photo'] !== '/assets/imgs/ksv-logo.jpg' && file_exists(__DIR__ . '/../..' . $p['photo']);
              $first_letter = strtoupper(substr($p['student_name'], 0, 1));

              // Mode icon
              $mode_icon = 'fa-money-bill-wave';
              if (stripos($p['payment_method'], 'upi') !== false) {
                $mode_icon = 'fa-qrcode';
              } elseif (stripos($p['payment_method'], 'net') !== false || stripos($p['payment_method'], 'bank') !== false) {
                $mode_icon = 'fa-building-columns';
              } elseif (stripos($p['payment_method'], 'cheque') !== false) {
                $mode_icon = 'fa-money-check';
              }
            ?>
            <tr class="ledger-row">
              <!-- 1. Receipt No -->
              <td>
                <span class="sid-receipt-pill">
                  <i class="fa-solid fa-receipt" style="font-size: 0.65rem;"></i>
                  <span><?php echo htmlspecialchars($p['receipt_no']); ?></span>
                </span>
              </td>

              <!-- 2. Student Profile -->
              <td>
                <div class="user-cell" style="display: flex; align-items: center; gap: 12px;">
                  <?php if ($has_photo): ?>
                    <img src="<?php echo htmlspecialchars($p['photo']); ?>" alt="<?php echo htmlspecialchars($p['student_name']); ?>" style="width: 38px; height: 38px; border-radius: 50%; object-fit: cover; border: 1.5px solid #e2e8f0; flex-shrink: 0;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div style="width: 38px; height: 38px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 14px; border: 1px solid #e2e8f0; display: none; align-items: center; justify-content: center; flex-shrink: 0;">
                      <?php echo $first_letter; ?>
                    </div>
                  <?php else: ?>
                    <div style="width: 38px; height: 38px; border-radius: 50%; background: #f1f5f9; color: #334155; font-weight: 700; font-size: 14px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                      <?php echo $first_letter; ?>
                    </div>
                  <?php endif; ?>
                  <div>
                    <div style="font-weight: 700; color: #0f172a; font-size: 0.88rem; font-family: 'Outfit', sans-serif; line-height: 1.25;">
                      <?php echo htmlspecialchars($p['student_name']); ?>
                    </div>
                    <div style="font-size: 0.73rem; color: #64748b; margin-top: 2px; display: flex; align-items: center; gap: 6px;">
                      <span><?php echo htmlspecialchars($p['gender'] ?? 'Scholar'); ?></span>
                      <?php if (!empty($p['blood_group'])): ?>
                        <span>&bull;</span>
                        <span class="sid-blood-badge">Blood: <?php echo htmlspecialchars($p['blood_group']); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </td>

              <!-- 3. Roll & Admission -->
              <td>
                <span class="sid-roll-pill">
                  <i class="fa-solid fa-hashtag" style="font-size: 0.62rem;"></i>
                  <span><?php echo htmlspecialchars($p['roll_no']); ?></span>
                </span>
                <div style="font-size: 0.74rem; color: #64748b; margin-top: 4px;">
                  Adm: <?php echo htmlspecialchars($p['admission_no'] ?? '—'); ?>
                </div>
              </td>

              <!-- 4. Standard & Section -->
              <td>
                <span class="sid-std-pill">
                  <i class="fa-solid fa-graduation-cap" style="font-size: 0.65rem; color: #64748b;"></i>
                  <span><?php echo htmlspecialchars($p['standard']); ?></span>
                </span>
                <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 4px;">
                  Section <?php echo htmlspecialchars($p['section'] ?? 'A'); ?>
                </div>
              </td>

              <!-- 5. Fee Type -->
              <td>
                <span class="sid-feehead-pill">
                  <i class="fa-solid fa-tag" style="font-size: 0.62rem; color: #0284c7;"></i>
                  <span><?php echo htmlspecialchars($p['fee_type'] ?? 'Tuition Fee'); ?></span>
                </span>
              </td>

              <!-- 6. Amount Paid -->
              <td>
                <div style="font-weight: 700; color: #059669; font-size: 0.88rem; font-family: 'Outfit', sans-serif;">
                  <?php echo format_inr($p['amount']); ?>
                </div>
                <?php if (!empty($p['discount']) && $p['discount'] > 0): ?>
                  <div style="font-size: 0.70rem; color: #dc2626; margin-top: 1px;">
                    Disc: <?php echo format_inr($p['discount']); ?>
                  </div>
                <?php endif; ?>
              </td>

              <!-- 7. Payment Mode -->
              <td>
                <span class="sid-mode-pill <?php echo strtolower(preg_replace('/[^a-zA-Z]/', '', $p['payment_method'])); ?>">
                  <i class="fa-solid <?php echo $mode_icon; ?>" style="font-size: 0.65rem;"></i>
                  <span><?php echo htmlspecialchars($p['payment_method']); ?></span>
                </span>
              </td>

              <!-- 8. Payment Date -->
              <td>
                <span style="font-size: 0.76rem; font-weight: 600; color: #64748b; white-space: nowrap;">
                  <?php echo format_date($p['payment_date']); ?>
                </span>
              </td>

              <!-- 9. Actions (Receipt & Collect) -->
              <td style="text-align: right; white-space: nowrap;">
                <div style="display: inline-flex; align-items: center; justify-content: flex-end; gap: 6px;">
                  <?php if ($current_user['role'] === 'super_admin'): ?>
                    <button type="button" onclick="event.stopPropagation(); openCollectModal(<?php echo (int)$p['student_id']; ?>);" class="sid-btn-action sid-btn-secondary" title="Collect fee installment for <?php echo htmlspecialchars($p['student_name'], ENT_QUOTES, 'UTF-8'); ?>">
                      <i class="fa-solid fa-circle-dollar-to-slot" style="color: #059669; font-size: 0.70rem;"></i>
                      <span>Collect</span>
                    </button>
                  <?php endif; ?>
                  <button type="button" onclick="event.stopPropagation(); openReceiptModalById(<?php echo (int)$p['id']; ?>);" class="sid-btn-action sid-btn-primary" title="View &amp; Print Official Receipt">
                    <i class="fa-solid fa-receipt" style="font-size: 0.70rem;"></i>
                    <span>Receipt</span>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Table Pagination & Per-Page Controls -->
  <div class="pagination-controls-wrap">
    
    <!-- Left: Showing summary & Limit Selector -->
    <div class="pagination-meta-group">
      <span style="font-size: 0.82rem; color: #475569;">
        <?php if ($total_records > 0): ?>
          Showing <strong><?php echo $start_record; ?></strong>–<strong><?php echo $end_record; ?></strong> of <strong><?php echo $total_records; ?></strong> receipts
        <?php else: ?>
          Showing <strong>0</strong> receipts
        <?php endif; ?>
      </span>

      <div class="pagination-limit-box">
        <label for="perPageLimitSelect" style="color: #64748b; font-size: 0.8rem; margin: 0; font-weight: 500;">Show Per Page</label>
        <select id="perPageLimitSelect" class="pagination-limit-select" onchange="window.location.href = this.value;">
          <?php foreach ($allowed_limits as $l): ?>
            <option value="<?php echo htmlspecialchars(get_fee_pagination_url(1, $search, $filter_standard, $filter_method, $filter_student_id, $l)); ?>" <?php echo $limit === $l ? 'selected' : ''; ?>>
              <?php echo $l; ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <!-- Center/Right: Navigation page buttons -->
    <?php if ($total_pages > 1): ?>
      <nav class="pagination-nav" aria-label="Fee Ledger Pagination">
        <!-- Prev Page -->
        <a href="<?php echo $page > 1 ? htmlspecialchars(get_fee_pagination_url($page - 1, $search, $filter_standard, $filter_method, $filter_student_id, $limit)) : '#'; ?>" 
           class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" 
           aria-label="Previous Page"
           title="Previous Page">
          <i class="fa-solid fa-chevron-left" style="font-size: 0.72rem;"></i>
        </a>

        <!-- Page Numbers -->
        <?php
          $range = 2;
          for ($p = 1; $p <= $total_pages; $p++):
            if ($p == 1 || $p == $total_pages || ($p >= $page - $range && $p <= $page + $range)):
        ?>
          <a href="<?php echo htmlspecialchars(get_fee_pagination_url($p, $search, $filter_standard, $filter_method, $filter_student_id, $limit)); ?>" 
             class="pagination-btn <?php echo $p === $page ? 'active' : ''; ?>">
            <?php echo $p; ?>
          </a>
        <?php 
            elseif (($p == 2 && $page - $range > 2) || ($p == $total_pages - 1 && $page + $range < $total_pages - 1)):
        ?>
          <span class="pagination-ellipsis">&hellip;</span>
        <?php 
            endif;
          endfor;
        ?>

        <!-- Next Page -->
        <a href="<?php echo $page < $total_pages ? htmlspecialchars(get_fee_pagination_url($page + 1, $search, $filter_standard, $filter_method, $filter_student_id, $limit)) : '#'; ?>" 
           class="pagination-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>" 
           aria-label="Next Page"
           title="Next Page">
          <i class="fa-solid fa-chevron-right" style="font-size: 0.72rem;"></i>
        </a>
      </nav>
    <?php endif; ?>

    <!-- Ledger Footer Summary & Session Info -->
    <div style="font-size: 0.78rem; color: #64748b; display: flex; align-items: center; gap: 12px; margin-left: auto;">
      <span>Total Collected: <strong style="color: #059669; font-family: 'Outfit', sans-serif;"><?php echo format_inr($total_collected); ?></strong></span>
      <span style="color: #cbd5e1;">|</span>
      <span>Session: <strong style="color: #334155;"><?php echo htmlspecialchars($current_session_name); ?></strong></span>
    </div>

  </div>

</div>

<!-- ══════════════════════════════════════════════════════
     MODAL: MOSQUE-INSPIRED OFFICIAL RECEIPT (VIEW, PRINT, DOWNLOAD, SHARE)
     ══════════════════════════════════════════════════════ -->
<div class="hrms-modal" id="receiptPrintModal">
  <div class="hrms-modal-card receipt-modal-card" style="max-width: 520px; width: 95%; max-height: 90vh; display: flex; flex-direction: column; border-radius: 20px; overflow: hidden; box-shadow: 0 25px 60px -15px rgba(15, 23, 42, 0.4);">
    
    <!-- Modal Header (no-print) -->
    <div class="hrms-modal-header no-print" style="padding: 14px 20px; background: #ffffff; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 36px; height: 36px; border-radius: 10px; background: rgba(0, 146, 223, 0.1); color: var(--hrms-primary); display: flex; align-items: center; justify-content: center; font-size: 1.05rem;">
          <i class="fa-solid fa-file-invoice-dollar"></i>
        </div>
        <div>
          <h4 style="margin: 0; font-size: 0.98rem; font-weight: 800; color: var(--hrms-navy); font-family: 'Outfit', sans-serif;">
            Official Fee Receipt
          </h4>
          <span id="modalReceiptSub" style="font-size: 0.72rem; color: #64748b;">Verified School Voucher</span>
        </div>
      </div>

      <button type="button" class="modal-close-btn" onclick="closeReceiptModal();" aria-label="Close modal" style="width: 32px; height: 32px; border-radius: 8px; border: 1px solid #e2e8f0; background: #f8fafc; color: #64748b; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <!-- Modal Body (Receipt display container with visible scrollbar) -->
    <div class="hrms-modal-body" id="receiptModalBody">
      <div id="receipt_print_area" style="display: flex; justify-content: center; width: 100%; padding: 14px 10px 20px;">
        <!-- Built dynamically via buildPaymentReceipt(payment) -->
      </div>
    </div>

    <!-- Hidden container used for off-screen clean html2canvas rendering -->
    <div id="receiptRenderContainer" style="position: fixed; left: -9999px; top: 0; width: 480px;"></div>

    <!-- Modal Footer Action Buttons (Print, Download, Share) -->
    <div class="no-print" style="padding: 12px 18px; background: #ffffff; border-top: 1px solid #e2e8f0; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
      
      <!-- Print Button -->
      <button type="button" onclick="printReceipt();" class="btn-hrms btn-hrms-outline btn-hrms-sm" style="font-weight: 700; gap: 6px; justify-content: center; padding: 9px 12px; font-size: 0.82rem; border-color: #cbd5e1;" title="Print on printer or save as PDF">
        <i class="fa-solid fa-print"></i>
        <span>Print</span>
      </button>

      <!-- Download Button -->
      <button type="button" id="btn_download_receipt" onclick="downloadReceiptPNG();" class="roaster-add-btn" style="justify-content: center; padding: 9px 12px; font-size: 0.82rem; gap: 6px; box-shadow: 0 4px 12px rgba(0, 146, 223, 0.25);" title="Download as high-resolution PNG image">
        <i class="fa-solid fa-file-arrow-down"></i>
        <span>Download</span>
      </button>

      <!-- Share Button -->
      <button type="button" id="btn_share_receipt" onclick="shareReceipt();" class="btn-hrms btn-hrms-sm" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #ffffff; border: none; font-weight: 700; gap: 6px; justify-content: center; padding: 9px 12px; font-size: 0.82rem; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);" title="Share via WhatsApp or Device Share">
        <i class="fa-solid fa-share-nodes"></i>
        <span>Share</span>
      </button>

    </div>

  </div>
</div>

<?php if ($current_user['role'] === 'super_admin'): ?>
<!-- ══════════════════════════════════════════════════════
     MODAL: COLLECT FEE PAYMENT FORM
     ══════════════════════════════════════════════════════ -->
<div class="hrms-modal" id="collectFeeModal">
  <div class="hrms-modal-card" style="max-width: 580px; width: 100%; max-height: calc(100vh - 32px); max-height: calc(100dvh - 32px); display: flex; flex-direction: column; border-radius: 18px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35); margin: auto;">
    
    <!-- Modal Header -->
    <div class="hrms-modal-header" style="flex-shrink: 0; border-bottom: 1px solid #e2e8f0; padding: 16px 22px; background: #ffffff; display: flex; align-items: center; justify-content: space-between;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 40px; height: 40px; border-radius: 12px; background: rgba(0, 146, 223, 0.1); color: var(--hrms-primary); display: flex; align-items: center; justify-content: center; font-size: 1.15rem;">
          <i class="fa-solid fa-hand-holding-dollar"></i>
        </div>
        <div>
          <h3 style="margin: 0; font-size: 1.08rem; font-weight: 800; color: var(--hrms-navy); font-family: 'Outfit', sans-serif;">
            Record Fee Collection
          </h3>
          <p style="margin: 2px 0 0; font-size: 0.76rem; color: #64748b;">Collect configured student fee installments &amp; issue verified receipt</p>
        </div>
      </div>

      <button type="button" class="modal-close-btn" onclick="closeCollectModal();" aria-label="Close modal" style="width: 32px; height: 32px; border-radius: 8px; border: 1px solid #e2e8f0; background: #f8fafc; color: #64748b; display: flex; align-items: center; justify-content: center; cursor: pointer;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <!-- Form wrapping Body + Footer -->
    <form method="POST" action="<?php echo htmlspecialchars(ADMIN_URL . '/fees', ENT_QUOTES, 'UTF-8'); ?>" onsubmit="return validateCollectFeeForm();" style="display: flex; flex-direction: column; flex: 1; min-height: 0; margin: 0; overflow: hidden;">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
      <input type="hidden" name="action" value="collect_fee">
      <div style="display:none !important;" aria-hidden="true">
        <label for="fees_hp_collect">Leave blank</label>
        <input type="text" id="fees_hp_collect" name="fees_hp" tabindex="-1" autocomplete="off">
      </div>

      <!-- Modal Body (Scrollable) -->
      <div class="hrms-modal-body" style="flex: 1; min-height: 0; overflow-y: auto; padding: 18px 22px;">

        <!-- Student Selector with Due Indicator -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
            Select Scholar / Student <span style="color: #dc2626;">*</span>
          </label>
          <select name="student_id" id="collectStudentSelect" class="hrms-input" required style="width: 100%; padding: 9px 12px; font-size: 0.85rem;" onchange="updateStudentDueDisplay(this)">
            <option value="">-- Choose Enrolled Student --</option>
            <?php foreach ($students_list as $s): ?>
              <?php $due = max(0, $s['total_fees'] - $s['paid_fees']); ?>
              <option value="<?php echo $s['id']; ?>" data-due="<?php echo $due; ?>" data-total="<?php echo $s['total_fees']; ?>" data-paid="<?php echo $s['paid_fees']; ?>">
                <?php echo htmlspecialchars($s['student_name']); ?> (Roll: <?php echo htmlspecialchars($s['roll_no']); ?> &bull; Class: <?php echo htmlspecialchars($s['standard']); ?> &bull; Due: ₹<?php echo number_format($due); ?>)
              </option>
            <?php endforeach; ?>
          </select>

          <!-- Dynamic Due Banner -->
          <div id="studentDueBanner" class="due-banner" style="display: none;">
            <span id="bannerDueLabel"><i class="fa-solid fa-clock-rotate-left"></i> Current Outstanding Due:</span>
            <strong id="bannerDueAmount">₹0.00</strong>
          </div>

          <!-- Dynamic Installments Schedule Section (Created in Add Student) -->
          <div id="studentInstallmentsWrap" style="display: none; margin-top: 14px; margin-bottom: 6px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <label class="form-label" style="margin: 0; font-size: 0.8rem; font-weight: 700; color: #334155; display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-list-check" style="color: #0284c7;"></i>
                <span>Configured Installments (From Student Registration)</span>
              </label>
              <span id="installmentsCountBadge" style="font-size: 0.70rem; font-weight: 700; background: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 10px; border: 1px solid #e2e8f0;">
                0 Installments
              </span>
            </div>

            <!-- Quick Amount Chips -->
            <div id="quickAmountChips" style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px;"></div>

            <!-- Installments Cards Grid -->
            <div id="installmentsCardsList" style="display: flex; flex-direction: column; gap: 8px; max-height: 180px; overflow-y: auto; padding-right: 2px;"></div>
          </div>
        </div>

        <!-- Fee Type & Amount Paid (Clean 2-column grid) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px;">
          <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
              Fee Head / Category <span style="color: #dc2626;">*</span>
            </label>
            <select name="fee_type" id="collectFeeTypeSelect" class="hrms-input" style="width: 100%; padding: 9px 12px; font-size: 0.85rem;">
              <option value="Tuition Fee">Tuition Fee</option>
              <option value="Admission Fee">Admission Fee</option>
              <option value="Examination Fee">Examination Fee</option>
              <option value="Laboratory Charges">Laboratory Charges</option>
              <option value="Library Fee">Library Fee</option>
              <option value="Transport Fee">Transport Fee</option>
              <option value="Annual Charges">Annual Charges</option>
            </select>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
              Amount Paid (₹) <span style="color: #dc2626;">*</span>
            </label>
            <div style="position: relative;">
              <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); font-weight: 800; color: #059669;">₹</span>
              <input type="number" step="1" name="amount" id="collectAmountInput" placeholder="0" class="hrms-input" required style="width: 100%; padding: 9px 12px 9px 28px; font-weight: 800; font-size: 1rem; color: #059669;">
            </div>
          </div>
        </div>

        <!-- Payment Mode & Payment Date (Clean 2-column grid) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px;">
          <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
              Payment Mode <span style="color: #dc2626;">*</span>
            </label>
            <select name="payment_method" class="hrms-input" style="width: 100%; padding: 9px 12px; font-size: 0.85rem;">
              <option value="Cash">Cash</option>
              <option value="UPI">UPI / PhonePe / GPay</option>
              <option value="Net Banking">Net Banking / NEFT</option>
              <option value="Cheque">Cheque</option>
            </select>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
              Payment Date <span style="color: #dc2626;">*</span>
            </label>
            <input type="date" name="payment_date" value="<?php echo date('Y-m-d'); ?>" class="hrms-input" required style="width: 100%; padding: 9px 12px; font-size: 0.85rem;">
          </div>
        </div>

        <!-- Remarks / Ref ID -->
        <div class="form-group" style="margin-bottom: 8px;">
          <label class="form-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 6px;">
            Transaction Reference / Remarks
          </label>
          <input type="text" name="remarks" id="collectRemarksInput" placeholder="e.g. UPI Ref #4928192019 or Cheque #91823" class="hrms-input" style="width: 100%; padding: 9px 12px; font-size: 0.85rem;">
        </div>

      </div>

      <!-- Modal Footer (Pinned at bottom) -->
      <div class="collect-modal-actions" style="flex-shrink: 0; display: flex; justify-content: flex-end; gap: 10px; padding: 14px 22px; border-top: 1px solid #e2e8f0; background: #f8fafc;">
        <button type="button" onclick="closeCollectModal();" class="btn-hrms btn-hrms-outline collect-cancel-btn" style="padding: 9px 18px; font-weight: 600;">
          Cancel
        </button>
        <button type="submit" class="roaster-add-btn collect-submit-btn" style="padding: 9px 22px; font-size: 0.85rem; gap: 8px;">
          <i class="fa-solid fa-check"></i>
          <span>Record &amp; Issue Receipt</span>
        </button>
      </div>

    </form>

  </div>
</div>
<?php endif; ?>

<script>
// ── Global Lookup Maps for Fast Modal Opening & URL State Persistence ──
window.STUDENT_INSTALLMENTS_MAP = <?php echo json_encode($students_installments_map ?? [], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
window.FEES_PAYMENTS_MAP = <?php 
  $clean_map = [];
  foreach ($payments as $item) {
      $clean_map[$item['id']] = $item;
  }
  echo json_encode($clean_map, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
?>;

// ── State for Active Payment in Modal ──
let currentActivePayment = null;

// ── Number to Indian Currency Words (e.g. 10000 -> Ten Thousand Rupees Only) ──
function numberToIndianWords(num) {
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  num = Math.floor(parseFloat(num) || 0);
  if (num === 0) return '(Zero Rupees Only)';

  function convertSection(n) {
    if (n < 20) return a[n];
    const digit = n % 10;
    return b[Math.floor(n / 10)] + (digit ? ' ' + a[digit] : '');
  }

  let words = '';
  const crore = Math.floor(num / 10000000);
  num %= 10000000;
  const lakh = Math.floor(num / 100000);
  num %= 100000;
  const thousand = Math.floor(num / 1000);
  num %= 1000;
  const hundred = Math.floor(num / 100);
  const remaining = num % 100;

  if (crore > 0) words += convertSection(crore) + ' Crore ';
  if (lakh > 0) words += convertSection(lakh) + ' Lakh ';
  if (thousand > 0) words += convertSection(thousand) + ' Thousand ';
  if (hundred > 0) words += convertSection(hundred) + ' Hundred ';
  if (remaining > 0) {
    if (words !== '') words += 'and ';
    words += convertSection(remaining) + ' ';
  }

  return '(' + words.trim() + ' Rupees Only)';
}

// ── Build Mosque-Style Official Receipt Card ──
function buildPaymentReceipt(record) {
  const paymentsList = (record.all_payments && Array.isArray(record.all_payments) && record.all_payments.length > 0)
    ? record.all_payments
    : [record];

  let totalReceived = 0;
  paymentsList.forEach(p => {
    totalReceived += parseFloat(p.amount) || 0;
  });

  const totalCourseFee = parseFloat(record.total_fees || 0);
  const remainingDue = Math.max(0, totalCourseFee - totalReceived);

  const receiptNo = record.receipt_no || ('RCPT-' + String(record.id).padStart(5, '0'));

  let payDateFmt = '--';
  if (record.payment_date) {
    const d = new Date(record.payment_date + 'T12:00:00');
    payDateFmt = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
  }

  const totalReceivedFmt = '₹' + totalReceived.toLocaleString('en-IN', { minimumFractionDigits: 2 }) + '/-';
  const amountWords = numberToIndianWords(totalReceived);

  const esc = (str) => {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  };

  // Verification QR string
  const qrData = "VERIFIED-INSTITUTE-FEE-RECEIPT:" + receiptNo + "|STUDENT:" + (record.student_name || '') + "|TOTAL_AMT:" + totalReceived + "|PAYMENTS:" + paymentsList.length;

  const schoolName = <?php echo json_encode($school_settings['school_name'] ?? 'KSV Academy', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
  const schoolAddress = <?php echo json_encode(($school_settings['address'] ?? 'KSV Campus, Near City Center') . ' • Contact: ' . ($school_settings['phone'] ?? '+91 98765 43210'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
  const sessionName = <?php echo json_encode($current_session_name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
  const schoolLogo = <?php echo json_encode($school_settings['logo_url'] ?? '/assets/imgs/ksv-logo.jpg', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;

  return `
    <div class="pay-receipt" id="renderedReceiptCard">
      <div class="ri-top-accent"></div>
      <div class="receipt-body">
        
        <!-- Academy Institutional Header -->
        <div class="ri-brand-row">
          <div class="ri-logo-box">
            <img src="${schoolLogo}" alt="Logo" onerror="this.src='/assets/imgs/ksv-logo.jpg'">
          </div>
          <div class="ri-brand-info">
            <h2 class="ri-title">${esc(schoolName)}</h2>
            <div class="ri-sub">Coaching Institute &amp; Academic Center</div>
            <div class="ri-address">${esc(schoolAddress)}</div>
          </div>
        </div>

        <!-- Document Type & Session Banner -->
        <div class="receipt-doc-band">
          <span class="receipt-doc-title"><i class="fa-solid fa-receipt" style="color: #0284c7; margin-right: 5px;"></i> FEE PAYMENT RECEIPT</span>
          <span class="receipt-doc-session">Session: ${esc(sessionName)}</span>
        </div>

        <!-- Student & Voucher Meta Grid -->
        <div class="receipt-meta-grid">
          <div class="rmg-cell">
            <span class="rmg-label">Receipt No</span>
            <span class="rmg-val mono-badge">${esc(receiptNo)}</span>
          </div>
          <div class="rmg-cell">
            <span class="rmg-label">Payment Date</span>
            <span class="rmg-val">${esc(payDateFmt)}</span>
          </div>
          <div class="rmg-cell">
            <span class="rmg-label">Student Name</span>
            <span class="rmg-val bold">${esc(record.student_name)}</span>
          </div>
          <div class="rmg-cell">
            <span class="rmg-label">Roll No / ID</span>
            <span class="rmg-val mono-badge" style="color: #0f172a;">${esc(record.roll_no)}</span>
          </div>
          <div class="rmg-cell">
            <span class="rmg-label">Class / Course</span>
            <span class="rmg-val">${esc(record.standard)}</span>
          </div>
          <div class="rmg-cell">
            <span class="rmg-label">${paymentsList.length > 1 ? 'Installments' : 'Payment Mode'}</span>
            <span class="rmg-val" style="color: #0284c7; font-weight: 700;">
              ${paymentsList.length > 1 ? `${paymentsList.length} Payments Recorded` : esc(record.payment_method || 'Cash')}
            </span>
          </div>
        </div>

        <!-- Particulars / Breakdown Table -->
        <div class="receipt-table-wrapper">
          <table class="receipt-table">
            <thead>
              <tr>
                <th style="width: 24px; text-align: center;">#</th>
                <th>Fee Head / Particulars</th>
                <th style="text-align: right; width: 105px;">Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${paymentsList.map((item, idx) => {
                const itemAmt = parseFloat(item.amount) || 0;
                let itemDate = '--';
                if (item.payment_date) {
                  const d = new Date(item.payment_date + 'T12:00:00');
                  itemDate = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
                }
                const isSelected = (item.id === record.id || item.receipt_no === record.receipt_no);
                const itemRemarks = item.remarks ? item.remarks.trim() : '';

                return `
                  <tr style="${isSelected && paymentsList.length > 1 ? 'background: #f0f9ff;' : ''}">
                    <td style="text-align: center; color: #64748b; font-weight: 700; font-size: 10px; vertical-align: top; padding-top: 7px;">
                      ${idx + 1}
                    </td>
                    <td style="padding: 6px 8px;">
                      <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;">
                        <span style="font-weight: 800; color: #0f172a; font-size: 10.5px;">
                          ${esc(item.fee_type || 'Tuition Fee')}
                          ${paymentsList.length > 1 ? `<span style="font-size: 8.5px; color: #0284c7; font-weight: 700; margin-left: 3px;">(Installment ${idx + 1})</span>` : ''}
                        </span>
                        <span style="font-size: 8.5px; background: #e0f2fe; color: #0369a1; padding: 1px 5px; border-radius: 4px; font-weight: 700; font-family: monospace;">
                          ${esc(item.receipt_no)}
                        </span>
                      </div>
                      <div style="font-size: 9px; color: #64748b; margin-top: 2px;">
                        <span><i class="fa-regular fa-calendar" style="font-size: 8px;"></i> ${esc(itemDate)}</span>
                        &bull; <span><i class="fa-solid fa-wallet" style="font-size: 8px;"></i> ${esc(item.payment_method || 'Cash')}</span>
                        ${isSelected && paymentsList.length > 1 ? '<span style="color: #0284c7; font-weight: 800; margin-left: 3px;">(Selected)</span>' : ''}
                      </div>
                      ${itemRemarks ? `<div style="font-size: 8.5px; color: #0284c7; margin-top: 2px; font-style: italic;">Note: ${esc(itemRemarks)}</div>` : ''}
                    </td>
                    <td style="text-align: right; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif; font-size: 11px; vertical-align: top; padding-top: 7px; white-space: nowrap;">
                      ₹${itemAmt.toLocaleString('en-IN', { minimumFractionDigits: 2 })}/-
                    </td>
                  </tr>
                `;
              }).join('')}

              <tr class="total-row">
                <td colspan="2" style="text-align: right; font-weight: 800; font-size: 10.5px; color: #0f172a; text-transform: uppercase;">
                  Total Amount Received
                </td>
                <td style="text-align: right; font-size: 13px; font-weight: 900; color: #059669; font-family: 'Outfit', sans-serif;">
                  ${totalReceivedFmt}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Course Fee & Due Balance Strip -->
        ${totalCourseFee > 0 ? `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 7px 10px; font-size: 9.5px;">
            <div>
              <span style="color: #64748b; display: block; font-size: 8.5px; text-transform: uppercase; font-weight: 700;">Total Course Fee</span>
              <strong style="color: #0f172a; font-family: 'Outfit', sans-serif; font-size: 11px;">₹${totalCourseFee.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </div>
            <div style="text-align: right;">
              <span style="color: #64748b; display: block; font-size: 8.5px; text-transform: uppercase; font-weight: 700;">Outstanding Balance Due</span>
              <strong style="color: ${remainingDue > 0 ? '#dc2626' : '#059669'}; font-family: 'Outfit', sans-serif; font-size: 11px;">
                ${remainingDue > 0 ? `₹${remainingDue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : 'Fully Paid ✓'}
              </strong>
            </div>
          </div>
        ` : ''}

        <!-- Amount In Words Box -->
        <div class="receipt-words-box">
          <span class="words-label">Total Amount in Words:</span>
          <span class="words-val">${amountWords}</span>
        </div>

        <!-- Signatures & Official Institute Stamp -->
        <div class="receipt-auth-row">
          <div class="auth-sign-box">
            <div class="auth-sign-line">${esc(record.student_name)}</div>
            <div class="auth-sign-label">Student / Depositor</div>
          </div>

          <div class="auth-seal-badge">
            <div class="seal-text-top">KSV ACADEMY</div>
            <div class="seal-text-mid">★ VERIFIED ★</div>
            <div class="seal-text-bot">ACCOUNTS DEPT</div>
          </div>

          <div class="auth-sign-box">
            <div class="auth-sign-line" style="color: #0284c7;">Authorized Signatory</div>
            <div class="auth-sign-label">Accounts Officer</div>
          </div>
        </div>

        <!-- Security QR & Institutional Terms -->
        <div class="receipt-bottom-bar">
          <div class="rb-qr-wrap">
            <img id="dl_qr_image" src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&margin=0&data=${encodeURIComponent(qrData)}" alt="QR Code">
          </div>
          <div class="rb-notes">
            <div><strong>Terms &amp; Instructions:</strong></div>
            <div>• Computer-generated fee acknowledgement voucher issued by KSV Academy.</div>
            <div>• Fees deposited are non-refundable and non-transferable under any condition.</div>
            <div>• Please preserve this receipt for academic clearance and hall ticket.</div>
          </div>
        </div>

      </div>
    </div>`;
}

// ── Open Receipt Modal ──
function openReceiptModal(payment) {
  if (!payment) return;
  currentActivePayment = payment;
  const printArea = document.getElementById('receipt_print_area');
  if (printArea) {
    printArea.innerHTML = buildPaymentReceipt(payment);
  }

  const sub = document.getElementById('modalReceiptSub');
  if (sub) {
    const pCount = (payment.all_payments && payment.all_payments.length) ? payment.all_payments.length : 1;
    sub.innerText = payment.student_name + ' • ' + (pCount > 1 ? `${pCount} Payments Recorded` : payment.receipt_no);
  }

  const modal = document.getElementById('receiptPrintModal');
  if (modal) {
    modal.style.display = 'flex';
    modal.classList.add('show');
    modal.setAttribute('data-opened-at', Date.now());
  }

  // Update URL state to preserve open modal on reload without page refresh
  try {
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.delete('collect');
    newUrl.searchParams.set('receipt', payment.receipt_no);
    history.replaceState(null, '', newUrl.toString());
  } catch (e) {}

  // Reset scroll position to top
  const body = document.getElementById('receiptModalBody');
  if (body) {
    body.scrollTop = 0;
  }
}

function openReceiptModalById(paymentId) {
  const p = window.FEES_PAYMENTS_MAP ? window.FEES_PAYMENTS_MAP[paymentId] : null;
  if (p) {
    openReceiptModal(p);
  }
}

// ── Close Receipt Modal ──
function closeReceiptModal() {
  const modal = document.getElementById('receiptPrintModal');
  if (modal) {
    modal.classList.remove('show');
    modal.style.display = 'none';
  }
  // Clear URL receipt state without page refresh
  try {
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.delete('receipt');
    history.replaceState(null, '', newUrl.toString());
  } catch (e) {}
}

// ── Print Action (Isolated Clean Print) ──
function printReceipt() {
  if (!currentActivePayment) return;
  const p = currentActivePayment;
  const printArea = document.getElementById('receipt_print_area');
  if (!printArea) return;

  const receiptContent = printArea.innerHTML;

  // Create or reuse hidden printing iframe for 100% reliable print isolation
  let printIframe = document.getElementById('ksvReceiptPrintFrame');
  if (!printIframe) {
    printIframe = document.createElement('iframe');
    printIframe.id = 'ksvReceiptPrintFrame';
    printIframe.style.position = 'fixed';
    printIframe.style.right = '0';
    printIframe.style.bottom = '0';
    printIframe.style.width = '0';
    printIframe.style.height = '0';
    printIframe.style.border = '0';
    document.body.appendChild(printIframe);
  }

  // Collect external link stylesheets (FontAwesome, Fonts)
  const externalLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
    .map(el => el.outerHTML)
    .join('\n');

  // Dedicated, pristine styles for receipt print (no visibility:hidden or layout clashes)
  const payReceiptStyles = `
    * { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    html, body {
      margin: 0;
      padding: 0;
      background: #ffffff !important;
      color: #0f172a;
      font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
    }
    body {
      display: flex;
      justify-content: center;
      padding: 8mm 0;
    }
    .pay-receipt {
      padding: 0;
      background: #ffffff !important;
      color: #0f172a;
      width: 100%;
      max-width: 480px;
      margin: 0 auto !important;
      border-radius: 12px;
      overflow: hidden;
      border: 1.5px solid #cbd5e1 !important;
      box-shadow: none !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .pay-receipt .ri-top-accent {
      height: 6px;
      background: linear-gradient(90deg, #0f172a 0%, #0092df 50%, #0284c7 100%);
    }
    .pay-receipt .receipt-body {
      padding: 16px 20px 14px;
    }
    .pay-receipt .ri-brand-row {
      display: flex;
      align-items: center;
      gap: 14px;
      padding-bottom: 12px;
      border-bottom: 2px solid #e2e8f0;
    }
    .pay-receipt .ri-logo-box {
      width: 54px;
      height: 54px;
      min-width: 54px;
      border-radius: 10px;
      border: 1.5px solid #e2e8f0;
      padding: 3px;
      background: #ffffff;
    }
    .pay-receipt .ri-logo-box img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      border-radius: 6px;
    }
    .pay-receipt .ri-brand-info { flex: 1; }
    .pay-receipt .ri-title {
      margin: 0;
      font-size: 16px;
      font-weight: 800;
      color: #0f172a;
      font-family: 'Outfit', sans-serif;
      line-height: 1.2;
    }
    .pay-receipt .ri-sub {
      font-size: 10px;
      font-weight: 700;
      color: #0284c7;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      margin-top: 2px;
    }
    .pay-receipt .ri-address {
      font-size: 9.5px;
      color: #64748b;
      margin-top: 2px;
      line-height: 1.3;
    }
    .pay-receipt .receipt-doc-band {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 5px 10px;
      margin: 8px 0 6px;
    }
    .pay-receipt .receipt-doc-title {
      font-size: 11px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      font-family: 'Outfit', sans-serif;
    }
    .pay-receipt .receipt-doc-session {
      font-size: 10px;
      font-weight: 700;
      color: #0284c7;
      background: #e0f2fe;
      padding: 2px 7px;
      border-radius: 5px;
    }
    .pay-receipt .receipt-meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 5px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 6px 10px;
      margin-bottom: 8px;
    }
    .pay-receipt .rmg-cell { display: flex; flex-direction: column; }
    .pay-receipt .rmg-label {
      font-size: 8.5px;
      color: #64748b;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.03em;
    }
    .pay-receipt .rmg-val {
      font-size: 10.5px;
      color: #0f172a;
      font-weight: 600;
      margin-top: 1px;
    }
    .pay-receipt .rmg-val.bold {
      font-weight: 800;
      font-family: 'Outfit', sans-serif;
      font-size: 11.5px;
    }
    .pay-receipt .rmg-val.mono-badge {
      font-family: monospace;
      color: #0284c7;
      font-weight: 800;
      letter-spacing: 0.02em;
    }
    .pay-receipt .receipt-table-wrapper {
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 8px;
    }
    .pay-receipt .receipt-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 10.5px;
    }
    .pay-receipt .receipt-table th {
      background: #f1f5f9;
      color: #334155;
      font-weight: 800;
      text-transform: uppercase;
      font-size: 8.5px;
      padding: 6px 10px;
      letter-spacing: 0.04em;
    }
    .pay-receipt .receipt-table td {
      padding: 7px 10px;
      border-bottom: 1px solid #f1f5f9;
      color: #334155;
    }
    .pay-receipt .receipt-table tr.total-row td {
      background: #f8fafc;
      border-top: 1.5px solid #cbd5e1;
      border-bottom: none;
      padding: 8px 10px;
    }
    .pay-receipt .receipt-words-box {
      background: #f0fdf4;
      border: 1px dashed #86efac;
      border-radius: 6px;
      padding: 6px 10px;
      margin-bottom: 10px;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .pay-receipt .receipt-words-box .words-label {
      font-size: 8px;
      font-weight: 800;
      color: #166534;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .pay-receipt .receipt-words-box .words-val {
      font-size: 9.5px;
      font-weight: 700;
      color: #15803d;
      font-style: italic;
    }
    .pay-receipt .receipt-auth-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin: 10px 0 8px;
      padding: 0 4px;
    }
    .pay-receipt .auth-sign-box { text-align: center; width: 115px; }
    .pay-receipt .auth-sign-line {
      border-bottom: 1.5px dashed #94a3b8;
      height: 24px;
      margin-bottom: 4px;
      font-size: 10.5px;
      font-weight: 700;
      color: #0f172a;
      display: flex;
      align-items: flex-end;
      justify-content: center;
    }
    .pay-receipt .auth-sign-label {
      font-size: 9px;
      font-weight: 700;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .pay-receipt .auth-seal-badge {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      border: 2px dashed #0284c7;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 4px;
      background: rgba(2, 132, 199, 0.03);
      transform: rotate(-6deg);
      margin: 0 auto;
    }
    .pay-receipt .seal-text-top { font-size: 7px; font-weight: 900; color: #0284c7; letter-spacing: 0.05em; line-height: 1; }
    .pay-receipt .seal-text-mid { font-size: 7.5px; font-weight: 900; color: #059669; letter-spacing: 0.08em; margin: 2px 0; line-height: 1; }
    .pay-receipt .seal-text-bot { font-size: 6.5px; font-weight: 800; color: #0284c7; line-height: 1; }
    .pay-receipt .receipt-bottom-bar {
      display: flex;
      gap: 10px;
      align-items: center;
      border-top: 1px solid #e2e8f0;
      padding-top: 8px;
      margin-top: 8px;
    }
    .pay-receipt .rb-qr-wrap {
      width: 62px;
      min-width: 62px;
      height: 62px;
      padding: 3px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
    }
    .pay-receipt .rb-qr-wrap img { width: 100%; height: 100%; display: block; }
    .pay-receipt .rb-notes { flex: 1; font-size: 8.5px; color: #64748b; line-height: 1.35; }
    .pay-receipt .rb-notes strong { color: #334155; }
    .no-print { display: none !important; }
    @page { size: auto; margin: 8mm; }
  `;

  const doc = printIframe.contentWindow.document;
  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Fee Receipt - ${p.student_name || 'KSV Academy'} - ${p.receipt_no || ''}</title>
      ${externalLinks}
      <style>
        ${payReceiptStyles}
      </style>
    </head>
    <body>
      ${receiptContent}
    </body>
    </html>
  `);
  doc.close();

  setTimeout(() => {
    try {
      printIframe.contentWindow.focus();
      printIframe.contentWindow.print();
    } catch (e) {
      console.warn('Iframe print fallback to window.print():', e);
      window.print();
    }
  }, 400);
}

// ── Download PNG Action (html2canvas) ──
function downloadReceiptPNG() {
  if (!currentActivePayment) return;
  const p = currentActivePayment;
  const btn = document.getElementById('btn_download_receipt');
  const origHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Rendering...';

  const renderContainer = document.getElementById('receiptRenderContainer');
  renderContainer.innerHTML = buildPaymentReceipt(p);
  const cardEl = renderContainer.firstElementChild;
  const filename = `Fee_Receipt-${(p.student_name || 'Student').replace(/\s+/g, '_')}-${p.receipt_no}.png`;

  // Pre-load image blob to avoid CORS issues in canvas
  const imgEl = renderContainer.querySelector('#dl_qr_image');
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const runExport = () => {
    html2canvas(cardEl, {
      scale: 2,
      useCORS: true,
      backgroundColor: isDark ? '#0f172a' : '#ffffff'
    }).then(canvas => {
      const link = document.createElement('a');
      link.download = filename;
      link.href = canvas.toDataURL('image/png');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      btn.disabled = false;
      btn.innerHTML = origHtml;
      renderContainer.innerHTML = '';
    }).catch(err => {
      console.error('html2canvas error:', err);
      alert('Unable to generate PNG receipt. You can use the Print button to save as PDF.');
      btn.disabled = false;
      btn.innerHTML = origHtml;
      renderContainer.innerHTML = '';
    });
  };

  if (imgEl && imgEl.src.startsWith('http')) {
    fetch(imgEl.src)
      .then(res => res.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = () => {
          imgEl.src = reader.result;
          runExport();
        };
        reader.readAsDataURL(blob);
      })
      .catch(() => runExport());
  } else {
    runExport();
  }
}

// ── Share Action (WhatsApp & Web Share) ──
function shareReceipt() {
  if (!currentActivePayment) return;
  const p = currentActivePayment;
  const btn = document.getElementById('btn_share_receipt');
  const origHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sharing...';

  const paymentsList = (p.all_payments && p.all_payments.length > 0) ? p.all_payments : [p];
  const totalPaidSum = paymentsList.reduce((acc, curr) => acc + (parseFloat(curr.amount) || 0), 0);

  let shareText = `*KSV ACADEMY - OFFICIAL FEE PAYMENT RECEIPT*\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `• Student: ${p.student_name} (${p.roll_no || '-'})\n` +
    `• Class: ${p.standard || '-'}\n` +
    `• Payments Recorded: ${paymentsList.length}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  paymentsList.forEach((pmt, idx) => {
    const pDate = pmt.payment_date ? new Date(pmt.payment_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-';
    shareText += `[${idx + 1}] ${pmt.fee_type || 'Tuition Fee'} (${pmt.receipt_no}): ₹${parseFloat(pmt.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })} on ${pDate} [${pmt.payment_method}]\n`;
  });

  shareText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `• Total Amount Received: ₹${totalPaidSum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}\n`;

  if (p.total_fee !== undefined && p.total_fee !== null && parseFloat(p.total_fee) > 0) {
    const balDue = Math.max(0, parseFloat(p.total_fee) - totalPaidSum);
    shareText += `• Total Course Fee: ₹${parseFloat(p.total_fee).toLocaleString('en-IN', { minimumFractionDigits: 2 })}\n` +
      `• Outstanding Due: ${balDue <= 0 ? 'Fully Paid (Nil)' : '₹' + balDue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}\n`;
  }

  shareText += `• Status: Paid & Cleared\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `Verified by KSV Academy Accounts Portal`;

  const renderContainer = document.getElementById('receiptRenderContainer');
  renderContainer.innerHTML = buildPaymentReceipt(p);
  const cardEl = renderContainer.firstElementChild;
  const filename = `Fee_Receipt-${(p.student_name || 'Student').replace(/\s+/g, '_')}-${p.receipt_no}.png`;
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

  html2canvas(cardEl, { scale: 2, useCORS: true, backgroundColor: isDark ? '#0f172a' : '#ffffff' })
    .then(canvas => {
      canvas.toBlob(blob => {
        const file = new File([blob], filename, { type: 'image/png' });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          navigator.share({
            title: `Fee Receipt - ${p.student_name}`,
            text: shareText,
            files: [file]
          }).then(() => {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            renderContainer.innerHTML = '';
          }).catch(err => {
            console.log('Share dismissed:', err);
            btn.disabled = false;
            btn.innerHTML = origHtml;
            renderContainer.innerHTML = '';
          });
        } else {
          // Fallback: Copy image to clipboard, and open WhatsApp with formatted text
          try {
            const item = new ClipboardItem({ 'image/png': blob });
            navigator.clipboard.write([item]).then(() => {
              btn.disabled = false;
              btn.innerHTML = origHtml;
              renderContainer.innerHTML = '';
              if (confirm('Receipt image copied to clipboard!\n\nClick OK to open WhatsApp and paste/send.')) {
                window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
              }
            }).catch(() => {
              const link = document.createElement('a');
              link.download = filename;
              link.href = canvas.toDataURL('image/png');
              link.click();
              btn.disabled = false;
              btn.innerHTML = origHtml;
              renderContainer.innerHTML = '';
              window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
            });
          } catch (e) {
            const link = document.createElement('a');
            link.download = filename;
            link.href = canvas.toDataURL('image/png');
            link.click();
            btn.disabled = false;
            btn.innerHTML = origHtml;
            renderContainer.innerHTML = '';
            window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
          }
        }
      }, 'image/png');
    })
    .catch(err => {
      console.error(err);
      btn.disabled = false;
      btn.innerHTML = origHtml;
      renderContainer.innerHTML = '';
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
    });
}

// ── Collect Fee Modal Controls ──
function openCollectModal(preselectStudentId) {
  const modal = document.getElementById('collectFeeModal');
  if (modal) {
    modal.style.display = 'flex';
    modal.classList.add('show');
    modal.setAttribute('data-opened-at', Date.now());
  }

  // Preserve modal state in URL on reload without refreshing page
  try {
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.delete('receipt');
    newUrl.searchParams.set('collect', preselectStudentId || '1');
    history.replaceState(null, '', newUrl.toString());
  } catch (e) {}

  const sel = document.getElementById('collectStudentSelect');
  if (sel) {
    if (preselectStudentId) {
      sel.value = preselectStudentId;
    }
    updateStudentDueDisplay(sel);
  }
}

function closeCollectModal() {
  const modal = document.getElementById('collectFeeModal');
  if (modal) {
    modal.classList.remove('show');
    modal.style.display = 'none';
  }
  const sel = document.getElementById('collectStudentSelect');
  if (sel) {
    sel.value = '';
    updateStudentDueDisplay(sel);
  }
  // Clear URL collect state without page refresh
  try {
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.delete('collect');
    history.replaceState(null, '', newUrl.toString());
  } catch (e) {}
}

function quickCollectFee(studentId, amount, remark) {
  openCollectModal(studentId);
  const amtInput = document.getElementById('collectAmountInput');
  if (amtInput && amount > 0) {
    amtInput.value = amount;
  }
  const remarkInput = document.getElementById('collectRemarksInput');
  if (remarkInput && remark) {
    remarkInput.value = remark + ' installment payment';
  }
}

function updateStudentDueDisplay(select, preferredInstallmentId = null) {
  if (!select) return;
  const opt = select.options[select.selectedIndex];
  const banner = document.getElementById('studentDueBanner');
  const labelEl = document.getElementById('bannerDueLabel');
  const amountEl = document.getElementById('bannerDueAmount');
  const amountInput = document.getElementById('collectAmountInput');
  const instWrap = document.getElementById('studentInstallmentsWrap');
  const instBadge = document.getElementById('installmentsCountBadge');
  const instList = document.getElementById('installmentsCardsList');
  const quickChips = document.getElementById('quickAmountChips');

  if (!banner) return;

  if (opt && opt.value) {
    const studentId = parseInt(opt.value, 10);
    const due = parseFloat(opt.getAttribute('data-due') || 0);

    banner.style.display = 'flex';
    banner.style.removeProperty('background');
    banner.style.removeProperty('border-color');
    banner.style.removeProperty('color');

    if (due > 0) {
      banner.className = 'due-banner is-due';
      if (labelEl) labelEl.innerHTML = '<i class="fa-solid fa-clock-rotate-left"></i> Current Outstanding Due:';
      if (amountEl) amountEl.innerText = '₹' + due.toLocaleString('en-IN');
      if (amountInput && (!amountInput.value || parseFloat(amountInput.value) <= 0)) {
        amountInput.value = due;
      }
    } else {
      banner.className = 'due-banner is-cleared';
      if (labelEl) labelEl.innerHTML = '<i class="fa-solid fa-circle-check"></i> Account Status:';
      if (amountEl) amountEl.innerText = 'Fully Paid / Cleared (₹0.00)';
      if (amountInput) amountInput.value = '0';
    }

    // Render Configured Installments (Created in Add Student)
    const installments = (window.STUDENT_INSTALLMENTS_MAP && window.STUDENT_INSTALLMENTS_MAP[studentId]) ? window.STUDENT_INSTALLMENTS_MAP[studentId] : [];

    if (instWrap && instList && installments.length > 0) {
      instWrap.style.display = 'block';
      if (instBadge) {
        instBadge.innerText = installments.length + (installments.length === 1 ? ' Installment' : ' Installments');
      }

      // Find first unpaid / overdue installment
      let nextUnpaidInst = installments.find(inst => !inst.is_paid && inst.pending_amount > 0);

      // Render Quick Chips
      let chipsHtml = '';
      if (nextUnpaidInst) {
        chipsHtml += `<button type="button" class="inst-chip active" onclick="selectInstallmentCard(${nextUnpaidInst.id || 0}, ${nextUnpaidInst.pending_amount}, '${escapeJsQuotes(nextUnpaidInst.title)}')">
          <i class="fa-solid fa-bolt" style="color: #f59e0b;"></i> Pay Next: ${escapeHtml(nextUnpaidInst.title)} (₹${nextUnpaidInst.pending_amount.toLocaleString('en-IN')})
        </button>`;
      }
      if (due > 0) {
        chipsHtml += `<button type="button" class="inst-chip" onclick="setCollectAmount(${due}, 'Tuition Fee', 'Full fee clearance payment')">
          <i class="fa-solid fa-check-double" style="color: #059669;"></i> Pay Full Due (₹${due.toLocaleString('en-IN')})
        </button>`;
      }
      chipsHtml += `<button type="button" class="inst-chip" onclick="focusCustomAmount()">
        <i class="fa-solid fa-pen-to-square"></i> Custom Amount
      </button>`;
      if (quickChips) quickChips.innerHTML = chipsHtml;

      // Render Installment Cards
      let cardsHtml = '';
      installments.forEach((inst, idx) => {
        const isPaid = inst.is_paid || inst.pending_amount <= 0;
        let badgeHtml = '';
        if (isPaid) {
          badgeHtml = '<span class="inst-badge paid"><i class="fa-solid fa-circle-check"></i> Paid</span>';
        } else if (inst.is_overdue) {
          badgeHtml = `<span class="inst-badge overdue"><i class="fa-solid fa-triangle-exclamation"></i> Overdue</span>`;
        } else if (inst.is_due_soon) {
          badgeHtml = `<span class="inst-badge due-soon"><i class="fa-solid fa-clock"></i> Due in ${inst.days_remaining}d</span>`;
        } else {
          badgeHtml = '<span class="inst-badge pending"><i class="fa-regular fa-calendar"></i> Upcoming</span>';
        }

        const isSelected = (!preferredInstallmentId && !isPaid && nextUnpaidInst && nextUnpaidInst === inst) || (preferredInstallmentId && inst.id == preferredInstallmentId);

        cardsHtml += `
          <div class="inst-card ${isPaid ? 'is-paid' : ''} ${isSelected ? 'selected' : ''}" id="inst_card_${inst.id || idx}" onclick="${isPaid ? '' : `selectInstallmentCard(${inst.id || idx}, ${inst.pending_amount}, '${escapeJsQuotes(inst.title)}')`}">
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <strong style="font-size: 0.84rem; color: #0f172a; font-family: 'Outfit', sans-serif;">${escapeHtml(inst.title)}</strong>
                ${badgeHtml}
              </div>
              <div style="font-size: 0.73rem; color: #64748b; margin-top: 2px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <span><i class="fa-regular fa-calendar" style="color: #94a3b8;"></i> Due: <strong>${escapeHtml(inst.due_date_formatted || inst.due_date)}</strong></span>
                <span>&bull;</span>
                <span>Total: ₹${parseFloat(inst.amount).toLocaleString('en-IN')}</span>
                <span>&bull;</span>
                <span style="color: ${isPaid ? '#059669' : '#0284c7'}; font-weight: 600;">Paid: ₹${parseFloat(inst.paid_amount || 0).toLocaleString('en-IN')}</span>
              </div>
            </div>
            <div style="text-align: right; flex-shrink: 0;">
              ${isPaid 
                ? '<div style="font-size: 0.75rem; font-weight: 700; color: #059669;"><i class="fa-solid fa-check"></i> Cleared</div>'
                : `<div style="font-size: 0.86rem; font-weight: 800; color: #0284c7; font-family: 'Outfit', sans-serif;">₹${parseFloat(inst.pending_amount).toLocaleString('en-IN')}</div>
                   <div style="font-size: 0.70rem; color: #64748b;">Pending Due</div>`
              }
            </div>
          </div>
        `;
      });
      instList.innerHTML = cardsHtml;

      // Auto-set the next unpaid installment amount, fee type, and remarks
      if (nextUnpaidInst && amountInput) {
        amountInput.value = nextUnpaidInst.pending_amount;
        setInstallmentFeeTypeAndRemarks(nextUnpaidInst.title, nextUnpaidInst.title + ' installment payment');
      }
    } else if (instWrap) {
      instWrap.style.display = 'none';
    }
  } else {
    banner.style.display = 'none';
    banner.className = 'due-banner';
    banner.style.removeProperty('background');
    banner.style.removeProperty('border-color');
    banner.style.removeProperty('color');
    if (instWrap) instWrap.style.display = 'none';
  }
}

function selectInstallmentCard(instId, amount, title) {
  document.querySelectorAll('.inst-card').forEach(c => c.classList.remove('selected'));
  const card = document.getElementById('inst_card_' + instId);
  if (card) card.classList.add('selected');
  setCollectAmount(amount, title, title + ' installment payment');
}

function setCollectAmount(amount, feeTypeTitle, remarksText) {
  const amountInput = document.getElementById('collectAmountInput');
  if (amountInput) {
    amountInput.value = amount;
    amountInput.focus();
  }
  setInstallmentFeeTypeAndRemarks(feeTypeTitle, remarksText);
}

function setInstallmentFeeTypeAndRemarks(title, remarksText) {
  const feeTypeSel = document.getElementById('collectFeeTypeSelect');
  if (feeTypeSel && title) {
    let found = false;
    for (let i = 0; i < feeTypeSel.options.length; i++) {
      if (feeTypeSel.options[i].value === title) {
        feeTypeSel.selectedIndex = i;
        found = true;
        break;
      }
    }
    if (!found) {
      const newOpt = document.createElement('option');
      newOpt.value = title;
      newOpt.textContent = title;
      newOpt.selected = true;
      feeTypeSel.appendChild(newOpt);
    }
  }
  const remInput = document.getElementById('collectRemarksInput');
  if (remInput) {
    remInput.value = remarksText || (title ? title + ' installment payment' : '');
  }
}

function focusCustomAmount() {
  const amountInput = document.getElementById('collectAmountInput');
  if (amountInput) {
    amountInput.focus();
    amountInput.select();
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function escapeJsQuotes(str) {
  if (!str) return '';
  return String(str).replace(/'/g, "\\'").replace(/"/g, '\\"');
}

function validateCollectFeeForm() {
  const amt = parseFloat(document.getElementById('collectAmountInput').value || 0);
  if (amt <= 0) {
    alert('Please enter a valid positive payment amount.');
    return false;
  }
  return true;
}

// ── Instant Table Search ──
function filterLedgerTable() {
  const q = document.getElementById('ledgerSearchInput').value.toLowerCase().trim();
  const rows = document.querySelectorAll('#feeLedgerTable tbody tr.ledger-row');

  rows.forEach(row => {
    const text = row.innerText.toLowerCase();
    row.style.display = (!q || text.includes(q)) ? '' : 'none';
  });
}

// ── Close on Escape or Backdrop Click ──
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeReceiptModal();
    closeCollectModal();
  }
});

document.addEventListener('DOMContentLoaded', function() {
  // 1. Rock-solid backdrop click handling (prevents glitchy open/close/reopen)
  ['receiptPrintModal', 'collectFeeModal'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    let mouseDownOnBackdrop = false;

    el.addEventListener('mousedown', function(e) {
      mouseDownOnBackdrop = (e.target === this);
    });

    el.addEventListener('click', function(e) {
      const openedAt = parseInt(el.getAttribute('data-opened-at') || '0', 10);
      // Ignore clicks if modal opened less than 200ms ago (prevents bubbling click glitch)
      if (Date.now() - openedAt < 200) {
        return;
      }
      if (e.target === this && mouseDownOnBackdrop) {
        if (id === 'receiptPrintModal') closeReceiptModal();
        if (id === 'collectFeeModal') closeCollectModal();
      }
      mouseDownOnBackdrop = false;
    });
  });

  // 2. URL-based auto-restore for modals (Fixes "when open if reload the page")
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const receiptParam = urlParams.get('receipt');
    const collectParam = urlParams.get('collect');

    if (receiptParam) {
      const p = Object.values(window.FEES_PAYMENTS_MAP || {}).find(x => x.receipt_no === receiptParam);
      if (p) {
        openReceiptModal(p);
      }
    } else if (collectParam) {
      const stuId = parseInt(collectParam, 10);
      openCollectModal(stuId > 0 ? stuId : null);
    }
  } catch (e) {
    console.warn('Modal URL restore error:', e);
  }
});
</script>

<?php require_once __DIR__ . '/../includes/layout-footer.php'; ?>
