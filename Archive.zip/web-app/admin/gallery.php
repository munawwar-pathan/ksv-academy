<?php
require_once __DIR__ . '/../config.php';

$current_user = require_login(['super_admin', 'admin']);
$page_title = 'Gallery | KSV Academy HRMS';
$page_heading = 'Media Gallery';
$page_subheading = 'Visual Media Archive, Campus Events & Student Life Moments';
$active_menu = 'gallery';

$db = get_db_connection();
$active_session = get_active_session();

// ── Handle Actions ──────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Determine validated redirect target early
    $redirect_view = in_array($_POST['redirect_view'] ?? '', ['table', 'grid'], true) ? $_POST['redirect_view'] : 'table';
    $redirect_status = in_array($_POST['redirect_status'] ?? '', ['all', 'active', 'inactive'], true) ? $_POST['redirect_status'] : 'all';

    // 1. CSRF Token Verification
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash('error', 'Security token invalid or expired. Please refresh the page and try again.');
        header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
        exit;
    }

    $action = trim((string)($_POST['action'] ?? ''));

    // Common gallery file upload validator
    $process_gallery_upload = function($file_field) {
        if (!isset($_FILES[$file_field]) || empty($_FILES[$file_field]['name'])) {
            return ['path' => '', 'error' => ''];
        }
        if ($_FILES[$file_field]['error'] === UPLOAD_ERR_NO_FILE) {
            return ['path' => '', 'error' => ''];
        }
        if ($_FILES[$file_field]['error'] !== UPLOAD_ERR_OK) {
            return ['path' => '', 'error' => 'Error during file upload (Code: ' . intval($_FILES[$file_field]['error']) . ').'];
        }

        $p_name = $_FILES[$file_field]['name'];
        $p_tmp = $_FILES[$file_field]['tmp_name'];
        $p_size = $_FILES[$file_field]['size'];

        // Size limit: 10MB
        if ($p_size > 10 * 1024 * 1024) {
            return ['path' => '', 'error' => 'Uploaded file exceeds the maximum allowed size of 10MB.'];
        }
        if (!is_uploaded_file($p_tmp)) {
            return ['path' => '', 'error' => 'Invalid file upload source.'];
        }

        $p_ext = strtolower(pathinfo($p_name, PATHINFO_EXTENSION));
        $allowed_img_exts = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif'];
        if (!in_array($p_ext, $allowed_img_exts, true)) {
            return ['path' => '', 'error' => 'Invalid file extension. Allowed: JPG, JPEG, PNG, WEBP, AVIF, GIF.'];
        }

        // MIME validation
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $p_tmp) : '';
        if ($finfo) finfo_close($finfo);

        $valid_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif', 'image/heif'];
        if (!in_array($mime, $valid_mimes, true)) {
            return ['path' => '', 'error' => 'Uploaded file is not a supported image format (detected: ' . htmlspecialchars($mime, ENT_QUOTES, 'UTF-8') . ').'];
        }

        // Header integrity check for formats supported by getimagesize
        if (in_array($p_ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
            $img_info = @getimagesize($p_tmp);
            if ($img_info === false) {
                return ['path' => '', 'error' => 'Corrupt or unreadable image file header.'];
            }
        }

        $p_dir = __DIR__ . '/../uploads/gallery';
        if (!is_dir($p_dir)) {
            mkdir($p_dir, 0755, true);
        }

        $filename = 'gal_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $p_ext;
        $dest = $p_dir . '/' . $filename;
        if (move_uploaded_file($p_tmp, $dest)) {
            return ['path' => '/web-app/uploads/gallery/' . $filename, 'error' => ''];
        }
        return ['path' => '', 'error' => 'Could not save the uploaded file to destination directory.'];
    };

    // 1. Add Photo
    if ($action === 'add_photo') {
        $title = mb_substr(trim((string)($_POST['title'] ?? '')), 0, 150);
        $caption = mb_substr(trim((string)($_POST['caption'] ?? '')), 0, 500);
        $category = mb_substr(trim((string)($_POST['category'] ?? 'Smart Classrooms')), 0, 60);
        $sort_order = max(0, min(999999, intval($_POST['sort_order'] ?? 0)));
        $raw_status = strtolower(trim((string)($_POST['status'] ?? 'active')));
        $status = in_array($raw_status, ['active', 'inactive', 'paused'], true) ? (($raw_status === 'paused') ? 'inactive' : $raw_status) : 'active';
        $image = '';

        // Process File Upload
        $upload_res = $process_gallery_upload('image_file');
        if (!empty($upload_res['error'])) {
            set_flash('error', $upload_res['error']);
            header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
            exit;
        }

        if (!empty($upload_res['path'])) {
            $image = $upload_res['path'];
        } elseif (!empty($_POST['selected_existing_file'])) {
            $sel = basename(trim((string)$_POST['selected_existing_file']));
            $allowed_file_exts = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif'];
            $clean_ext = strtolower(pathinfo($sel, PATHINFO_EXTENSION));
            $gal_check_dir = dirname(__DIR__, 2) . '/assets/imgs/gallers';
            if (in_array($clean_ext, $allowed_file_exts, true) && file_exists($gal_check_dir . '/' . $sel)) {
                $image = '/assets/imgs/gallers/' . $sel;
            }
        } elseif (!empty($_POST['image_url'])) {
            $raw_url = trim((string)$_POST['image_url']);
            if (!preg_match('/^(javascript|data|vbscript):/i', $raw_url)) {
                $image = mb_substr($raw_url, 0, 500);
            }
        }

        if (!empty($title) && !empty($image)) {
            $stmt = $db->prepare("INSERT INTO gallery (title, caption, category, image, sort_order, status, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $caption, $category, $image, $sort_order, $status]);
            $status_note = ($status === 'active') ? 'Live on website' : 'Paused';
            set_flash('success', "Media '" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "' added to gallery successfully! ({$status_note})");
        } else {
            set_flash('error', "Please provide both a valid title and an image.");
        }

        header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
        exit;
    }

    // 2. Edit Photo
    if ($action === 'edit_photo') {
        $id = intval($_POST['id'] ?? 0);
        $title = mb_substr(trim((string)($_POST['title'] ?? '')), 0, 150);
        $caption = mb_substr(trim((string)($_POST['caption'] ?? '')), 0, 500);
        $category = mb_substr(trim((string)($_POST['category'] ?? 'Smart Classrooms')), 0, 60);
        $sort_order = max(0, min(999999, intval($_POST['sort_order'] ?? 0)));
        $raw_status = strtolower(trim((string)($_POST['status'] ?? 'active')));
        $status = in_array($raw_status, ['active', 'inactive', 'paused'], true) ? (($raw_status === 'paused') ? 'inactive' : $raw_status) : 'active';
        
        $image = '';
        $raw_current = trim((string)($_POST['current_image'] ?? ''));
        if (!preg_match('/^(javascript|data|vbscript):/i', $raw_current)) {
            $image = mb_substr($raw_current, 0, 500);
        }

        // New File Upload
        $upload_res = $process_gallery_upload('image_file');
        if (!empty($upload_res['error'])) {
            set_flash('error', $upload_res['error']);
            header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
            exit;
        }

        if (!empty($upload_res['path'])) {
            $image = $upload_res['path'];
        } elseif (!empty($_POST['selected_existing_file'])) {
            $sel = basename(trim((string)$_POST['selected_existing_file']));
            $allowed_file_exts = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif'];
            $clean_ext = strtolower(pathinfo($sel, PATHINFO_EXTENSION));
            $gal_check_dir = dirname(__DIR__, 2) . '/assets/imgs/gallers';
            if (in_array($clean_ext, $allowed_file_exts, true) && file_exists($gal_check_dir . '/' . $sel)) {
                $image = '/assets/imgs/gallers/' . $sel;
            }
        } elseif (!empty($_POST['image_url'])) {
            $raw_url = trim((string)$_POST['image_url']);
            if (!preg_match('/^(javascript|data|vbscript):/i', $raw_url)) {
                $image = mb_substr($raw_url, 0, 500);
            }
        }

        if ($id > 0 && !empty($title) && !empty($image)) {
            $stmt = $db->prepare("UPDATE gallery SET title = ?, caption = ?, category = ?, image = ?, sort_order = ?, status = ? WHERE id = ?");
            $stmt->execute([$title, $caption, $category, $image, $sort_order, $status, $id]);
            $status_note = ($status === 'active') ? 'Live on website' : 'Paused';
            set_flash('success', "Gallery media updated successfully! ({$status_note})");
        } else {
            set_flash('error', "Title and image cannot be empty.");
        }

        header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
        exit;
    }

    // 3. Toggle Status (Active / Paused)
    if ($action === 'toggle_status') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            $stmt = $db->prepare("SELECT status, title FROM gallery WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if ($row) {
                $current_status = $row['status'] ?? 'active';
                $new_status = ($current_status === 'active') ? 'inactive' : 'active';
                $upd = $db->prepare("UPDATE gallery SET status = ? WHERE id = ?");
                $upd->execute([$new_status, $id]);
                $safe_title = htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8');
                $msg = ($new_status === 'active') 
                    ? "Media '{$safe_title}' is now Active & Live on website." 
                    : "Media '{$safe_title}' is now Paused (hidden from website).";
                set_flash('success', $msg);
            }
        }
        header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
        exit;
    }

    // 4. Delete Photo
    if ($action === 'delete_photo') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            $stmt = $db->prepare("SELECT image FROM gallery WHERE id = ?");
            $stmt->execute([$id]);
            $item = $stmt->fetch();
            if ($item) {
                // If local uploaded file, delete from disk safely without traversal
                if (strpos($item['image'], '/web-app/uploads/gallery/') === 0) {
                    $clean_file = basename($item['image']);
                    $upload_dir = realpath(__DIR__ . '/../uploads/gallery');
                    if ($upload_dir) {
                        $local_path = $upload_dir . DIRECTORY_SEPARATOR . $clean_file;
                        if (file_exists($local_path) && strpos(realpath($local_path), $upload_dir) === 0) {
                            @unlink($local_path);
                        }
                    }
                }
                $del = $db->prepare("DELETE FROM gallery WHERE id = ?");
                $del->execute([$id]);
                set_flash('success', "Media deleted from gallery.");
            }
        }
        header('Location: ' . ADMIN_URL . '/gallery?status=' . urlencode($redirect_status) . '&view=' . urlencode($redirect_view));
        exit;
    }
}

// ── Query Data ──────────────────────────────────────────────────────────────
$filter_category = mb_substr(trim((string)($_GET['category'] ?? '')), 0, 100);
$raw_status = (string)($_GET['status'] ?? 'all');
$filter_status = in_array($raw_status, ['all', 'active', 'inactive'], true) ? $raw_status : 'all';
$search = mb_substr(trim((string)($_GET['search'] ?? '')), 0, 100);
$raw_view = (string)($_GET['view'] ?? 'table');
$view_mode = in_array($raw_view, ['table', 'grid'], true) ? $raw_view : 'table';

// Scan existing gallery photos in assets/imgs/gallers/
$existing_gallery_files = [];
$gal_dir = dirname(__DIR__, 2) . '/assets/imgs/gallers';
if (is_dir($gal_dir)) {
    $scanned = @scandir($gal_dir);
    if ($scanned) {
        foreach ($scanned as $f) {
            if ($f[0] !== '.' && in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp', 'avif'])) {
                $existing_gallery_files[] = [
                    'name' => $f,
                    'path' => '/assets/imgs/gallers/' . $f
                ];
            }
        }
    }
}

// Pagination Setup (10, 20, 30, 40, 50)
$allowed_limits = [10, 20, 30, 40, 50];
$limit = intval($_GET['limit'] ?? 10);
if (!in_array($limit, $allowed_limits)) {
    $limit = 10;
}
$page = max(1, intval($_GET['page'] ?? 1));

$where_clauses = ["1=1"];
$params = [];

if (!empty($filter_status) && in_array($filter_status, ['active', 'inactive'])) {
    $where_clauses[] = "status = ?";
    $params[] = $filter_status;
}

if (!empty($filter_category) && $filter_category !== 'all') {
    $where_clauses[] = "category = ?";
    $params[] = $filter_category;
}

if (!empty($search)) {
    $where_clauses[] = "(title LIKE ? OR caption LIKE ? OR category LIKE ?)";
    $like_term = "%" . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . "%";
    $params[] = $like_term;
    $params[] = $like_term;
    $params[] = $like_term;
}

$where_sql = implode(' AND ', $where_clauses);

// Count total filtered records
$count_query = "SELECT COUNT(*) FROM gallery WHERE {$where_sql}";
$count_stmt = $db->prepare($count_query);
$count_stmt->execute($params);
$total_records = (int)$count_stmt->fetchColumn();

// Overall status counts
$active_count = (int)$db->query("SELECT COUNT(*) FROM gallery WHERE status = 'active'")->fetchColumn();
$paused_count = (int)$db->query("SELECT COUNT(*) FROM gallery WHERE status = 'inactive'")->fetchColumn();
$total_all_count = (int)$db->query("SELECT COUNT(*) FROM gallery")->fetchColumn();

$total_pages = max(1, ceil($total_records / $limit));
if ($page > $total_pages) {
    $page = $total_pages;
}
$offset = ($page - 1) * $limit;
$start_record = $total_records > 0 ? $offset + 1 : 0;
$end_record = min($offset + $limit, $total_records);

// Fetch paginated records ordered by sort_order then id
$query = "SELECT * FROM gallery WHERE {$where_sql} ORDER BY sort_order ASC, id DESC LIMIT ? OFFSET ?";
$stmt = $db->prepare($query);
$p_idx = 1;
foreach ($params as $param_val) {
    $stmt->bindValue($p_idx++, $param_val);
}
$stmt->bindValue($p_idx++, (int)$limit, PDO::PARAM_INT);
$stmt->bindValue($p_idx++, (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$gallery_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get list of distinct categories for filters
$categories_stmt = $db->query("SELECT category, COUNT(*) as cnt FROM gallery GROUP BY category ORDER BY category ASC");
$category_counts = $categories_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Helper function to build pagination url
function get_gallery_pagination_url($target_page, $filter_category, $filter_status, $search, $view_mode, $limit) {
    $p = [];
    if (!empty($filter_category) && $filter_category !== 'all') $p['category'] = $filter_category;
    if (!empty($filter_status) && $filter_status !== 'all') $p['status'] = $filter_status;
    if (!empty($search)) $p['search'] = $search;
    if ($view_mode !== 'table') $p['view'] = $view_mode;
    if ($limit !== 10) $p['limit'] = $limit;
    if ($target_page > 1) $p['page'] = $target_page;
    $q = !empty($p) ? '?' . http_build_query($p) : '';
    return ADMIN_URL . '/gallery' . $q;
}

// Helper function to return icon for category
function get_category_icon($cat) {
    $c = strtolower(trim((string)$cat));
    if (strpos($c, 'doubt') !== false || strpos($c, 'mentor') !== false) return 'fa-comments';
    if (strpos($c, 'smart') !== false) return 'fa-desktop';
    if (strpos($c, 'class') !== false) return 'fa-chalkboard-user';
    if (strpos($c, 'lib') !== false || strpos($c, 'book') !== false || strpos($c, 'study') !== false) return 'fa-book-open-reader';
    if (strpos($c, 'sport') !== false) return 'fa-trophy';
    if (strpos($c, 'event') !== false) return 'fa-champagne-glasses';
    if (strpos($c, 'acad') !== false || strpos($c, 'sci') !== false) return 'fa-graduation-cap';
    if (strpos($c, 'celeb') !== false) return 'fa-wand-magic-sparkles';
    if (strpos($c, 'camp') !== false) return 'fa-landmark';
    return 'fa-camera';
}

require_once __DIR__ . '/../includes/layout-header.php';
?>

<style>
/* ── Gallery Specific Enhanced Styles ── */
.gallery-status-tabs {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f1f5f9;
  padding: 4px;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
}
.gallery-tab-pill {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 8px 16px;
  border-radius: 10px;
  font-size: 0.82rem;
  font-weight: 700;
  color: #64748b;
  background: transparent;
  border: none;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  text-decoration: none;
  white-space: nowrap;
}
.gallery-tab-pill:hover {
  color: #0f172a;
  background: #f1f5f9;
}
.gallery-tab-pill.active {
  color: #ffffff;
  background: linear-gradient(135deg, #0092df 0%, #0066aa 100%);
  box-shadow: 0 4px 14px rgba(0, 146, 223, 0.3);
}
.gallery-tab-pill .tab-badge {
  font-size: 0.7rem;
  font-weight: 800;
  padding: 2px 7px;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.28);
  color: #ffffff;
}
.gallery-tab-pill:not(.active) .tab-badge {
  background: #e2e8f0;
  color: #475569;
}

/* ── Media Directory Table & Badges (Simple & Sober like Staff ID) ── */
.staff-id-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}
.staff-id-table thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 0.73rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
.staff-id-table tbody td {
  padding: 10px 12px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
  font-size: 0.84rem;
}
.staff-id-table tbody tr {
  transition: background-color 0.15s ease;
}
.staff-id-table tbody tr:hover {
  background-color: #f8fafc;
}

/* Category Badges */
.cat-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 8px;
  border-radius: 5px;
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
}
.cat-pill.campus { background: #f0f9ff; color: #0284c7; border: 1px solid #bae6fd; }
.cat-pill.events { background: #fef3c7; color: #b45309; border: 1px solid #fde68a; }
.cat-pill.sports { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
.cat-pill.academics { background: #faf5ff; color: #7c3aed; border: 1px solid #e9d5ff; }
.cat-pill.celebrations { background: #fff1f2; color: #be123c; border: 1px solid #fecdd3; }
.cat-pill.classrooms { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
.cat-pill.other { background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0; }

/* Status Badges */
.status-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 9px;
  border-radius: 6px;
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.02em;
}
.status-pill.active {
  background: #ecfdf5;
  color: #059669;
  border: 1px solid #a7f3d0;
}
.status-pill.paused {
  background: #fffbeb;
  color: #d97706;
  border: 1px solid #fde68a;
}
[data-theme="dark"] .status-pill.active {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border-color: rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .status-pill.paused {
  background: rgba(245, 158, 11, 0.15) !important;
  color: #fbbf24 !important;
  border-color: rgba(245, 158, 11, 0.3) !important;
}

.gallery-order-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  padding: 2px 7px;
  border-radius: 5px;
  font-size: 0.72rem;
  font-weight: 700;
  background: #f1f5f9;
  color: #334155;
  border: 1px solid #cbd5e1;
}
[data-theme="dark"] .gallery-order-badge {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-color: #334155 !important;
}

.existing-file-thumb {
  width: 76px;
  height: 52px;
  border-radius: 6px;
  overflow: hidden;
  border: 2px solid #cbd5e1;
  cursor: pointer;
  position: relative;
  transition: all 0.2s ease;
  background: #0f172a;
  flex-shrink: 0;
}
.existing-file-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.existing-file-thumb:hover {
  transform: translateY(-2px);
  border-color: #0092df;
}
.existing-file-thumb.selected {
  border-color: #059669;
  box-shadow: 0 0 0 2px rgba(5, 150, 105, 0.4);
}

/* Table Thumbnail */
.gallery-thumb-container {
  width: 58px;
  height: 42px;
  border-radius: 6px;
  overflow: hidden;
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  cursor: pointer;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  transition: all 0.2s ease;
  margin: 0 auto;
}
.gallery-thumb-container:hover {
  transform: scale(1.05);
  border-color: #0284c7;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
.gallery-thumb-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.gallery-thumb-overlay {
  position: absolute;
  inset: 0;
  background: rgba(15, 23, 42, 0.45);
  opacity: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 0.78rem;
  transition: opacity 0.15s ease;
}
.gallery-thumb-container:hover .gallery-thumb-overlay {
  opacity: 1;
}

/* Action Buttons */
.action-btn-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.15s ease;
}
.action-btn-pill.primary {
  background: #0284c7;
  color: #ffffff;
  border: 1px solid #0284c7;
}
.action-btn-pill.primary:hover {
  background: #0369a1;
  border-color: #0369a1;
}
.action-btn-pill.secondary {
  background: #ffffff;
  color: #475569;
  border: 1px solid #cbd5e1;
}
.action-btn-pill.secondary:hover {
  background: #f8fafc;
  color: #0f172a;
  border-color: #94a3b8;
}

/* Grid Cards */
.gallery-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
  gap: 24px;
  margin-bottom: 30px;
}
.gallery-card {
  background: #ffffff;
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid #e2e8f0;
  box-shadow: 0 3px 14px rgba(0,0,0,0.04);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  display: flex;
  flex-direction: column;
}
.gallery-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 16px 32px -8px rgba(15, 23, 42, 0.12);
  border-color: #cbd5e1;
}
.gallery-card-img-wrap {
  width: 100%;
  height: 195px;
  background: #0f172a;
  position: relative;
  overflow: hidden;
  cursor: pointer;
}
.gallery-card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1);
}
.gallery-card:hover .gallery-card-img {
  transform: scale(1.08);
}
.gallery-card-badge {
  position: absolute;
  top: 12px;
  left: 12px;
  z-index: 2;
  box-shadow: 0 4px 10px rgba(0,0,0,0.18);
}
.gallery-card-quick-zoom {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 2;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: rgba(15, 23, 42, 0.55);
  backdrop-filter: blur(6px);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 0.85rem;
  opacity: 0;
  transform: scale(0.9);
  transition: all 0.2s ease;
}
.gallery-card:hover .gallery-card-quick-zoom {
  opacity: 1;
  transform: scale(1);
}
.gallery-card-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, transparent 40%, rgba(15, 23, 42, 0.75) 100%);
  display: flex;
  align-items: flex-end;
  padding: 14px;
  opacity: 0.9;
}
.gallery-card-body {
  padding: 18px 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.gallery-card-title {
  font-size: 0.98rem;
  font-weight: 800;
  color: #0f172a;
  margin: 0 0 6px;
  line-height: 1.35;
  font-family: 'Outfit', sans-serif;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.gallery-card-meta {
  font-size: 0.76rem;
  color: #64748b;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 14px;
}
.gallery-card-actions {
  display: flex;
  gap: 8px;
  border-top: 1px solid #f1f5f9;
  padding-top: 14px;
  justify-content: flex-end;
}

/* Lightbox Modal */
.lightbox-modal {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(10, 15, 25, 0.92);
  backdrop-filter: blur(12px);
  z-index: 2000;
  align-items: center;
  justify-content: center;
  padding: 24px;
}
.lightbox-modal.show {
  display: flex;
}
.lightbox-content {
  max-width: 920px;
  width: 100%;
  background: #0f172a;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 25px 60px -12px rgba(0, 0, 0, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.15);
  animation: modalPop 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}
.lightbox-img-wrap {
  width: 100%;
  max-height: 68vh;
  background: #000000;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.lightbox-img {
  max-width: 100%;
  max-height: 68vh;
  object-fit: contain;
}
.lightbox-footer {
  padding: 16px 24px;
  background: #1e293b;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #ffffff;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
}

/* File Upload Dropzone */
.gallery-dropzone {
  border: 2px dashed #cbd5e1;
  border-radius: 12px;
  padding: 22px 18px;
  text-align: center;
  background: #f8fafc;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
}
.gallery-dropzone:hover {
  border-color: #0092df;
  background: #f0f9ff;
}

/* ══════════════════════════════════════════════════════════════════════
   DARK THEME COMPREHENSIVE ADAPTATIONS FOR MEDIA GALLERY
   ══════════════════════════════════════════════════════════════════════ */

/* 1. Toolbar Card & Controls */
[data-theme="dark"] .gallery-toolbar-card {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-status-tabs {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .gallery-status-tabs .gallery-tab-pill:not(.active) .fa-circle-check {
  color: #34d399 !important;
}
[data-theme="dark"] .gallery-status-tabs .gallery-tab-pill:not(.active) .fa-pause {
  color: #fbbf24 !important;
}
[data-theme="dark"] .gallery-categories-nav {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .gallery-categories-nav::-webkit-scrollbar-thumb {
  background: #475569 !important;
}
[data-theme="dark"] .gallery-nav-scroll-btn {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4) !important;
}
[data-theme="dark"] .gallery-nav-scroll-btn:hover {
  background: #0092df !important;
  border-color: #0092df !important;
  color: #ffffff !important;
}
[data-theme="dark"] .gallery-tab-pill {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-tab-pill:hover {
  background: #1e293b !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-tab-pill.active {
  background: linear-gradient(135deg, #0092df 0%, #0066aa 100%) !important;
  color: #ffffff !important;
  box-shadow: 0 4px 14px rgba(0, 146, 223, 0.35) !important;
}
[data-theme="dark"] .gallery-tab-pill:not(.active) .tab-badge {
  background: #1e293b !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .gallery-tab-pill.active .tab-badge {
  background: rgba(255, 255, 255, 0.28) !important;
  color: #ffffff !important;
}

/* Toolbar Search & View Switcher */
[data-theme="dark"] .gallery-search-input {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-search-input:focus {
  border-color: #0092df !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .gallery-search-input::placeholder {
  color: #64748b !important;
}
[data-theme="dark"] .gallery-search-icon {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-search-clear {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-search-clear:hover {
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-view-switcher {
  background: #0f172a !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .gallery-view-switcher .action-btn-pill.secondary {
  background: transparent !important;
  color: #94a3b8 !important;
  border: none !important;
}
[data-theme="dark"] .gallery-view-switcher .action-btn-pill.secondary:hover {
  color: #f8fafc !important;
  background: #1e293b !important;
}
[data-theme="dark"] .gallery-view-switcher .action-btn-pill.primary {
  background: #0092df !important;
  color: #ffffff !important;
  border: none !important;
}

/* 2. Category Badges */
[data-theme="dark"] .cat-pill {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .cat-pill.campus {
  background: rgba(2, 132, 199, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(2, 132, 199, 0.3) !important;
}
[data-theme="dark"] .cat-pill.events {
  background: rgba(245, 158, 11, 0.15) !important;
  color: #fbbf24 !important;
  border: 1px solid rgba(245, 158, 11, 0.3) !important;
}
[data-theme="dark"] .cat-pill.sports {
  background: rgba(16, 185, 129, 0.15) !important;
  color: #34d399 !important;
  border: 1px solid rgba(16, 185, 129, 0.3) !important;
}
[data-theme="dark"] .cat-pill.academics {
  background: rgba(124, 58, 237, 0.15) !important;
  color: #a78bfa !important;
  border: 1px solid rgba(124, 58, 237, 0.3) !important;
}
[data-theme="dark"] .cat-pill.celebrations {
  background: rgba(244, 63, 94, 0.15) !important;
  color: #fb7185 !important;
  border: 1px solid rgba(244, 63, 94, 0.3) !important;
}
[data-theme="dark"] .cat-pill.classrooms {
  background: rgba(37, 99, 235, 0.15) !important;
  color: #60a5fa !important;
  border: 1px solid rgba(37, 99, 235, 0.3) !important;
}
[data-theme="dark"] .cat-pill.other {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border: 1px solid #334155 !important;
}

/* 3. Empty State Card */
[data-theme="dark"] .hrms-card[style*="text-align: center"] {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .hrms-card[style*="text-align: center"] div[style*="border-radius: 50%"] {
  background: #0f172a !important;
  color: #64748b !important;
  border: 1px solid #334155 !important;
}
[data-theme="dark"] .hrms-card[style*="text-align: center"] h3 {
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-card[style*="text-align: center"] p {
  color: #94a3b8 !important;
}

/* 4. Visual Card Grid View */
[data-theme="dark"] .gallery-card {
  background: #1e293b !important;
  border-color: #334155 !important;
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.25) !important;
}
[data-theme="dark"] .gallery-card:hover {
  border-color: #475569 !important;
  box-shadow: 0 16px 32px rgba(0, 0, 0, 0.45) !important;
}
[data-theme="dark"] .gallery-card-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-card-meta {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-card-actions {
  border-top-color: #334155 !important;
}
[data-theme="dark"] .gallery-grid + .hrms-card {
  background: #1e293b !important;
  border-color: #334155 !important;
}

/* 5. Directory Table View */
[data-theme="dark"] .gallery-table-card {
  background: #1e293b !important;
  border-color: #334155 !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25) !important;
}
[data-theme="dark"] .gallery-table-header {
  background: #1e293b !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .gallery-table-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-table-subtitle {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-total-badge {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .gallery-table thead th {
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .gallery-table tbody td {
  border-bottom-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .gallery-table tbody tr:hover {
  background-color: rgba(255, 255, 255, 0.02) !important;
}
[data-theme="dark"] .gallery-thumb-container {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-table td div[style*="#0f172a"] {
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-table td div[style*="#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-table td span[style*="#475569"] {
  color: #cbd5e1 !important;
}
[data-theme="dark"] .gallery-table td .fa-images {
  color: #64748b !important;
}

/* Action Button Pills */
[data-theme="dark"] .action-btn-pill.primary {
  background: #0284c7 !important;
  border-color: #0284c7 !important;
  color: #ffffff !important;
}
[data-theme="dark"] .action-btn-pill.primary:hover {
  background: #0369a1 !important;
  border-color: #0369a1 !important;
}
[data-theme="dark"] .action-btn-pill.secondary {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .action-btn-pill.secondary:hover {
  background: #1e293b !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .action-btn-pill.secondary[style*="#dc2626"] {
  background: rgba(220, 38, 38, 0.12) !important;
  border-color: rgba(220, 38, 38, 0.3) !important;
  color: #f87171 !important;
}
[data-theme="dark"] .action-btn-pill.secondary[style*="#dc2626"]:hover {
  background: #dc2626 !important;
  border-color: #dc2626 !important;
  color: #ffffff !important;
}

/* Pagination Controls */
[data-theme="dark"] .pagination-controls-wrap {
  border-top-color: #334155 !important;
}
[data-theme="dark"] .pagination-meta-group span {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-meta-group span strong {
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-limit-box label {
  color: #94a3b8 !important;
}
[data-theme="dark"] .pagination-limit-select {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .pagination-btn:hover:not(.disabled) {
  background: #1e293b !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .pagination-btn.active {
  background: #0092df !important;
  border-color: #0092df !important;
  color: #ffffff !important;
}
[data-theme="dark"] .pagination-btn.disabled {
  opacity: 0.35 !important;
}
[data-theme="dark"] .pagination-ellipsis {
  color: #64748b !important;
}

/* 6. Modals (Add, Edit, Lightbox) */
[data-theme="dark"] .hrms-modal-card {
  background: #1e293b !important;
  border-color: #334155 !important;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5) !important;
}
[data-theme="dark"] .hrms-modal-header {
  background: #1e293b !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .hrms-modal-header h3 {
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-modal-header span[style*="#64748b"] {
  color: #94a3b8 !important;
}
[data-theme="dark"] .modal-close-btn {
  color: #94a3b8 !important;
  background: transparent !important;
}
[data-theme="dark"] .modal-close-btn:hover {
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-modal-body label {
  color: #cbd5e1 !important;
}
[data-theme="dark"] .hrms-modal-body .form-control {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .hrms-modal-body .form-control:focus {
  border-color: #0092df !important;
  box-shadow: 0 0 0 3px rgba(0, 146, 223, 0.2) !important;
}
[data-theme="dark"] .hrms-modal-body select.form-control option {
  background: #0f172a !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-dropzone {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-dropzone:hover {
  background: #1e293b !important;
  border-color: #0092df !important;
}
[data-theme="dark"] .gallery-dropzone-title {
  color: #f8fafc !important;
}
[data-theme="dark"] .gallery-dropzone-sub {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-live-preview-box {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-live-preview-hint {
  color: #94a3b8 !important;
}
[data-theme="dark"] .gallery-current-preview-box {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-current-label {
  color: #f8fafc !important;
}
[data-theme="dark"] #edit_preview_img {
  border-color: #334155 !important;
}
[data-theme="dark"] .gallery-current-hint {
  color: #94a3b8 !important;
}
[data-theme="dark"] .hrms-modal-body form > div:last-child {
  border-top-color: #334155 !important;
}
[data-theme="dark"] .roaster-btn.secondary {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .roaster-btn.secondary:hover {
  background: #1e293b !important;
  border-color: #475569 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .lightbox-footer .action-btn-pill.secondary {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #cbd5e1 !important;
}
[data-theme="dark"] .lightbox-footer .action-btn-pill.secondary:hover {
  background: #334155 !important;
  color: #f8fafc !important;
}
</style>

<!-- ══════════════════════════════════════════════════════
     TOP TOOLBAR CARD & CONTROLS
     ══════════════════════════════════════════════════════ -->
<div class="roaster-toolbar-card gallery-toolbar-card no-print" style="margin-bottom: 24px;">
  <div class="roaster-toolbar-inner gallery-toolbar-inner" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
    
    <!-- Left: Status & Category Pills with Scroll Controls -->
    <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap; flex: 1; min-width: 300px;">
      
      <!-- 1. Status Filter Pills (All, Active, Paused) -->
      <div class="gallery-status-tabs" style="display: inline-flex; align-items: center; gap: 4px; padding: 4px; border-radius: 12px;">
        <a href="?status=all<?php echo !empty($filter_category) ? '&category=' . urlencode($filter_category) : ''; ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
           class="gallery-tab-pill <?php echo ($filter_status === 'all' || empty($filter_status)) ? 'active' : ''; ?>" style="padding: 6px 12px; font-size: 0.78rem;">
          <i class="fa-solid fa-layer-group"></i>
          <span>All</span>
          <span class="tab-badge"><?php echo $total_all_count; ?></span>
        </a>
        <a href="?status=active<?php echo !empty($filter_category) ? '&category=' . urlencode($filter_category) : ''; ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
           class="gallery-tab-pill <?php echo $filter_status === 'active' ? 'active' : ''; ?>" style="padding: 6px 12px; font-size: 0.78rem;">
          <i class="fa-solid fa-circle-check" style="<?php echo $filter_status === 'active' ? 'color:#fff;' : 'color:#059669;'; ?>"></i>
          <span>Live</span>
          <span class="tab-badge"><?php echo $active_count; ?></span>
        </a>
        <a href="?status=inactive<?php echo !empty($filter_category) ? '&category=' . urlencode($filter_category) : ''; ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
           class="gallery-tab-pill <?php echo $filter_status === 'inactive' ? 'active' : ''; ?>" style="padding: 6px 12px; font-size: 0.78rem;">
          <i class="fa-solid fa-pause" style="<?php echo $filter_status === 'inactive' ? 'color:#fff;' : 'color:#d97706;'; ?>"></i>
          <span>Paused</span>
          <span class="tab-badge"><?php echo $paused_count; ?></span>
        </a>
      </div>

      <!-- 2. Category Nav with Left/Right Buttons -->
      <div class="gallery-categories-wrapper" style="flex: 1; min-width: 220px;">
        <button type="button" class="gallery-nav-scroll-btn left" aria-label="Scroll categories left" title="Scroll left">
          <i class="fa-solid fa-chevron-left"></i>
        </button>

        <div class="gallery-categories-nav">
          <a href="?category=all&status=<?php echo urlencode($filter_status); ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
             class="gallery-tab-pill <?php echo (empty($filter_category) || $filter_category === 'all') ? 'active' : ''; ?>">
            <i class="fa-solid fa-tags"></i>
            <span>All Categories</span>
          </a>

          <?php foreach ($category_counts as $cat_name => $count): ?>
            <?php $cat_icon = get_category_icon($cat_name); ?>
            <a href="?category=<?php echo urlencode($cat_name); ?>&status=<?php echo urlencode($filter_status); ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
               class="gallery-tab-pill <?php echo $filter_category === $cat_name ? 'active' : ''; ?>">
              <i class="fa-solid <?php echo $cat_icon; ?>"></i>
              <span><?php echo htmlspecialchars($cat_name); ?></span>
              <span class="tab-badge"><?php echo $count; ?></span>
            </a>
          <?php endforeach; ?>
        </div>

        <button type="button" class="gallery-nav-scroll-btn right" aria-label="Scroll categories right" title="Scroll right">
          <i class="fa-solid fa-chevron-right"></i>
        </button>
      </div>

    </div>

    <!-- Right: Search, View Switcher & Add Button -->
    <div class="gallery-toolbar-right" style="display: flex; align-items: center; gap: 10px;">
      
      <!-- Search Form -->
      <form method="GET" action="<?php echo ADMIN_URL; ?>/gallery" class="gallery-search-form">
        <?php if (!empty($filter_status) && $filter_status !== 'all'): ?>
          <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
        <?php endif; ?>
        <?php if (!empty($filter_category)): ?>
          <input type="hidden" name="category" value="<?php echo htmlspecialchars($filter_category); ?>">
        <?php endif; ?>
        <input type="hidden" name="view" value="<?php echo htmlspecialchars($view_mode); ?>">
        <?php if ($limit !== 10): ?>
          <input type="hidden" name="limit" value="<?php echo $limit; ?>">
        <?php endif; ?>
        
        <i class="fa-solid fa-magnifying-glass gallery-search-icon"></i>
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search title or caption..." class="gallery-search-input">
        <?php if (!empty($search)): ?>
          <a href="?status=<?php echo urlencode($filter_status); ?>&category=<?php echo urlencode($filter_category); ?>&view=<?php echo urlencode($view_mode); ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" class="gallery-search-clear" title="Clear search">&times;</a>
        <?php endif; ?>
      </form>

      <div class="gallery-toolbar-actions-group">
        <!-- View Switcher -->
        <div class="gallery-view-switcher">
          <a href="?view=table&status=<?php echo urlencode($filter_status); ?><?php echo !empty($filter_category) ? '&category=' . urlencode($filter_category) : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
             class="action-btn-pill <?php echo $view_mode === 'table' ? 'primary' : 'secondary'; ?>" title="Table View">
            <i class="fa-solid fa-table-list"></i>
            <span>Table</span>
          </a>
          <a href="?view=grid&status=<?php echo urlencode($filter_status); ?><?php echo !empty($filter_category) ? '&category=' . urlencode($filter_category) : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?><?php echo $limit !== 10 ? '&limit=' . $limit : ''; ?>" 
             class="action-btn-pill <?php echo $view_mode === 'grid' ? 'primary' : 'secondary'; ?>" title="Grid View">
            <i class="fa-solid fa-grip"></i>
            <span>Grid</span>
          </a>
        </div>

        <!-- Upload Button -->
        <button type="button" onclick="openAddModal();" class="roaster-add-btn gallery-upload-btn" title="Add Photo to Gallery">
          <div class="btn-icon-circle"><i class="fa-solid fa-plus"></i></div>
          <span>Upload Photo</span>
        </button>
      </div>

    </div>

  </div>
</div>

<?php if (empty($gallery_items)): ?>
  <!-- Empty State -->
  <div class="hrms-card" style="text-align: center; padding: 60px 20px; margin-bottom: 30px; border-radius: 14px;">
    <div style="width: 64px; height: 64px; border-radius: 50%; background: #f1f5f9; color: #94a3b8; display: inline-flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 16px;">
      <i class="fa-solid fa-images"></i>
    </div>
    <h3 style="font-size: 1.15rem; font-weight: 800; color: #0f172a; margin: 0 0 6px; font-family: 'Outfit', sans-serif;">
      No Gallery Photos Found
    </h3>
    <p style="font-size: 0.85rem; color: #64748b; max-width: 440px; margin: 0 auto 20px;">
      <?php if (!empty($search) || !empty($filter_category) || ($filter_status !== 'all' && !empty($filter_status))): ?>
        No photos match your current search or status/category filters. Try resetting filters or uploading a new image.
      <?php else: ?>
        There are currently no media items in your school gallery. Start showcasing campus moments by uploading photos!
      <?php endif; ?>
    </p>
    <button type="button" onclick="openAddModal();" class="roaster-add-btn" style="display: inline-flex;">
      <div class="btn-icon-circle"><i class="fa-solid fa-plus"></i></div>
      <span>Upload First Photo</span>
    </button>
  </div>
<?php else: ?>

  <?php if ($view_mode === 'grid'): ?>
    <!-- ══════════════════════════════════════════════════════
         VIEW MODE 1: VISUAL CARD GRID
         ══════════════════════════════════════════════════════ -->
    <div class="gallery-grid">
      <?php foreach ($gallery_items as $item): ?>
        <?php
          $cat_key = strtolower(trim($item['category'] ?? ''));
          $badge_class = 'other';
          if (strpos($cat_key, 'camp') !== false) $badge_class = 'campus';
          elseif (strpos($cat_key, 'event') !== false) $badge_class = 'events';
          elseif (strpos($cat_key, 'sport') !== false) $badge_class = 'sports';
          elseif (strpos($cat_key, 'acad') !== false) $badge_class = 'academics';
          elseif (strpos($cat_key, 'celeb') !== false) $badge_class = 'celebrations';
          elseif (strpos($cat_key, 'class') !== false) $badge_class = 'classrooms';
          $icon_class = get_category_icon($item['category'] ?? '');
          $is_active = (($item['status'] ?? 'active') === 'active');
        ?>
        <div class="gallery-card">
          <div class="gallery-card-img-wrap" onclick="openLightbox(<?php echo htmlspecialchars(json_encode($item['image']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['title']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['category']), ENT_QUOTES, 'UTF-8'); ?>)">
            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="gallery-card-img" onerror="this.src='/assets/imgs/ksv-logo.png'">
            
            <div class="gallery-card-badge" style="display: flex; gap: 6px; align-items: center;">
              <span class="cat-pill <?php echo $badge_class; ?>">
                <i class="fa-solid <?php echo $icon_class; ?>"></i>
                <?php echo htmlspecialchars($item['category']); ?>
              </span>
              <span class="gallery-order-badge" title="Sort Order">
                #<?php echo intval($item['sort_order']); ?>
              </span>
            </div>

            <!-- Top Right Status Pill -->
            <div style="position: absolute; top: 12px; right: 12px; z-index: 2;">
              <?php if ($is_active): ?>
                <span class="status-pill active" title="Active on website">
                  <i class="fa-solid fa-circle-check"></i> Live
                </span>
              <?php else: ?>
                <span class="status-pill paused" title="Paused (hidden from website)">
                  <i class="fa-solid fa-pause"></i> Paused
                </span>
              <?php endif; ?>
            </div>

            <div class="gallery-card-overlay">
              <span style="color: #ffffff; font-size: 0.78rem; font-weight: 700; display: flex; align-items: center; gap: 5px;">
                <i class="fa-solid fa-magnifying-glass-plus"></i> Click to preview
              </span>
            </div>
          </div>

          <div class="gallery-card-body">
            <div>
              <h4 class="gallery-card-title"><?php echo htmlspecialchars($item['title']); ?></h4>
              <?php if (!empty($item['caption'])): ?>
                <p style="font-size: 0.78rem; color: #64748b; line-height: 1.4; margin: 4px 0 8px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                  <?php echo htmlspecialchars($item['caption']); ?>
                </p>
              <?php endif; ?>
              <div class="gallery-card-meta">
                <i class="fa-regular fa-calendar-check" style="color: #94a3b8;"></i>
                <span><?php echo date('d M Y, h:i A', strtotime($item['created_at'])); ?></span>
              </div>
            </div>

            <div class="gallery-card-actions" style="display: flex; justify-content: space-between; align-items: center;">
              <!-- Toggle Active / Pause Form -->
              <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" style="display: inline; margin: 0;">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                <input type="hidden" name="action" value="toggle_status">
                <input type="hidden" name="id" value="<?php echo intval($item['id']); ?>">
                <input type="hidden" name="redirect_view" value="grid">
                <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">
                <?php if ($is_active): ?>
                  <button type="submit" class="action-btn-pill secondary" style="padding: 5px 10px; font-size: 0.74rem; color: #b45309; border-color: #fde68a; background: #fffbeb;" title="Pause Media (Hide from website)">
                    <i class="fa-solid fa-pause"></i>
                    <span>Pause</span>
                  </button>
                <?php else: ?>
                  <button type="submit" class="action-btn-pill secondary" style="padding: 5px 10px; font-size: 0.74rem; color: #047857; border-color: #a7f3d0; background: #ecfdf5;" title="Activate Media (Show on website)">
                    <i class="fa-solid fa-play"></i>
                    <span>Activate</span>
                  </button>
                <?php endif; ?>
              </form>

              <div style="display: flex; gap: 6px;">
                <button type="button" onclick="openLightbox(<?php echo htmlspecialchars(json_encode($item['image']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['title']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['category']), ENT_QUOTES, 'UTF-8'); ?>)" class="action-btn-pill secondary" style="padding: 6px 10px; font-size: 0.76rem;" title="View Preview">
                  <i class="fa-solid fa-eye"></i>
                </button>

                <button type="button" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($item), ENT_QUOTES, 'UTF-8'); ?>);" class="action-btn-pill primary" style="padding: 6px 12px; font-size: 0.76rem;" title="Edit Media Details">
                  <i class="fa-solid fa-pen-to-square"></i>
                  <span>Edit</span>
                </button>

                <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" style="display: inline; margin: 0;" onsubmit="return confirm('Are you sure you want to delete \'<?php echo htmlspecialchars(addslashes($item['title']), ENT_QUOTES, 'UTF-8'); ?>\'?');">
                  <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                  <input type="hidden" name="action" value="delete_photo">
                  <input type="hidden" name="id" value="<?php echo intval($item['id']); ?>">
                  <input type="hidden" name="redirect_view" value="grid">
                  <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">
                  <button type="submit" class="action-btn-pill secondary" style="padding: 6px 10px; font-size: 0.76rem; color: #dc2626; border-color: #fecdd3;" title="Delete Media">
                    <i class="fa-solid fa-trash-can"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Grid View Footer Pagination & Per-Page Controls -->
    <div class="hrms-card no-print" style="margin-top: 24px; margin-bottom: 30px; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 18px rgba(0,0,0,0.04); border: 1px solid #e2e8f0;">
      <div class="pagination-controls-wrap">
        
        <!-- Left: Showing summary & Limit Selector -->
        <div class="pagination-meta-group">
          <span style="font-size: 0.82rem; color: #475569;">
            <?php if ($total_records > 0): ?>
              Showing <strong><?php echo $start_record; ?></strong>–<strong><?php echo $end_record; ?></strong> of <strong><?php echo $total_records; ?></strong> <?php echo $total_records === 1 ? 'photo' : 'photos'; ?>
            <?php else: ?>
              Showing <strong>0</strong> photos
            <?php endif; ?>
          </span>

          <div class="pagination-limit-box">
            <label for="perPageLimitSelectGrid" style="color: #64748b; font-size: 0.8rem; margin: 0; font-weight: 500;">Show Per Page</label>
            <select id="perPageLimitSelectGrid" class="pagination-limit-select" onchange="window.location.href = this.value;">
              <?php foreach ($allowed_limits as $l): ?>
                <option value="<?php echo htmlspecialchars(get_gallery_pagination_url(1, $filter_category, $search, $view_mode, $l)); ?>" <?php echo $limit === $l ? 'selected' : ''; ?>>
                  <?php echo $l; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Center/Right: Navigation page buttons -->
        <?php if ($total_pages > 1): ?>
          <nav class="pagination-nav" aria-label="Media Gallery Grid Pagination">
            <!-- Prev Page -->
            <a href="<?php echo $page > 1 ? htmlspecialchars(get_gallery_pagination_url($page - 1, $filter_category, $search, $view_mode, $limit)) : '#'; ?>" 
               class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" 
               aria-label="Previous Page"
               title="Previous Page">
              <i class="fa-solid fa-chevron-left" style="font-size: 0.72rem;"></i>
            </a>

            <!-- Page Numbers -->
            <?php
              $range = 2;
              for ($p = 1; $p <= $total_pages; $p++):
                if ($p == 1 || $p == $total_pages || ($p >= $page - $range && $p <= $page + $range)):
            ?>
              <a href="<?php echo htmlspecialchars(get_gallery_pagination_url($p, $filter_category, $search, $view_mode, $limit)); ?>" 
                 class="pagination-btn <?php echo $p === $page ? 'active' : ''; ?>">
                <?php echo $p; ?>
              </a>
            <?php 
                elseif (($p == 2 && $page - $range > 2) || ($p == $total_pages - 1 && $page + $range < $total_pages - 1)):
            ?>
              <span class="pagination-ellipsis">&hellip;</span>
            <?php 
                endif;
              endfor; 
            ?>

            <!-- Next Page -->
            <a href="<?php echo $page < $total_pages ? htmlspecialchars(get_gallery_pagination_url($page + 1, $filter_category, $search, $view_mode, $limit)) : '#'; ?>" 
               class="pagination-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>" 
               aria-label="Next Page"
               title="Next Page">
              <i class="fa-solid fa-chevron-right" style="font-size: 0.72rem;"></i>
            </a>
          </nav>
        <?php endif; ?>

      </div>
    </div>

  <?php else: ?>
    <!-- ══════════════════════════════════════════════════════
         VIEW MODE 2: DIRECTORY TABLE (Default)
         ══════════════════════════════════════════════════════ -->
    <div class="hrms-card gallery-table-card" style="margin-bottom: 24px; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.03); border: 1px solid #e2e8f0;">
      
      <div class="hrms-card-header gallery-table-header" style="border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 14px 18px;">
        <div>
          <h3 class="card-title gallery-table-title" style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 0.95rem; font-weight: 700; color: #0f172a; font-family: 'Outfit', sans-serif;">
            <i class="fa-solid fa-images" style="color: #0284c7;"></i>
            Media Directory &amp; Photo Records
          </h3>
          <p class="gallery-table-subtitle" style="margin: 3px 0 0; font-size: 0.78rem; color: #64748b;">
            Manage and catalog all campus photography, event archives, and visual records.
          </p>
        </div>

        <div style="display: flex; align-items: center; gap: 8px;">
          <span class="gallery-total-badge" style="display: inline-flex; align-items: center; gap: 5px; font-size: 0.74rem; font-weight: 600; color: #475569; background: #f8fafc; padding: 3px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
            <i class="fa-solid fa-photo-film" style="color: #0284c7; font-size: 0.72rem;"></i>
            <?php echo $total_records; ?> Total Photos
          </span>
        </div>
      </div>

      <div class="table-responsive gallery-table-responsive">
        <table class="hrms-table staff-id-table gallery-table">
          <thead>
            <tr>
              <th style="width: 76px; text-align: center;">Photo</th>
              <th style="min-width: 220px;">Title &amp; Subtitle</th>
              <th style="min-width: 140px;">Category</th>
              <th style="width: 75px; text-align: center;">Order</th>
              <th style="width: 135px; text-align: center;">Status</th>
              <th style="min-width: 120px;">Uploaded</th>
              <th style="text-align: right; width: 130px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($gallery_items)): ?>
              <tr>
                <td colspan="7" style="text-align: center; color: #94a3b8; padding: 36px 20px;">
                  <i class="fa-regular fa-images" style="font-size: 2rem; color: #cbd5e1; display: block; margin-bottom: 8px;"></i>
                  <span>No media records found matching current filter.</span>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($gallery_items as $item): ?>
                <?php
                  $cat_key = strtolower(trim($item['category'] ?? ''));
                  $badge_class = 'other';
                  if (strpos($cat_key, 'camp') !== false) $badge_class = 'campus';
                  elseif (strpos($cat_key, 'event') !== false) $badge_class = 'events';
                  elseif (strpos($cat_key, 'sport') !== false) $badge_class = 'sports';
                  elseif (strpos($cat_key, 'acad') !== false) $badge_class = 'academics';
                  elseif (strpos($cat_key, 'celeb') !== false) $badge_class = 'celebrations';
                  elseif (strpos($cat_key, 'class') !== false) $badge_class = 'classrooms';
                  $icon_class = get_category_icon($item['category'] ?? '');
                  $is_active = (($item['status'] ?? 'active') === 'active');
                ?>
                <tr>
                  <!-- 1. Image Thumbnail -->
                  <td style="text-align: center;">
                    <div class="gallery-thumb-container" onclick="openLightbox(<?php echo htmlspecialchars(json_encode($item['image']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['title']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['category']), ENT_QUOTES, 'UTF-8'); ?>)" title="Click to view full preview">
                      <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="gallery-thumb-img" onerror="this.src='/assets/imgs/ksv-logo.png'">
                      <div class="gallery-thumb-overlay">
                        <i class="fa-solid fa-magnifying-glass-plus"></i>
                      </div>
                    </div>
                  </td>

                  <!-- 2. Title & Caption -->
                  <td>
                    <div style="font-weight: 700; font-size: 0.88rem; color: #0f172a; font-family: 'Outfit', sans-serif;">
                      <?php echo htmlspecialchars($item['title']); ?>
                    </div>
                    <?php if (!empty($item['caption'])): ?>
                      <div style="font-size: 0.76rem; color: #64748b; margin-top: 2px;">
                        <?php echo htmlspecialchars($item['caption']); ?>
                      </div>
                    <?php endif; ?>
                    <div style="font-size: 0.70rem; color: #94a3b8; margin-top: 2px;">
                      Path: <code><?php echo htmlspecialchars(substr($item['image'], 0, 36) . (strlen($item['image']) > 36 ? '...' : '')); ?></code>
                    </div>
                  </td>

                  <!-- 3. Category -->
                  <td>
                    <span class="cat-pill <?php echo $badge_class; ?>">
                      <i class="fa-solid <?php echo $icon_class; ?>"></i>
                      <?php echo htmlspecialchars($item['category']); ?>
                    </span>
                  </td>

                  <!-- 4. Sort Order -->
                  <td style="text-align: center;">
                    <span class="gallery-order-badge" title="Sort Order on Homepage &amp; Gallery">
                      #<?php echo intval($item['sort_order']); ?>
                    </span>
                  </td>

                  <!-- 5. Status & Quick Toggle -->
                  <td style="text-align: center;">
                    <div style="display: inline-flex; align-items: center; gap: 6px;">
                      <?php if ($is_active): ?>
                        <span class="status-pill active" title="Active • Visible on Homepage &amp; Gallery">
                          <i class="fa-solid fa-circle-check"></i> Live
                        </span>
                      <?php else: ?>
                        <span class="status-pill paused" title="Paused • Hidden from website">
                          <i class="fa-solid fa-pause"></i> Paused
                        </span>
                      <?php endif; ?>

                      <!-- Quick Toggle Button -->
                      <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" style="display: inline; margin: 0;">
                        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                        <input type="hidden" name="action" value="toggle_status">
                        <input type="hidden" name="id" value="<?php echo intval($item['id']); ?>">
                        <input type="hidden" name="redirect_view" value="table">
                        <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">
                        <button type="submit" class="action-btn-pill secondary" style="padding: 3px 6px; font-size: 0.7rem;" title="<?php echo $is_active ? 'Click to Pause' : 'Click to Activate'; ?>">
                          <i class="fa-solid <?php echo $is_active ? 'fa-pause' : 'fa-play'; ?>" style="color: <?php echo $is_active ? '#d97706' : '#059669'; ?>;"></i>
                        </button>
                      </form>
                    </div>
                  </td>

                  <!-- 6. Uploaded Date -->
                  <td>
                    <span style="font-size: 0.80rem; color: #475569; font-weight: 500; display: inline-flex; align-items: center; gap: 5px;">
                      <i class="fa-regular fa-calendar" style="color: #94a3b8; font-size: 0.72rem;"></i>
                      <?php echo date('d M Y', strtotime($item['created_at'])); ?>
                    </span>
                  </td>

                  <!-- 7. Actions -->
                  <td style="text-align: right;">
                    <div style="display: flex; gap: 5px; justify-content: flex-end; align-items: center;">
                      <button type="button" onclick="openLightbox(<?php echo htmlspecialchars(json_encode($item['image']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['title']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($item['category']), ENT_QUOTES, 'UTF-8'); ?>)" class="action-btn-pill secondary" style="padding: 4px 8px;" title="Preview Photo">
                        <i class="fa-solid fa-eye" style="font-size: 0.72rem;"></i>
                      </button>

                      <button type="button" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($item), ENT_QUOTES, 'UTF-8'); ?>);" class="action-btn-pill primary" style="padding: 4px 8px;" title="Edit Media Details">
                        <i class="fa-solid fa-pencil" style="font-size: 0.72rem;"></i>
                      </button>

                      <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" style="display: inline; margin: 0;" onsubmit="return confirm('Delete \'<?php echo htmlspecialchars(addslashes($item['title']), ENT_QUOTES, 'UTF-8'); ?>\' from gallery?');">
                        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                        <input type="hidden" name="action" value="delete_photo">
                        <input type="hidden" name="id" value="<?php echo intval($item['id']); ?>">
                        <input type="hidden" name="redirect_view" value="table">
                        <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">
                        <button type="submit" class="action-btn-pill secondary" style="padding: 4px 8px; color: #dc2626; border-color: #fecdd3;" title="Delete Photo">
                          <i class="fa-solid fa-trash-can" style="font-size: 0.72rem;"></i>
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Table Footer Pagination & Per-Page Controls (Matches HRMS standard) -->
      <div class="pagination-controls-wrap">
        
        <!-- Left: Showing summary & Limit Selector -->
        <div class="pagination-meta-group">
          <span style="font-size: 0.82rem; color: #475569;">
            <?php if ($total_records > 0): ?>
              Showing <strong><?php echo $start_record; ?></strong>–<strong><?php echo $end_record; ?></strong> of <strong><?php echo $total_records; ?></strong> <?php echo $total_records === 1 ? 'photo' : 'photos'; ?>
            <?php else: ?>
              Showing <strong>0</strong> photos
            <?php endif; ?>
          </span>

          <div class="pagination-limit-box">
            <label for="perPageLimitSelectTable" style="color: #64748b; font-size: 0.8rem; margin: 0; font-weight: 500;">Show Per Page</label>
            <select id="perPageLimitSelectTable" class="pagination-limit-select" onchange="window.location.href = this.value;">
              <?php foreach ($allowed_limits as $l): ?>
                <option value="<?php echo htmlspecialchars(get_gallery_pagination_url(1, $filter_category, $filter_status, $search, $view_mode, $l)); ?>" <?php echo $limit === $l ? 'selected' : ''; ?>>
                  <?php echo $l; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Center/Right: Navigation page buttons -->
        <?php if ($total_pages > 1): ?>
          <nav class="pagination-nav" aria-label="Media Gallery Table Pagination">
            <!-- Prev Page -->
            <a href="<?php echo $page > 1 ? htmlspecialchars(get_gallery_pagination_url($page - 1, $filter_category, $filter_status, $search, $view_mode, $limit)) : '#'; ?>" 
               class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" 
               aria-label="Previous Page"
               title="Previous Page">
              <i class="fa-solid fa-chevron-left" style="font-size: 0.72rem;"></i>
            </a>

            <!-- Page Numbers -->
            <?php
              $range = 2;
              for ($p = 1; $p <= $total_pages; $p++):
                if ($p == 1 || $p == $total_pages || ($p >= $page - $range && $p <= $page + $range)):
            ?>
              <a href="<?php echo htmlspecialchars(get_gallery_pagination_url($p, $filter_category, $filter_status, $search, $view_mode, $limit)); ?>" 
                 class="pagination-btn <?php echo $p === $page ? 'active' : ''; ?>">
                <?php echo $p; ?>
              </a>
            <?php 
                elseif (($p == 2 && $page - $range > 2) || ($p == $total_pages - 1 && $page + $range < $total_pages - 1)):
            ?>
              <span class="pagination-ellipsis">&hellip;</span>
            <?php 
                endif;
              endfor; 
            ?>

            <!-- Next Page -->
            <a href="<?php echo $page < $total_pages ? htmlspecialchars(get_gallery_pagination_url($page + 1, $filter_category, $filter_status, $search, $view_mode, $limit)) : '#'; ?>" 
               class="pagination-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>" 
               aria-label="Next Page"
               title="Next Page">
              <i class="fa-solid fa-chevron-right" style="font-size: 0.72rem;"></i>
            </a>
          </nav>
        <?php endif; ?>

      </div>

    </div>
  <?php endif; ?>

<?php endif; ?>

<!-- ══════════════════════════════════════════════════════
     MODAL 1: ADD PHOTO TO GALLERY
     ══════════════════════════════════════════════════════ -->
<div id="addMediaModal" class="hrms-modal" onclick="if (event.target === this) closeAddModal();">
  <div class="hrms-modal-card" style="max-width: 540px;">
    
    <div class="hrms-modal-header">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(0, 146, 223, 0.12); color: #0092df; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
          <i class="fa-solid fa-cloud-arrow-up"></i>
        </div>
        <div>
          <h3 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
            Add Photo to Gallery
          </h3>
          <span style="font-size: 0.74rem; color: #64748b;">Showcase classrooms, campus facilities, and events</span>
        </div>
      </div>
      <button type="button" class="modal-close-btn" onclick="closeAddModal();" style="border: none; cursor: pointer; padding: 4px 8px; font-size: 1.2rem;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <div class="hrms-modal-body">
      <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
        <input type="hidden" name="action" value="add_photo">
        <input type="hidden" name="redirect_view" value="<?php echo htmlspecialchars($view_mode); ?>">
        <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">

        <!-- 1. Photo Title -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Photo Title <span style="color: #ef4444;">*</span>
          </label>
          <input type="text" name="title" class="form-control" required placeholder="e.g. Interactive Physics Classroom Session" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
        </div>

        <!-- 2. Subtitle / Caption -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Subtitle / Caption (Displayed on hover &amp; lightboxes)
          </label>
          <input type="text" name="caption" class="form-control" placeholder="e.g. Live problem solving with senior mentors inside AC classroom" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
        </div>

        <!-- 3. Category & Sort Order in 2 Columns -->
        <div style="display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 12px; margin-bottom: 14px;">
          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
              Category <span style="color: #ef4444;">*</span>
            </label>
            <select name="category" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem; background: #ffffff;">
              <option value="Smart Classrooms" selected>Smart Classrooms</option>
              <option value="Doubt Clearing">Doubt Clearing</option>
              <option value="Study Library">Study Library</option>
              <option value="Academics">Academics</option>
              <option value="Campus Life">Campus Life</option>
              <option value="Events">Events</option>
              <option value="Celebrations">Celebrations</option>
              <option value="Sports">Sports</option>
              <option value="Classrooms">Classrooms</option>
              <option value="General">General</option>
            </select>
          </div>

          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
              Sort Order
            </label>
            <input type="number" name="sort_order" value="0" min="0" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
          </div>
        </div>

        <!-- 4. Status -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Publication Status
          </label>
          <select name="status" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem; background: #ffffff;">
            <option value="active" selected>Active (Live &amp; Visible on Website)</option>
            <option value="inactive">Paused (Temporarily Hidden from Website)</option>
          </select>
        </div>

        <!-- 5. Existing Campus Photos Quick Picker -->
        <?php if (!empty($existing_gallery_files)): ?>
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            <span>Or Choose Existing Campus Photo (<?php echo count($existing_gallery_files); ?> found)</span>
            <span style="font-size: 0.72rem; color: #0092df; font-weight: 600;">Click to select</span>
          </label>
          <div style="display: flex; gap: 8px; overflow-x: auto; padding: 6px 2px; max-height: 84px;">
            <?php foreach ($existing_gallery_files as $ef): ?>
              <div class="existing-file-thumb" onclick="selectExistingGalleryFile('<?php echo htmlspecialchars($ef['name']); ?>', '<?php echo htmlspecialchars($ef['path']); ?>', 'addSelectedExistingFile', 'addImgPreviewWrap', 'addImgPreview', 'addImageUrl', this);" title="<?php echo htmlspecialchars($ef['name']); ?>">
                <img src="<?php echo htmlspecialchars($ef['path']); ?>" alt="<?php echo htmlspecialchars($ef['name']); ?>">
              </div>
            <?php endforeach; ?>
          </div>
          <input type="hidden" name="selected_existing_file" id="addSelectedExistingFile" value="">
        </div>
        <?php endif; ?>

        <!-- 6. Image File Upload -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Upload New Image File (From Computer)
          </label>
          <div class="gallery-dropzone" onclick="document.getElementById('addImageFile').click();" style="padding: 18px 12px; cursor: pointer; text-align: center; border: 1.5px dashed #cbd5e1; border-radius: 10px; background: #f8fafc;">
            <i class="fa-solid fa-cloud-arrow-up gallery-dropzone-icon" style="font-size: 1.6rem; color: #0092df; margin-bottom: 6px;"></i>
            <div class="gallery-dropzone-title" style="font-size: 0.82rem; font-weight: 700; color: #0f172a;">Click to browse image file</div>
            <div class="gallery-dropzone-sub" style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">Supports JPG, PNG, WEBP, AVIF</div>
            <input type="file" name="image_file" id="addImageFile" accept="image/*" style="display: none;" onchange="previewUploadImage(this, 'addImgPreview');">
          </div>
        </div>

        <!-- 7. Or Image URL -->
        <div class="form-group" style="margin-bottom: 18px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Or Image URL / Relative Path
          </label>
          <input type="text" name="image_url" id="addImageUrl" placeholder="/assets/imgs/gallers/gallery-1.png" class="form-control" style="width: 100%; padding: 8px 12px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.84rem;" oninput="previewUrlImage(this.value, 'addImgPreview');">
        </div>

        <!-- Live Preview Box -->
        <div id="addImgPreviewWrap" class="gallery-live-preview-box" style="margin-bottom: 18px; display: none; text-align: center; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 10px; padding: 12px;">
          <img id="addImgPreview" src="" alt="Preview" style="max-height: 140px; max-width: 100%; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
          <div class="gallery-live-preview-hint" style="font-size: 0.74rem; color: #64748b; margin-top: 6px;">Selected Image Preview</div>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #f1f5f9; padding-top: 16px;">
          <button type="button" onclick="closeAddModal();" class="roaster-btn secondary" style="padding: 9px 18px;">
            Cancel
          </button>
          <button type="submit" class="roaster-add-btn" style="padding: 9px 20px;">
            <div class="btn-icon-circle"><i class="fa-solid fa-check"></i></div>
            <span>Upload Photo</span>
          </button>
        </div>

      </form>
    </div>

  </div>
</div>

<!-- ══════════════════════════════════════════════════════
     MODAL 2: EDIT MEDIA DETAILS
     ══════════════════════════════════════════════════════ -->
<div id="editMediaModal" class="hrms-modal" onclick="if (event.target === this) closeEditModal();">
  <div class="hrms-modal-card" style="max-width: 540px;">
    
    <div class="hrms-modal-header">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(0, 146, 223, 0.12); color: #0092df; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
          <i class="fa-solid fa-pen-to-square"></i>
        </div>
        <div>
          <h3 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; font-family: 'Outfit', sans-serif;">
            Edit Gallery Media
          </h3>
          <span style="font-size: 0.74rem; color: #64748b;">Update photo title, caption, sort order, and status</span>
        </div>
      </div>
      <button type="button" class="modal-close-btn" onclick="closeEditModal();" style="border: none; cursor: pointer; padding: 4px 8px; font-size: 1.2rem;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <div class="hrms-modal-body">
      <form method="POST" action="<?php echo ADMIN_URL; ?>/gallery" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
        <input type="hidden" name="action" value="edit_photo">
        <input type="hidden" name="id" id="edit_id">
        <input type="hidden" name="current_image" id="edit_current_image">
        <input type="hidden" name="redirect_view" value="<?php echo htmlspecialchars($view_mode); ?>">
        <input type="hidden" name="redirect_status" value="<?php echo htmlspecialchars($filter_status); ?>">

        <!-- 1. Photo Title -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Photo Title <span style="color: #ef4444;">*</span>
          </label>
          <input type="text" name="title" id="edit_title" class="form-control" required style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
        </div>

        <!-- 2. Subtitle / Caption -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Subtitle / Caption
          </label>
          <input type="text" name="caption" id="edit_caption" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
        </div>

        <!-- 3. Category & Sort Order in 2 Columns -->
        <div style="display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 12px; margin-bottom: 14px;">
          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
              Category <span style="color: #ef4444;">*</span>
            </label>
            <select name="category" id="edit_category" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem; background: #ffffff;">
              <option value="Smart Classrooms">Smart Classrooms</option>
              <option value="Doubt Clearing">Doubt Clearing</option>
              <option value="Study Library">Study Library</option>
              <option value="Academics">Academics</option>
              <option value="Campus Life">Campus Life</option>
              <option value="Events">Events</option>
              <option value="Celebrations">Celebrations</option>
              <option value="Sports">Sports</option>
              <option value="Classrooms">Classrooms</option>
              <option value="General">General</option>
            </select>
          </div>

          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
              Sort Order
            </label>
            <input type="number" name="sort_order" id="edit_sort_order" min="0" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem;">
          </div>
        </div>

        <!-- 4. Status -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Publication Status
          </label>
          <select name="status" id="edit_status" class="form-control" style="width: 100%; padding: 9px 13px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.85rem; background: #ffffff;">
            <option value="active">Active (Live &amp; Visible on Website)</option>
            <option value="inactive">Paused (Temporarily Hidden from Website)</option>
          </select>
        </div>

        <!-- 5. Current Image Preview -->
        <div class="gallery-current-preview-box" style="margin-bottom: 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px;">
          <label class="gallery-current-label" style="display: block; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 6px;">Current Image</label>
          <div style="display: flex; align-items: center; gap: 12px;">
            <img id="edit_preview_img" src="" alt="Current Image" style="width: 80px; height: 55px; object-fit: cover; border-radius: 6px; border: 1px solid #cbd5e1;">
            <div class="gallery-current-hint" style="font-size: 0.74rem; color: #64748b; line-height: 1.4;">
              To change this photo, select from existing photos below or upload a new file.
            </div>
          </div>
        </div>

        <!-- 6. Existing Campus Photos Quick Picker in Edit -->
        <?php if (!empty($existing_gallery_files)): ?>
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            <span>Or Pick From Campus Photos</span>
            <span style="font-size: 0.72rem; color: #0092df; font-weight: 600;">Click to select</span>
          </label>
          <div style="display: flex; gap: 8px; overflow-x: auto; padding: 6px 2px; max-height: 84px;">
            <?php foreach ($existing_gallery_files as $ef): ?>
              <div class="existing-file-thumb" onclick="selectExistingGalleryFile('<?php echo htmlspecialchars($ef['name']); ?>', '<?php echo htmlspecialchars($ef['path']); ?>', 'editSelectedExistingFile', null, 'edit_preview_img', 'edit_image_url', this);" title="<?php echo htmlspecialchars($ef['name']); ?>">
                <img src="<?php echo htmlspecialchars($ef['path']); ?>" alt="<?php echo htmlspecialchars($ef['name']); ?>">
              </div>
            <?php endforeach; ?>
          </div>
          <input type="hidden" name="selected_existing_file" id="editSelectedExistingFile" value="">
        </div>
        <?php endif; ?>

        <!-- 7. Upload New Image File -->
        <div class="form-group" style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Upload New File (Optional)
          </label>
          <input type="file" name="image_file" accept="image/*" class="form-control" style="width: 100%; padding: 8px 12px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.84rem; background: #ffffff;">
        </div>

        <!-- 8. Image URL / Path -->
        <div class="form-group" style="margin-bottom: 18px;">
          <label style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; color: #1e293b; margin-bottom: 5px;">
            Or Update Image URL / Path
          </label>
          <input type="text" name="image_url" id="edit_image_url" placeholder="/assets/imgs/gallers/gallery-1.png" class="form-control" style="width: 100%; padding: 8px 12px; border-radius: 8px; border: 1.5px solid #cbd5e1; font-size: 0.84rem;">
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #f1f5f9; padding-top: 16px;">
          <button type="button" onclick="closeEditModal();" class="roaster-btn secondary" style="padding: 9px 18px;">
            Cancel
          </button>
          <button type="submit" class="roaster-add-btn" style="padding: 9px 20px;">
            <div class="btn-icon-circle"><i class="fa-solid fa-check"></i></div>
            <span>Update Photo</span>
          </button>
        </div>

      </form>
    </div>

  </div>
</div>

<!-- ══════════════════════════════════════════════════════
     MODAL 3: LIGHTBOX PREVIEW
     ══════════════════════════════════════════════════════ -->
<div id="lightboxModal" class="lightbox-modal" onclick="if (event.target === this) closeLightbox();">
  <div class="lightbox-content">
    <div style="padding: 14px 22px; display: flex; justify-content: space-between; align-items: center; background: #0f172a; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
      <div style="display: flex; align-items: center; gap: 10px;">
        <span id="lbCategory" class="cat-pill other" style="font-size: 0.72rem;">Category</span>
        <h4 id="lbTitle" style="margin: 0; font-size: 1rem; font-weight: 800; color: #ffffff; font-family: 'Outfit', sans-serif;">Photo Preview</h4>
      </div>
      <button type="button" onclick="closeLightbox();" style="background: none; border: none; color: #94a3b8; font-size: 1.4rem; cursor: pointer;">&times;</button>
    </div>

    <div class="lightbox-img-wrap">
      <img id="lbImage" src="" alt="Full Preview" class="lightbox-img">
    </div>

    <div class="lightbox-footer">
      <span style="font-size: 0.8rem; opacity: 0.85;">
        <i class="fa-solid fa-shield-halved" style="color: #38bdf8; margin-right: 5px;"></i>
        KSV Academy Media Archive
      </span>
      <div style="display: flex; gap: 8px;">
        <a id="lbOriginalLink" href="#" target="_blank" class="action-btn-pill secondary" style="padding: 6px 14px; font-size: 0.78rem; text-decoration: none;">
          <i class="fa-solid fa-arrow-up-right-from-square"></i>
          <span>Open Original</span>
        </a>
        <button type="button" onclick="closeLightbox();" class="action-btn-pill primary" style="padding: 6px 14px; font-size: 0.78rem;">
          Close
        </button>
      </div>
    </div>
  </div>
</div>

<script>
function openAddModal() {
  const modal = document.getElementById('addMediaModal');
  if (modal) modal.classList.add('show');
}
function closeAddModal() {
  const modal = document.getElementById('addMediaModal');
  if (modal) modal.classList.remove('show');
}

function openEditModal(item) {
  document.getElementById('edit_id').value = item.id || '';
  document.getElementById('edit_title').value = item.title || '';
  document.getElementById('edit_caption').value = item.caption || '';
  document.getElementById('edit_category').value = item.category || 'Smart Classrooms';
  document.getElementById('edit_sort_order').value = item.sort_order || 0;
  document.getElementById('edit_status').value = item.status || 'active';
  document.getElementById('edit_current_image').value = item.image || '';
  document.getElementById('edit_image_url').value = item.image || '';
  document.getElementById('edit_preview_img').src = item.image || '';

  const modal = document.getElementById('editMediaModal');
  if (modal) modal.classList.add('show');
}
function closeEditModal() {
  const modal = document.getElementById('editMediaModal');
  if (modal) modal.classList.remove('show');
}

function openLightbox(imgSrc, title, category) {
  // Validate image URL scheme before setting to prevent javascript: or malformed URIs
  if (imgSrc && (imgSrc.startsWith('/') || /^https?:\/\//i.test(imgSrc))) {
    document.getElementById('lbImage').src = imgSrc;
    document.getElementById('lbOriginalLink').href = imgSrc;
  } else {
    document.getElementById('lbImage').src = '/assets/imgs/ksv-logo.png';
    document.getElementById('lbOriginalLink').href = '#';
  }
  document.getElementById('lbTitle').innerText = title || 'Photo Preview';
  
  const catEl = document.getElementById('lbCategory');
  catEl.innerText = category || 'Category';
  catEl.className = 'cat-pill other';
  const c = (category || '').toLowerCase();
  if (c.includes('camp')) catEl.className = 'cat-pill campus';
  else if (c.includes('event')) catEl.className = 'cat-pill events';
  else if (c.includes('sport')) catEl.className = 'cat-pill sports';
  else if (c.includes('acad')) catEl.className = 'cat-pill academics';
  else if (c.includes('celeb')) catEl.className = 'cat-pill celebrations';
  else if (c.includes('class')) catEl.className = 'cat-pill classrooms';

  const lb = document.getElementById('lightboxModal');
  if (lb) lb.classList.add('show');
}
function closeLightbox() {
  const lb = document.getElementById('lightboxModal');
  if (lb) lb.classList.remove('show');
}

// Live Image Previews in Add Modal
function previewUploadImage(input, targetImgId) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const img = document.getElementById(targetImgId);
      if (img) img.src = e.target.result;
      const wrap = document.getElementById(targetImgId + 'Wrap');
      if (wrap) wrap.style.display = 'block';
    }
    reader.readAsDataURL(input.files[0]);
  }
}

function previewUrlImage(url, targetImgId) {
  if (url && url.trim() !== '') {
    const img = document.getElementById(targetImgId);
    if (img) img.src = url.trim();
    const wrap = document.getElementById(targetImgId + 'Wrap');
    if (wrap) wrap.style.display = 'block';
  }
}

// Select an existing image from assets/imgs/gallers/
function selectExistingGalleryFile(filename, webPath, hiddenInputId, previewWrapId, previewImgId, urlInputId, el) {
  const hiddenInput = document.getElementById(hiddenInputId);
  if (hiddenInput) hiddenInput.value = filename;

  if (urlInputId) {
    const urlInput = document.getElementById(urlInputId);
    if (urlInput) urlInput.value = webPath;
  }

  // Visual selection highlighting
  const parent = el.parentNode;
  if (parent) {
    const items = parent.querySelectorAll('.existing-file-thumb');
    items.forEach(function(item) { item.classList.remove('selected'); });
    el.classList.add('selected');
  }

  if (previewImgId) {
    const previewImg = document.getElementById(previewImgId);
    if (previewImg) previewImg.src = webPath;
  }
  if (previewWrapId) {
    const wrap = document.getElementById(previewWrapId);
    if (wrap) wrap.style.display = 'block';
  }
}

// Close modals on Escape key
window.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeAddModal();
    closeEditModal();
    closeLightbox();
  }
});

// Category Navigation Left/Right Scroll Enhancement
(function initGalleryNavScroll() {
  const nav = document.querySelector('.gallery-categories-nav');
  const btnLeft = document.querySelector('.gallery-nav-scroll-btn.left');
  const btnRight = document.querySelector('.gallery-nav-scroll-btn.right');
  if (!nav) return;

  function updateScrollButtons() {
    const maxScroll = nav.scrollWidth - nav.clientWidth;
    if (maxScroll > 4) {
      if (btnLeft) btnLeft.style.display = nav.scrollLeft > 6 ? 'inline-flex' : 'none';
      if (btnRight) btnRight.style.display = (nav.scrollLeft < maxScroll - 6) ? 'inline-flex' : 'none';
    } else {
      if (btnLeft) btnLeft.style.display = 'none';
      if (btnRight) btnRight.style.display = 'none';
    }
  }

  nav.addEventListener('wheel', function(e) {
    if (e.deltaY !== 0) {
      e.preventDefault();
      nav.scrollLeft += e.deltaY;
      updateScrollButtons();
    }
  }, { passive: false });

  let isDown = false;
  let startX;
  let scrollLeft;

  nav.addEventListener('mousedown', function(e) {
    isDown = true;
    startX = e.pageX - nav.offsetLeft;
    scrollLeft = nav.scrollLeft;
  });
  window.addEventListener('mouseup', function() { isDown = false; });
  nav.addEventListener('mousemove', function(e) {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - nav.offsetLeft;
    const walk = (x - startX) * 1.5;
    nav.scrollLeft = scrollLeft - walk;
    updateScrollButtons();
  });

  nav.addEventListener('scroll', updateScrollButtons);
  window.addEventListener('resize', updateScrollButtons);
  setTimeout(updateScrollButtons, 50);

  if (btnLeft) {
    btnLeft.addEventListener('click', function(e) {
      e.preventDefault();
      nav.scrollBy({ left: -160, behavior: 'smooth' });
      setTimeout(updateScrollButtons, 300);
    });
  }
  if (btnRight) {
    btnRight.addEventListener('click', function(e) {
      e.preventDefault();
      nav.scrollBy({ left: 160, behavior: 'smooth' });
      setTimeout(updateScrollButtons, 300);
    });
  }
})();
</script>

<?php require_once __DIR__ . '/../includes/layout-footer.php'; ?>
